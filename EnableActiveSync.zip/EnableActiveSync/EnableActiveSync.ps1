﻿<#	
	.NOTES
	===========================================================================
	 
	 Created on:   	12/1/2016 2:28 PM
	 Created by:   	Vikas Sukhija
	 Organization: 	
	 Filename:     	EnableActiveSync.ps1
	===========================================================================
	.DESCRIPTION
		Enable ActiveSync only for users in a Active Directory group and 
        disable it for all mailboxes not in that group
#>
$error.clear()
#####################Fuunctions###################
function ProgressBar {
    [CmdletBinding()]
    param
    (
        $Title
    )
    For ($i = 1; $i -le "10"; $i++) {
        Start-Sleep 1;
        Write-Progress -Activity $Title -status "$i" -percentComplete ($i /10 * 100)
    }
}

function Send-Email {
    [CmdletBinding()]
    param
    (
        $From,
        
        $To1,
        
        $To2,
        
        $To3,
        
        $bcc,
        
        $cc,
        
        $body,
        
        $subject,
        
        $attachment,
        
        $smtpserver
    )
    $message = new-object System.Net.Mail.MailMessage
    $message.From = $from
    if ($To1 -ne $null) {
        $message.To.Add($To1)
    }
    if ($To2 -ne $null) {
        $message.To.Add($To2)
    }
    if ($To3 -ne $null) {
        $message.To.Add($To3)
    }
    if ($cc -ne $null) {
        $message.CC.Add($cc)
    }
    if ($bcc -ne $null) {
        $message.Bcc.Add($bcc)
    }
    $message.IsBodyHtml = $True
    if ($subject -ne $null) {
        $message.Subject = $Subject
    }
    if ($attachment -ne $null) {
        $attach = new-object Net.Mail.Attachment($attachment)
        $message.Attachments.Add($attach)
    }
    if ($body -ne $null) {
        $message.body = $body
    }
    $smtp = new-object Net.Mail.SmtpClient($smtpserver)
    $smtp.Send($message)
}
###########Add Exchnage Snapin ######################
If ((Get-PSSnapin | Where-Object { $_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010" }) -eq $null) {
    Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}
if ($error) { ProgressBar -Title "Exit - Exchnage Shell not loaded"; exit }
###############ADD Logs and variables ###############
$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/", "-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log = (Get-Location).Path + "\Logs" + "\" + "Processed_PS_AS" + $date1 + "_" + $time + "_.log"
$log1 = (Get-Location).Path + "\Logs" + "\" + "Enabled_Disabled_AS" + $date1 + "_" + $time + "_.log"

$csv1 = (Get-Location).Path + "\Temp" + "\" + "DisabledUsers" + $date1 + "_" + $time + "_.csv"
$csv2 = (Get-Location).Path + "\Temp" + "\" + "EnabledUsers" + $date1 + "_" + $time + "_.csv"

$group = "CN=ADGroup,OU=DistributionLists,OU=Exchange,DC=labtest,DC=com"

$FindDisabledQuery = "(&(objectCategory=user)(objectClass=user)(mail=*)(homeMDB=*)(memberOf=CN=ADGroup,OU=DistributionLists,OU=Exchange,DC=labtest,DC=comm)(|(msExchOmaAdminWirelessEnable=4)(msExchOmaAdminWirelessEnable=5)(msExchOmaAdminWirelessEnable=6)(msExchOmaAdminWirelessEnable=7)))"
$FindEnabledQuery = "(&(objectCategory=user)(objectClass=user)(mail=*)(homeMDB=*)(!userAccountControl=514)(!memberOf=CN=ADGroup,OU=DistributionLists,OU=Exchange,DC=labtest,DC=com)(|(!msExchOmaAdminWirelessEnable=*)(msExchOmaAdminWirelessEnable=0)(msExchOmaAdminWirelessEnable=1)(msExchOmaAdminWirelessEnable=2)(msExchOmaAdminWirelessEnable=3)))"

$countofchanges = "100"

$email1 = "VikasS@labtest.com"
$from = "donotreply@labtest.com"
$smtpserver = "smtpserver"

$limit = (Get-Date).AddDays(-60) #for report recycling
$path1 = (Get-Location).Path + "\Logs"
$path2 = (Get-Location).Path + "\Temp"

Start-Transcript -Path $log
####################CSVDE Processing##################

if (Get-DistributionGroup $group) {
    
    CSVDE -f $csv1 -r $FindDisabledQuery -l "sAMAccountName, msExchOmaAdminWirelessEnable"
    
    CSVDE -f $csv2 -r $FindEnabledQuery -l "sAMAccountName, msExchOmaAdminWirelessEnable"
    
}
else {
    Write-Host "Exiting Script as group doesn't exist" -ForegroundColor Red
    ProgressBar -Title "Exiting Script as group doesn't exist"
    Exit
}
if ($error) { ProgressBar -Title "Exit - CSVDE Export Error"; exit }
##############Enable ActiveSync Processing###########
if (Test-Path $csv1) {
    $data = Import-Csv $csv1
    if ($error) { ProgressBar -Title "Exit - Import CSV Error"; exit }
    if ($data.count -lt $countofchanges) {
        if ($data -ne $null) {
            foreach ($i in $data) {
                if (Get-CASMailbox $i.sAMAccountName) {
                    Set-CASMailbox -Identity $i.sAMAccountName -ActiveSyncEnabled:$true
                    $dt = get-date
                    $sm = $i.sAMAccountName
                    Write-Host "$sm is enabled for ActiveSYnc" -ForegroundColor Green
                    Add-Content $log1 "$dt -- $sm is enabled for ActiveSYnc"
                }
                else {
                    Write-Host ""$i.sAMAccountName" is not mailbox" -ForegroundColor Yellow
                }
            }
        }
        
    }
    else {
        Write-Host "Count of changes are more than $countofchanges" -ForegroundColor Yellow
        Send-Email -From $from -To1 $email1 -subject "Disable ACtiveSync - Count of changes are more than $countofchanges" -smtpserver $smtpserver
    }
}

##############Disable ActiveSync Processing###########
if (Test-Path $csv2) {
    $data = Import-Csv $csv2
    if ($error) { ProgressBar -Title "Exit - Import CSV Error"; exit }
    if ($data.count -lt $countofchanges) {
        if ($data -ne $null) {
            foreach ($i in $data) {
                if (Get-CASMailbox $i.sAMAccountName) {
                    Set-CASMailbox -Identity $i.sAMAccountName -ActiveSyncEnabled:$false
                    $dt = get-date
                    $sm = $i.sAMAccountName
                    Write-Host "$sm is Disabled for ActiveSYnc" -ForegroundColor Yellow
                    Add-Content $log1 "$dt -- $sm is Disabled for ActiveSYnc"
                }
                else {
                    Write-Host ""$i.sAMAccountName" is not mailbox" -ForegroundColor Yellow
                }
            }
        }
        
    }
    else {
        Write-Host "Count of changes are more than $countofchanges" -ForegroundColor Yellow
        Send-Email -From $from -To1 $email1 -subject "Disable ACtiveSync - Count of changes are more than $countofchanges" -smtpserver $smtpserver
    }
}
if (Test-Path $log1) {
    Send-Email -From $from -To1 $email1 -subject "Manage-ActiveSync Log" -attachment $log1 -smtpserver $smtpserver
}
##################Recycle logs#################
if ($error) {Send-Email -From $from -To1 $email1 -subject "Error - Manage Active Sync" -body $error -smtpserver $smtpserver}
    
Get-ChildItem -Path $path1 | Where-Object {
    $_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

Get-ChildItem -Path $path2 | Where-Object {
    $_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

Stop-Transcript
#########################################################