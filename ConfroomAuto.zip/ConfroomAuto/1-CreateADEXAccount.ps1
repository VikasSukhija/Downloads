###########################################################################
#		Author: Vikas Sukhija
#		Date: 12/11/2015
#		Modified: 12/14/2015
#       	Upadted: Included Groups & owners as well
#		Reviewer:
#		Description: Create Room mailbox Accounts for Confrence Rooms
############################################################################
########################### Add Exchange Shell##############################
param (
	$csv)
$error.clear()
$csv = Read-Host "Please enter csv file"

$email1 = "Reporting@labtest.com"
$from = "ConRmMailboxCreation@labtest.com"
$smtpserver = "smtp.labtest.com"

################Email Function#####################

function Send-Email
{
	[CmdletBinding()]
	param
	(
		$From,
		[array]$To,
		[array]$bcc,
		[array]$cc,
		$body,
		$subject,
		$attachment,
		$smtpserver
	)
	$message = new-object System.Net.Mail.MailMessage
	$message.From = $from
	if ($To -ne $null)
	{
		$To | ForEach-Object{
			$to1 = $_
			$to1
			$message.To.Add($to1)
		}
	}
	if ($cc -ne $null)
	{
		$cc | ForEach-Object{
			$cc1 = $_
			$cc1
			$message.CC.Add($cc1)
		}
	}
	if ($bcc -ne $null)
	{
		$bcc | ForEach-Object{
			$bcc1 = $_
			$bcc1
			$message.bcc.Add($bcc1)
		}
	}
	$message.IsBodyHtml = $True
	if ($subject -ne $null)
	{
		$message.Subject = $Subject
	}
	if ($attachment -ne $null)
	{
		$attach = new-object Net.Mail.Attachment($attachment)
		$message.Attachments.Add($attach)
	}
	if ($body -ne $null)
	{
		$message.body = $body
	}
	$smtp = new-object Net.Mail.SmtpClient($smtpserver)
	$smtp.Send($message)
}
###################################################
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://ExchangeServer.labtest.com/PowerShell/ -Authentication Kerberos
import-pssession $session

if ($Error)
{
	Write-Host "CSV Parameter incorrect ---Script will exit" -ForegroundColor Yellow
	For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
	Stop-transcript
	Send-Email -From $from -To $email1 -subject "Confrence Room Creation - CSV Parameter incorrect" -smtpserver $smtpserver
	exit
}


###########################Define Variables/Logs############################

$date = get-date -format d
# replace \ by -
$time = get-date -format t
$month = get-date
$month1 = $month.month
$year1 = $month.year


$date = $date.ToString().Replace("/", "-")

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = (Get-Location).Path + "\Logs" + "\" + "RoomScript" + $date + "_" + $time + "_.txt"
$log1 = (Get-Location).Path + "\Logs" + "\" + "RoomScript_Summary" + $date + "_" + $time + "_.txt"

Start-Transcript -Path $logs


$data = import-csv $csv
if ($Error)
{
	Write-Host "CSV Import Error ---Script will exit" -ForegroundColor Yellow
	For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
	Stop-transcript
	Send-Email -From $from -To $email1 -subject "Confrence Room Creation - CSV Import Error" -smtpserver $smtpserver
	exit
}

foreach ($i in $data)
{
	
	$name = $i.name
	$name = $name.trim() # mandatory
	if ($name -like $null)
	{
		Write-host "Name is empty... Script will exit" -foregroundcolor yellow
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
		Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $logs
		exit
	}
	
	$samaccountname = $i.samaccountname
	$samaccountname = $samaccountname.trim() #mandatory
	if ($samaccountname -like $null)
	{
		Write-host "samaccountName is empty... Script will exit" -foregroundcolor yellow
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
		Stop-transcript
		Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $logs
		exit
	}
	
	$OU = $i.OU
	$OU = $OU.trim() #mandatory
	if ($OU -like $null)
	{
		Write-host "OU is empty... Script will exit" -foregroundcolor yellow
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
		Stop-transcript
		Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $logs
		exit
	}
	
	$Office = $i.office
	$Office = $office.trim()
	
	$Title = $i.title
	$Title = $Title.trim()
	
	$Company = $i.company
	$Company = $Company.trim()
	
	$Telephone = $i.Telephone
	$Telephone = $Telephone.trim()
	
	$Restricted = $i.Restricted
	$Restricted = $Restricted.trim() #mandatory
	if ($Restricted -like $null)
	{
		Write-host "Restricted field is empty... Script will exit" -foregroundcolor yellow
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
		Stop-transcript
		Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $logs
		exit
	}
	$resou = $i.resou
	$resou = $resou.trim()
	
	$OwnerGroup = $i.OwnerGroup
	$OwnerGroup = $OwnerGroup.trim()
	
	$AuthorGroup = $i.AuthorGroup
	$AuthorGroup = $AuthorGroup.trim()
	
	if (($Restricted -like "Yes") -and (($OwnerGroup -like $null) -or ($OwnerGroup -like $null) -or ($resou -like $null)))
	{
		Write-host "Either both or one of the restrction group is empty... Script will exit" -foregroundcolor yellow
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
		Stop-transcript
		Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $logs
		exit
	}
	
	$managedby = $i.PrimaryOwnerGrp
	$managedby = $managedby.trim()
	
	$bkpowner = $i.SecondaryOwnerGrp
	$user1 = $bkpowner.split(",")
	$count1 = $user1.count
	$user = $user1[0 .. ($count1 - 2)]
	$count = $user.count
	
	if (($Restricted -like "Yes") -and (($managedby -like $null) -or ($bkpowner -like $null)))
	{
		Write-host "Either both or one of the managed by filed is empty... Script will exit" -foregroundcolor yellow
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
		Stop-transcript
		Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $logs
		exit
	}
	
	if ($Restricted -like "Yes")
	{
		## All Owners for DL including backups
		$AllOwner = @()
		$AllOwner += $managedby
		$AllOwner += $user
		$AllOwner = $AllOwner | Select -Unique
	}
	
	$Notes = $i.Notes
	
	$UserPrincipalName = $samaccountname + "@" + "labtest.com"
	
	if ($error)
	{
		Write-host "CSV Load error... Script will exit" -foregroundcolor yellow
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
		Stop-transcript
		Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $logs
		exit
	}
	
	############################Start Room mailbox account###########################
	
	write-host "Creating Room mailbox Account..........." -foregroundcolor green
	
	$gmmbx1 = get-mailbox $name -ea silentlycontinue
	$gmmbx2 = get-mailbox $samaccountname -ea silentlycontinue
	if ($gmmbx1 -or $gmmbx2)
	{
		Write-Host "Mailbox Already exists,script will exit....." -ForegroundColor Yellow
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
		Stop-transcript
		Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $logs
		exit
	}
	
	$Error.Clear()
	
	New-Mailbox -Name $name -OrganizationalUnit $ou -DisplayName $name -samaccountname $samaccountname -UserPrincipalName $UserPrincipalName -Room
	
	if ($error)
	{
		Write-host "Mailbox Creation error... Script will exit" -foregroundcolor yellow
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10 * 100) }
		Stop-transcript
		$DATE1 = GET-DATE
		Add-Content $log1 "$DATE1 - Mailbox $name Creation error"
		Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $log1
		exit
	}
	
	For ($i = 1; $i -le "20"; $i++) { sleep 1; Write-Progress -Activity "Creating Room Mailbox" -status "$i" -percentComplete ($i /20 * 100) }
	
	write-host "Room mailbox $name Account Created..........." -foregroundcolor green
	$DATE1 = GET-DATE
	Add-Content $log1 "$DATE1 - Mailbox $name Created"
	
	while (!(get-mailbox $samaccountname -ea silentlycontinue))
	{
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Creating Room Mailbox $name" -status "$i" -percentComplete ($i /10 * 100) }
	}
	
	$getrmbx = get-mailbox $samaccountname -ea silentlycontinue
	$Error.clear()
	#######################Update Attributes on the Mailbox##################
	
	if ($getrmbx)
	{
		
		set-User -identity $samaccountname -office $office -Company $company -Title $title -phone $Telephone -notes $notes
		set-mailbox -id $samaccountname -CustomAttribute1 "NONE" -CustomAttribute12 "CONF"
		
		if ($error)
		{
			write-host "Setting Room mailbox $samaccountname Attributes encountered error ..........." -foregroundcolor yellow
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Error - Setting Attributes"}
		else
		{
			write-host "Room mailbox $samaccountname Attributes has been set..........." -foregroundcolor green
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Success - Setting Attributes"}
		
	}

	$error.clear()
	
	########################Create Owner /Author Groups#####################
	
	if ($Restricted -like "Yes")
	{
		
		New-DistributionGroup -Name $OwnerGroup -Type "Security" -OrganizationalUnit $resou -Managedby $AllOwner -MemberDepartRestriction closed
		#Provide permissions to owner on Group
		For ($i = 1; $i -le "20"; $i++) { sleep 1; Write-Progress -Activity "Creating $OwnerGroup" -status "$i" -percentComplete ($i /20 * 100) }
		if ($error)
		{
			Write-host "group $OwnerGroup Creation error..." -foregroundcolor yellow
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Error - $OwnerGroup Creation"
		}
		else
		{
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Success - $OwnerGroup Creation"
			while (!(get-distributiongroup $OwnerGroup -ea "silentlycontinue"))
			{
				For ($i = 1; $i -le "20"; $i++) { sleep 1; Write-Progress -Activity "Waiting for $OwnerGroup Appear " -status "$i" -percentComplete ($i /20 * 100) }
			}
		}
		$Error.clear()
		New-DistributionGroup -Name $AuthorGroup -Type "Security" -OrganizationalUnit $resou -Managedby $AllOwner -MemberDepartRestriction closed
		#Provide permissions to owner on Group
		For ($i = 1; $i -le "20"; $i++) { sleep 1; Write-Progress -Activity "Creating $AuthorGroup" -status "$i" -percentComplete ($i /20 * 100) }
		if ($error)
		{
			Write-host "group $AuthorGroup Creation error..." -foregroundcolor yellow
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Error - $AuthorGroup Creation"
		}
		else
		{
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Success - $AuthorGroup Creation"
			while (!(get-distributiongroup $AuthorGroup -ea "silentlycontinue"))
			{
				For ($i = 1; $i -le "20"; $i++) { sleep 1; Write-Progress -Activity "Waiting for $OwnerGroup Appear " -status "$i" -percentComplete ($i /20 * 100) }
			}
		}
		#################Update the Custom attributes for the group#############
		
		$getowngp = get-distributiongroup $OwnerGroup -ea "silentlycontinue"
		$getauthgp = get-distributiongroup $AuthorGroup -ea "silentlycontinue"
		
		$Error.clear()
		if ($getowngp)
		{
			set-distributiongroup $OwnerGroup -CustomAttribute1 "NONE" -CustomAttribute12 "CONF"
			Add-ADPermission -identity $OwnerGroup -User $managedby -AccessRights writeproperty -Properties "Member"
			if ($error)
			{
				write-host "Setting Group $OwnerGroup Attributes encountered error ..........." -foregroundcolor yellow
				$DATE1 = GET-DATE
				Add-Content $log1 "$DATE1 - Error - $OwnerGroup Attributes"}
			else
			{
				write-host "Group $OwnerGroup Attributes Attributes has been set..........." -foregroundcolor green
				$DATE1 = GET-DATE
				Add-Content $log1 "$DATE1 - Success - $OwnerGroup Attributes"}
		}
		
		
		if ($getauthgp)
		{
			set-distributiongroup $AuthorGroup -CustomAttribute1 "NONE" -CustomAttribute12 "CONF"
			Add-ADPermission -identity $AuthorGroup -User $managedby -AccessRights writeproperty -Properties "Member"
			if ($error)
			{
				write-host "Setting Group $AuthorGroup Attributes encountered error ..........." -foregroundcolor yellow
				$DATE1 = GET-DATE
				Add-Content $log1 "$DATE1 - Error - $AuthorGroup Attributes"}
			else
			{
				write-host "Group $AuthorGroup Attributes Attributes has been set..........." -foregroundcolor green
				$DATE1 = GET-DATE
				Add-Content $log1 "$DATE1 - Success - $AuthorGroup Attributes"}
		}
		
	}
	else
	{
		Write-host "As Restricted is not equal to Yes for $samaccountname....so Group creation is ignored" -foregroundcolor blue
		$DATE1 = GET-DATE
		Add-Content $log1 "$DATE1 - SKIP - Restricted"}
	
	$error.clear()
	
	###################ADD permission for Unrestricted Rooms####################
	
	if ($Restricted -like "No")
	{
		
		Set-MailboxFolderPermission -identity ($getrmbx.alias + ':\calendar') -user "Default" -AccessRights "Reviewer"
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Adding Reviewer Perm on $samacountname " -status "$i" -percentComplete ($i /10 * 100) }
		
		if ($error)
		{
			write-host "Setting unrestricted for $samaccountname default permission encountered error ..........." -foregroundcolor yellow
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Error - Setting Default Reviewer"}
		else
		{
			write-host "Unrestricted Room Deafult Reviewer has been set for .......$samaccountname" -foregroundcolor green
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Success - Setting Default Reviewer"}
	}
	$error.clear()
	
	###################ADD permission for Restricted Rooms####################	
	
	if ($Restricted -like "Yes")
	{
		
		Set-MailboxFolderPermission -identity ($getrmbx.alias + ':\calendar') -user "Default" -AccessRights "None"
		
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Adding Default Perm to None on $samacountname " -status "$i" -percentComplete ($i /10 * 100) }
		
		ADD-mailboxfolderpermission -identity ($getrmbx.alias + ':\calendar') -user "$ownergroup" -AccessRights "Owner"
		
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Adding Owner Perm to $ownergroup on $samacountname " -status "$i" -percentComplete ($i /10 * 100) }
		
		ADD-mailboxfolderpermission -identity ($getrmbx.alias + ':\calendar') -user "$Authorgroup" -AccessRights "Author"
		
		For ($i = 1; $i -le "10"; $i++) { sleep 1; Write-Progress -Activity "Adding Author Perm to $Authorgroup on $samacountname " -status "$i" -percentComplete ($i /10 * 100) }
		
		if ($error)
		{
			write-host "Setting restricted permission for $samaccountname encountered error ..........." -foregroundcolor yellow
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Error - Setting Restricted Permissions"}
		else
		{
			write-host "Restrcited Permissions has been set for........... $samaccountname" -foregroundcolor green
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Success - Setting Restricted Permissions"}
	}
	
	$error.clear()
	
	#########################Setting Auto accept##############################
	
	$AUTOMATE_PROCESSING = "AutoAccept"
	$ADD_ADDITIONAL_RESPONSE = $false
	$ADDITIONAL_RESPONSE = $false
	$ADD_NEW_REQUEST_TENTATIVELY = $false
	$REMOVE_OLD_MEETING_MSG = $true
	$DELETE_SUBJECT = $false
	$DELETE_Organizer = $false
	$RESTRICT_ALL_BOOK = $false
	$TentativePendingApproval = $true
	
	if ($Restricted -like "No")
	{
		set-calendarprocessing -id $samaccountname `
							   -AutomateProcessing: $AUTOMATE_PROCESSING		`
							   -enableresponsedetails: $false				`
							   -AddAdditionalResponse: $ADD_ADDITIONAL_RESPONSE	`
							   -AdditionalResponse: $ADDITIONAL_RESPONSE		`
							   -AddNewRequestsTentatively: $ADD_NEW_REQUEST_TENTATIVELY	`
							   -RemoveOldMeetingMessages: $REMOVE_OLD_MEETING_MSG		`
							   -DeleteSubject: $DELETE_SUBJECT		`
							   -TentativePendingApproval:$TentativePendingApproval
		set-MailboxCalendarConfiguration -id $samaccountname -RemindersEnabled:$false
		For ($i = 1; $i -le "5"; $i++) { sleep 1; Write-Progress -Activity "Setting Auto accept properties" -status "$i" -percentComplete ($i /5 * 100) }
		if ($error)
		{
			write-host "Unrestricted Room $samaccountname : Setting Auto accept & other properties encountered error ..........." -foregroundcolor yellow
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Error - Setting AutoAccept Properties"}
		else
		{
			write-host "Unrestricted Room $samaccountname : Auto accept & other properties has been set..........." -foregroundcolor green
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Success - Setting AutoAccept Properties"}
	}
	
	$error.clear()
	
	if ($Restricted -like "Yes")
	{
		$restrictlist = @()
		$restrictlist = $ownergroup, $Authorgroup
		set-calendarprocessing -id $samaccountname `
							   -AutomateProcessing: $AUTOMATE_PROCESSING		`
							   -enableresponsedetails: $false			        `
							   -AddAdditionalResponse: $ADD_ADDITIONAL_RESPONSE	`
							   -AdditionalResponse: $ADDITIONAL_RESPONSE		`
							   -AddNewRequestsTentatively: $ADD_NEW_REQUEST_TENTATIVELY	`
							   -RemoveOldMeetingMessages: $REMOVE_OLD_MEETING_MSG		`
							   -DeleteSubject: $DELETE_SUBJECT			`
							   -AllBookInPolicy: $RESTRICT_ALL_BOOK		`
							   -BookInPolicy: $restrictlist 	`
							   -TentativePendingApproval:$TentativePendingApproval
		set-MailboxCalendarConfiguration -id $samaccountname -RemindersEnabled:$false
		For ($i = 1; $i -le "5"; $i++) { sleep 1; Write-Progress -Activity "Setting Auto accept properties" -status "$i" -percentComplete ($i /5 * 100) }
		if ($error)
		{
			write-host "Restricted Room $samaccountname : Setting Auto accept & other properties encountered rror ..........." -foregroundcolor yellow
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Error - Setting AutoAccept Restricted Properties"}
		else
		{
			write-host "Restricted Room $samaccountname : Auto accept & other properties has been set..........." -foregroundcolor green
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Success - Setting AutoAccept Restricted Properties"}
	}
	
	$error.clear()
	
	#################################Setting for Video Conference Rooms#########################
	
	if ($name -match ".*(VC).*")
	{
		set-calendarprocessing -id $samaccountname -AddOrganizerToSubject $DELETE_Organizer
		For ($i = 1; $i -le "5"; $i++) { sleep 1; Write-Progress -Activity "Setting VC Room properties" -status "$i" -percentComplete ($i /5 * 100) }
		if ($error)
		{
			write-host "VC Room $samaccountname : Setting Auto accept & other properties encountered error ..........." -foregroundcolor yellow
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Error - Setting VC Properties"}
		else
		{
			write-host "VCRestricted Room $samaccountname : Auto accept & other properties has been set..........." -foregroundcolor green
			$DATE1 = GET-DATE
			Add-Content $log1 "$DATE1 - Success - Setting VC Properties"}
	}
	############################################################################################
	
}
Stop-transcript

$body = Get-Content $log1
Send-Email -From $from -To $email1 -subject "Confrence Room Creation Logs" -smtpserver $smtpserver -attachment $log1 -body $body


Exit
