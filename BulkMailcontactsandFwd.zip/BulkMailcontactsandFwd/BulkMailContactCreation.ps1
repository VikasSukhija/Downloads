<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	9/20/2019 1:46 PM
    Created by:   	Vikas Sukhija
    Organization: 	
    Filename:     	BulkMailContactCreation.ps1
    ===========================================================================
    .DESCRIPTION
    This script will create Bulk contacts by reading the CSV file
#>
param (
  [string]$csvpath = $(Read-Host "Enter CSV file path")
)

function Write-Log
{
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [array]$Name,
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [string]$Ext,
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [string]$folder,
    
    [Parameter(ParameterSetName = 'Create',Position = 0)][switch]$Create,
    
    [Parameter(Mandatory = $true,ParameterSetName = 'Message')]
    [String]$Message,
    [Parameter(Mandatory = $true,ParameterSetName = 'Message')]
    [String]$path,
    [Parameter(Mandatory = $false,ParameterSetName = 'Message')]
    [ValidateSet('Information','Warning','Error')]
    [string]$Severity = 'Information',
    
    [Parameter(ParameterSetName = 'Message',Position = 0)][Switch]$MSG
  )
  switch ($PsCmdlet.ParameterSetName) {
    "Create"
    {
      $log = @()
      $date1 = Get-Date -Format d
      $date1 = $date1.ToString().Replace("/", "-")
      $time = Get-Date -Format t
	
      $time = $time.ToString().Replace(":", "-")
      $time = $time.ToString().Replace(" ", "")
	
      foreach ($n in $Name)
      {$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"}
      return $log
    }
    "Message"
    {
      $date = Get-Date
      $concatmessage = "|$date" + "|   |" + $Message +"|  |" + "$Severity|"
      switch($Severity){
        "Information"{Write-Host -Object $concatmessage -ForegroundColor Green}
        "Warning"{Write-Host -Object $concatmessage -ForegroundColor Yellow}
        "Error"{Write-Host -Object $concatmessage -ForegroundColor Red}
      }
      
      Add-Content -Path $path -Value $concatmessage
    }
  }
} #Function Write-Log

function start-ProgressBar
{
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true)]
    $Title,
    [Parameter(Mandatory = $true)]
    [int]$Timer
  )
	
  For ($i = 1; $i -le $Timer; $i++)
  {
    Start-Sleep -Seconds 1;
    Write-Progress -Activity $Title -Status "$i" -PercentComplete ($i /100 * 100)
  }
} # Function start-progressbar

#################Check if logs folder is created##################
$logpath  = (Get-Location).path + "\logs" 
$Reportpath  = (Get-Location).path + "\Report" 
$testlogpath = Test-Path -Path $logpath
if($testlogpath -eq $false)
{
  start-ProgressBar -Title "Creating logs folder" -Timer 10
  New-Item -Path (Get-Location).path -Name Logs -Type directory
}

$testlogpath = Test-Path -Path $Reportpath
if($testlogpath -eq $false)
{
  start-ProgressBar -Title "Creating reports folder" -Timer 10
  New-Item -Path (Get-Location).path -Name Report -Type directory
}

####################Load variables and log###########
$log = Write-Log -Name "BulkMailContact-Log" -folder "logs" -Ext "log"
$report1 = Write-Log -Name "BulkMailContact-Report" -folder "Report" -Ext "csv"
Write-Log -Message "Start ......Script" -path $log 
################connect to modules###################
try
{
  $Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://exchangeserver.labtest.com/PowerShell/ -Authentication Kerberos
  Import-PSSession $Session -AllowClobber
  Write-Log -Message "Exchange 2010 Module Loaded" -path $log 
}
catch
{
  $exception = $_.Exception
  Write-Log -Message "Error loading Exchange 2010" -path $log -Severity Error 
  Write-Log -Message $exception -path $log -Severity error
  Exit
}

$collection=@()
$data = import-csv $csvpath
write-log -message "imported.............$csvpath" -path $log
foreach($i in $data){
  $error.clear()
  
  $mcoll = "" | select orgemail,Name, externaladdress, status
  $mcoll.orgemail = $i.orgemail.trim()
  $externaladdress = $i.externaladdress.trim()
  $extsplit = $externaladdress -split "@"
  $name = "LABtest-" + $extsplit[0] +"-fwd"
  $mcoll.Name = $name
  $mcoll.externaladdress = $externaladdress
  write-log -message "Processing ...$name" -path $log
  new-mailcontact -Name $name -ExternalEmailAddress $externaladdress -OrganizationalUnit  "labtest.com/Exchange/Contacts"
  if($error)
  {
    $mcoll.status = "error"
    write-log -message "Failed Creating mailcontact $Name - $externaladdress" -path $log -Severity error

  }
  else{

    $mcoll.status = "Success"
    write-log -message "Created mailcontact $Name - $externaladdress" -path $log
  }
  $collection+=$mcoll
}
$collection | Export-Csv $report1 -NoTypeInformation
start-ProgressBar -Title "wait for replication" -Timer 100

$collection | foreach-object{
  $name = $_.Name
  set-mailcontact -id $name -HiddenFromAddressListsEnabled:$true
  write-log -message "hidding ...$name" -path $log
}
Write-Log -Message "Script.........Finished" -path $log 
################################################################################