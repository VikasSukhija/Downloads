<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	9/20/2019 1:46 PM
    Created by:   	Vikas Sukhija
    Organization: 	
    Filename:     	BulkMailContactCreation.ps1
    ===========================================================================
    .DESCRIPTION
    This script will Bulk forward by reading the CSV file
#>
param (
  [string]$csvpath = $(Read-Host "Enter CSV file path")
)

function Write-Log
{
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [array]$Name,
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [string]$Ext,
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [string]$folder,
    
    [Parameter(ParameterSetName = 'Create',Position = 0)][switch]$Create,
    
    [Parameter(Mandatory = $true,ParameterSetName = 'Message')]
    [String]$Message,
    [Parameter(Mandatory = $true,ParameterSetName = 'Message')]
    [String]$path,
    [Parameter(Mandatory = $false,ParameterSetName = 'Message')]
    [ValidateSet('Information','Warning','Error')]
    [string]$Severity = 'Information',
    
    [Parameter(ParameterSetName = 'Message',Position = 0)][Switch]$MSG
  )
  switch ($PsCmdlet.ParameterSetName) {
    "Create"
    {
      $log = @()
      $date1 = Get-Date -Format d
      $date1 = $date1.ToString().Replace("/", "-")
      $time = Get-Date -Format t
	
      $time = $time.ToString().Replace(":", "-")
      $time = $time.ToString().Replace(" ", "")
	
      foreach ($n in $Name)
      {$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"}
      return $log
    }
    "Message"
    {
      $date = Get-Date
      $concatmessage = "|$date" + "|   |" + $Message +"|  |" + "$Severity|"
      switch($Severity){
        "Information"{Write-Host -Object $concatmessage -ForegroundColor Green}
        "Warning"{Write-Host -Object $concatmessage -ForegroundColor Yellow}
        "Error"{Write-Host -Object $concatmessage -ForegroundColor Red}
      }
      
      Add-Content -Path $path -Value $concatmessage
    }
  }
} #Function Write-Log

function start-ProgressBar
{
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true)]
    $Title,
    [Parameter(Mandatory = $true)]
    [int]$Timer
  )
	
  For ($i = 1; $i -le $Timer; $i++)
  {
    Start-Sleep -Seconds 1;
    Write-Progress -Activity $Title -Status "$i" -PercentComplete ($i /10 * 100)
  }
} # Function start-progressbar

function LaunchEOL
	{
		param
		(
			$Credential
		)
		
		$UserCredential = $Credential
		
		$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
		
		Import-PSSession $Session -Prefix "EOL" -AllowClobber
	}
	
	Function RemoveEOL
	{
		
		$Session = Get-PSSession | where { $_.ComputerName -like "outlook.office365.com" }
		Remove-PSSession $Session
		
	}

#################Check if logs folder is created##################
$logpath  = (Get-Location).path + "\logs" 
$Reportpath  = (Get-Location).path + "\Report" 
$testlogpath = Test-Path -Path $logpath
if($testlogpath -eq $false)
{
  start-ProgressBar -Title "Creating logs folder" -Timer 10
  New-Item -Path (Get-Location).path -Name Logs -Type directory
}

$testlogpath = Test-Path -Path $Reportpath
if($testlogpath -eq $false)
{
  start-ProgressBar -Title "Creating reports folder" -Timer 10
  New-Item -Path (Get-Location).path -Name Report -Type directory
}

####################Load variables and log###########
$log = Write-Log -Name "BulkMailfwd-Log" -folder "logs" -Ext "log"
$report1 = Write-Log -Name "BulkMailfwd-Report" -folder "Report" -Ext "csv"
Write-Log -Message "Start ......Script" -path $log 
################connect to modules###################
try
{
  $usercred = Get-Credential
  launcheol -Credential $userCred
  Write-Log -Message "Exchange Online Module Loaded" -path $log 
}
catch
{
  $exception = $_.Exception
  Write-Log -Message "Error loading Exchange Online module" -path $log -Severity Error 
  Write-Log -Message $exception -path $log -Severity error
  Exit
}

$collection=@()
$data = import-csv $csvpath
write-log -message "imported.............$csvpath" -path $log
foreach($i in $data){
  $error.clear()
  
  $mcoll = "" | select orgemail, externaladdress,Name, status
  $Emailaddress = $i.orgemail
  $Forwardingaddress = $i.externaladdress
  $mcoll.orgemail = $Emailaddress
  $mcoll.Name = $i.Name
  $mcoll.externaladdress = $Forwardingaddress
  write-log -Message "Processing ...$Emailaddress" -path $log
   set-eolmailbox -id $Emailaddress -ForwardingAddress $Forwardingaddress
  if($error)
  {
    $mcoll.status = "error"
    write-log -message "Failed fwding $Emailaddress - $Forwardingaddress" -path $log -Severity error
   
  }
  else{

    $mcoll.status = "Success"
     write-log -message "Fwding $Emailaddress - $Forwardingaddress" -path $log
  }
  $collection+=$mcoll
}
$collection | Export-Csv $report1 -NoTypeInformation
RemoveEOL
Write-Log -Message "Script.........Finished" -path $log 
################################################################################