#############################################################################
#       Author: Vikas Sukhija
#       Reviewer:    
#       Date: 01/24/2015
#       Satus: 
#       Update: 04/12/2015
#       Description: Report & turn of auto mapping status
#############################################################################
####################Define logs##############################################

$limit = (Get-Date).AddDays(-60) #for log recycling
$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$path = ".\logs\"
$output1 = ".\logs\" + "AutomappingR_" + $date + "_" + $time + "_.csv"
$output2 = ".\logs\" + "Automapping_" + $date + "_" + $time + "_.log"

###########################Add Shells########################################
If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles.ADManagement"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}

$Collection = @()

$allmailboxes = get-mailbox -resultsize unlimited

$allmailboxes | foreach-object{

$user =  $_.SamAccountName
$user
$automap = get-qaduser  $user -includedproperties "msExchDelegateListLink" | where{$_.msExchDelegateListLink} | select Name,@{Name = "msExchDelegateListLink";Expression ={$_.msExchDelegateListLink}}
$automap

if($automap.msExchDelegateListLink){

$coll = "" | select Name,Automap

$coll.Name = $automap.Name
$coll.Automap = $automap.msExchDelegateListLink

$collection += $coll
}

}

$collection | export-csv $output1 -notypeinformation

timeout 10

###########################Set Automapping to Null##########################

$collection | foreach{
$aname = $_.Name
write-host "processing..... $aname" -foregroundcolor green

$user = get-qaduser $aname -includedproperties "msExchDelegateListLink"
$name = $user.Name

$automapnull = $user | Set-QADUser -ObjectAttributes @{msExchDelegateListLink = $null}

add-content $output2 "$name .........msExchDelegateListLink...attribute has been set to ...Null"
}

########################Recycle logs ######################################

Get-ChildItem -Path $path  | Where-Object {  
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force 

###########################################################################
