###########################################################################################
##           Script to Archive List in CSV and rmove items from sharepoint     
##           Author: Vikas SUkhija                             								
##           Reviewer:       		                 								
##           Review Date: 02-14-2015  
##           Modified: 04-14-2015
##           
###########################################################################################
#############################Log Files#####################################################

$days = (get-date).adddays(-90) #define list retention

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t
$month = get-date 
$month1 = $month.month
$year1 = $month.year
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log1 = ".\Logs" + "\" + "Splistarchive_" + $date + $time + "_.log"

$output1 = ".\Archivecsv" + "\" + "Sp_List_" + $date + "_" + $time + "_.csv"

$logs = ".\Logs" + "\" + "Powershellsplarchive" + $date + "_" + $time + "_.txt"

################################Add Sharepoint Shell#####################################

#Start-Transcript -Path $logs 

If ((Get-PSSnapin | where {$_.Name -match "SharePoint.PowerShell"}) -eq $null)
{
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}


######################################get List items to be delted########################

$web = Get-SPWeb "http://myspteamuat.labtest.com/sites/Support"
$list = $web.lists["AD Group Modification"]
$collection = @()

$items = $list.items
$itemscount = $items.count
$itemscount
$date = get-date
Add-Content $log1 "$date Reading items in the List"
$date = get-date
Add-Content $log1 "$date $itemscount items in the List"

$items = $items | where{($_['Status'] -like "*Processed*") -or ($_['AdGpModWF'] -eq "17") -and ($_['Created'] -le $days)}

if($items -eq $null)
{
Write-host "nothing to process, script will exit"
$date = get-date
Add-Content $log1 "$date nothing to process, script will exit"
$date = get-date
Add-Content $log1 "$date Finished processing the requests"
exit

} else {

$date = get-date
Add-Content $log1 "$date Collecting the columns from the list item "

#########################Get items so that these can be exported first##################
$items | foreach-object {
	$ID = $_['ID']
	$Ticket = $_['Ticket No.']
        $GrpName = $_['Group Name']
	$GpSamName = $_['GpSamName']
	$manager = $_['Manager']
	$Action = $_['Action']
	$userName = $_['User Name']
	$ApprovingManager = $_['Approving Manager']
	$UserSamName = $_['UserSamName']
	$ManSamName = $_['ManSamName']
	$AdGpModWF = $_['AdGpModWF']
	$status = $_['Status']
        $Created = $_['Created']
	$createdby = $_['Created By']
	$Modified = $_['Modified']
	$Modifiedby = $_['Modified By']
        $submitter= $_['Cresamname']

$coll = ""| select ID,Ticket,GrpName,GpSamName,manager,Action,userName,ApprovingManager,UserSamName,ManSamName,AdGpModWF,status,
Created,createdby,Modified,Modifiedby,submitter

$coll.ID = $ID
$coll.Ticket = $Ticket
$coll.GrpName = $GrpName
$coll.GpSamName = $GpSamName
$coll.manager = $manager
$coll.Action = $Action
$coll.userName = $userName
$coll.ApprovingManager = $ApprovingManager
$coll.UserSamName = $UserSamName
$coll.ManSamName = $ManSamName
$coll.AdGpModWF = $AdGpModWF
$coll.status = $status
$coll.Created = $Created
$coll.createdby = $createdby
$coll.Modified = $Modified
$coll.Modifiedby = $Modifiedby
$coll.submitter = $submitter
$collection += $coll

$date = get-date
Add-Content $log1 "$date Delete List item with ID $ID"
$_.Delete()

}

}
###############################################Export CSV#################################

$collection | export-csv $output1 -notypeinformation

#stop-transcript 


#########################################Script finished##################################
        
		
