#########################################################################
#			Author:Vikas Sukhija(http://msexchange.me)
#			Reviewer:
#			Date: 12/17/2015
#			Desc: Backup & Restore Permissions
#			Refrence: File System Security PowerShell Module 4.0.1
#			Thanks Raimund Andr�e for creating the Module
#########################################################################
########################Import NTFS Module###############################
param(
$restore)


$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$resfolder = ".\restore\" + "Restore" + "_" + $date  + "_" + $time

$logs = ".\logs\" + "Restore" + "_" + $date  + "_" + $time + "_.log"

if(!(Test-path $resfolder)){new-item -path $resfolder -type directory}


Import-Module .\NTFSSecurity\NTFSSecurity.psd1

if($error) {write-host "Module not imported-- Script will exit" -foregroundcolor yellow}

start-transcript $logs

$restorepath = read-host "Enter the path of dump file from which permissions will be restored"
if($restorepath -like $null){Write-host "No Input entered - script will exit" -foregroundcolor yellow
For($i = 1; $i -le "10"; $i++){ sleep 1;Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10*100)}
}

write-host "-------------------------------------" -foregroundcolor magenta
write-host "When prompted please enter the path for file or folder to restore" -foregroundcolor magenta
write-host "Example: \\fileserver\folder" -foregroundcolor magenta
write-host "Example: \\fileserver\folder\file.txt" -foregroundcolor magenta
write-host "Paths should be same from which backup is taken " -foregroundcolor magenta

$restore = Read-host "Enter the path for restore"

if($restore -like $null){Write-host "No Input entered - script will exit" -foregroundcolor yellow
For($i = 1; $i -le "10"; $i++){ sleep 1;Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10*100)}
}
else{
$msg = Read-host "Do you want to include subfolders -Type "Yes" else "No""

###############Extracting the permissions required from dump#########

if($msg -eq "Yes"){

$restpath = $resfolder +"\" + "restore" + "_" + $date + "_" + $time + "_.csv"

$restore = $restore + "*"

import-csv $restorepath | Where {$_.fullname -like $restore} | export-csv $restpath

if($error -like $null){Write-host "Error encountered during extraction of permissions from dump" -foregroundcolor yellow
For($i = 1; $i -le "10"; $i++){ sleep 1;Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10*100)}
stop-transcript
Exit
}

For($i = 1; $i -le "20"; $i++){ sleep 1;Write-Progress -Activity "Now permissions will be applied, Cancel immediately if you dont want to perform this operation" -status "$i" -percentComplete ($i /20*100)}

import-csv $restpath | Add-NTFSaccess

}
elseif($msg -eq "No"){

$restpath = $resfolder +"\" + "restore" + "_" + $date + "_" + $time + "_.csv"

import-csv $restorepath | Where {$_.fullname -like $restore} | export-csv $restpath

if($error -like $null){Write-host "Error encountered during extraction of permissions from dump" -foregroundcolor yellow
For($i = 1; $i -le "10"; $i++){ sleep 1;Write-Progress -Activity "Exiting Script" -status "$i" -percentComplete ($i /10*100)}
stop-transcript
Exit
}

For($i = 1; $i -le "20"; $i++){ sleep 1;Write-Progress -Activity "Now permissions will be applied, Cancel immediately if you dont want to perform this operation" -status "$i" -percentComplete ($i /20*100)}

import-csv $restpath | Add-NTFSaccess

}

else
{
For($i = 1; $i -le "10"; $i++){ sleep 1;Write-Progress -Activity "Exiting Script - Invalid input" -status "$i" -percentComplete ($i /10*100)}
stop-transcript
Exit
}
}
stop-transcript
###########################################################################

