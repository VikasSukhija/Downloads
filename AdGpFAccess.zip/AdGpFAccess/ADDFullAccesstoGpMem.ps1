######################################################################
#               Author: Vikas Sukhija
#               Date:- 06/16/2015
#		Reviewer:-
#               Description:- Add full Access to service account 
#               to particular group members.
######################################################################

$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/","-")
$dir= "C:\Scripts\AdGpFAccess\logs"
$limit = (Get-Date).AddDays(-30)

$logs = ".\Logs" + "\" + "Processed_" + $date1 + "_.log"

$smtpServer = "smtpserver"
$fromadd = "DoNotReply@labtest.com"
$email1 = "vikass@labtest.com"

Start-Transcript -Path $logs

######Add Exchange Shell##########################################

$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://exchangeserver.labtest.com/PowerShell/ -Authentication Kerberos
import-pssession $session


$serviceacct = "serviceaccount"

$group = "Distributiongroup"

###################################

$groupmem = get-distributiongroupmember $group

$Statefile = "$($group)-Name.csv"


# If the file doesn't exist, create oit
   If (!(Test-Path $Statefile)){  
                $groupmem | select Name,PrimarySMTPAddress | Export-csv $Statefile -NoTypeInformation 
                }

# Check Changes
$Changes =  Compare-Object $groupmem $(Import-Csv $StateFile) -Property Name | 
                Select-Object Name,
                    @{n='State';e={
                        If ($_.SideIndicator -eq "=>"){
                            "Removed" } Else { "Added" }
                        }
                    }

$Changes | foreach-object{
         
	if($_.state -eq "Added") {

         Write-host "Full access to $serviceacct will be granted on "$_.Name"" -foregroundcolor green
	ADD-MailboxPermission -Identity $_.Name -User $serviceacct -AccessRights FullAccess -AutoMapping $false
	}
	
        if($_.state -eq "Removed") {
        $userid = "$_.Name"
        Write-host "Full access to $serviceacct will be removed on "$_.Name"" -foregroundcolor Red
	Remove-MailboxPermission -Identity $_.Name -User $serviceacct -AccessRights FullAccess -confirm:$false
	}
      }

$groupmem | select Name,PrimarySMTPAddress | Export-csv $StateFile -NoTypeInformation

###########################Recycle##########################################

$path = $dir 
 
Get-ChildItem -Path $path  | Where-Object {  
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force 

#######################Report Error#########################################
if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "DL Full Access Script Error"
$msg.Body = $error
$smtp.Send($msg)
$error.clear()
       }
  else

      {
    Write-host "no errors till now"
      }


stop-transcript

##########################################################################


