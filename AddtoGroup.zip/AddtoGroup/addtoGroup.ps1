###########################################################################################
##                                                                                            
##           Author: Vikas Sukhija                  		                              
##           Date: 26-11-2012                       		      			      
##           Description:- If user is not a member of group this script add it after reading   
##           from CSV     			      		                              			      
###########################################################################################
#Add Quest Shell...

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}

#####define Group########

$grp="Group Name"

#########################

# import csv file

$data = import-csv $args[0]

$Can = �CN=$grp�

Write-host $Can

#Check if usr belogs to group in csv

foreach ($i in $data)

{

$user=get-qaduser $i.userid


  if (($user.memberof -like �$Can,*�))

  {

  write-host �$user is a member & will not be added to $grp group�

  }

  else
 
  {

  write-host �$user is not a member & will be added to $grp group�

  add-qadgroupmember $grp $user  

  }

}
########################################################################################