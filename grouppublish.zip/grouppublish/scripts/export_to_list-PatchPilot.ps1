Add-PsSnapin Microsoft.SharePoint.Powershell �ErrorAction SilentlyContinue 

$siteurl = "http://spsite.testlab.com/sites/PatchPilot"        ### Specify SharePoint Site
$spWeb = Get-SPWeb $siteurl                            
$docLibraryName = "Site List"                ### Specify Document library where file wil be uploaded
$localFolderPath = "C:\scripts\report"                      ### Put folder path in a variable 
$docLibrary = $spWeb.Lists[$docLibraryName]   

$files = ([System.IO.DirectoryInfo] (Get-Item $localFolderPath)).GetFiles() | ForEach-Object {  
				
$fileStream = ([System.IO.FileInfo] (Get-Item $_.FullName)).OpenRead()  

$contents = new-object byte[] $fileStream.Length  

$fileStream.Read($contents, 0, [int]$fileStream.Length);  

$fileStream.Close();  

$folder = $docLibrary.RootFolder  

$spFile = $folder.Files.Add($folder.Url + "/" + $_.Name, $contents, $true)  

$spItem = $spFile.Item  
} 