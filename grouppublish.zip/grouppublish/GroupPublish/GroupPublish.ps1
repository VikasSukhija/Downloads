###############################################################################
#		This script  will export group membership & than 
#		Call another script to update 
#               /PatchPilot/Lists/Tech%20Pilot%20Members2/AllItems.aspx
#		Author: Vikas Sukhija
# 		Date:- 01/15/2014
#
###############################################################################
####################Define Variables###########################################

$group = "group1"

$source = "C:\scripts\GroupPublish\output1\patchpilot.html"
$destination = "\\spserver\c$\Scripts\report"

###############################################################################


$output1 =  ".\" + "\" + "output1" + "\" + "patchpilot.html"

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles.ADManagement"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}

$groupmembers = Get-QADGroupMember $group -SizeLimit 0 | Select LastName,FirstName,Email,City,DisplayName,SamAccountName


$gpm=$groupmembers | select LastName,FirstName,Email,City,DisplayName,SamAccountName -unique | sort LastName

# All HTML formatting in a single variable to be used with ConvertTo-HTML cmdlet

$HTMLFormat = "<style>"
$HTMLFormat = $HTMLFormat + "BODY{background-color:GainsBoro;}"
$HTMLFormat = $HTMLFormat + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$HTMLFormat = $HTMLFormat + "TH{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:darksalmon}"
$HTMLFormat = $HTMLFormat + "TD{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:LightBlue}"
$HTMLFormat = $HTMLFormat + "</style>"


$gpm  | ConvertTo-HTML -Head $HTMLFormat  -Body "<H2><Font Size = 4,Color = DarkCyan>Patch Pilot List</Font></H2>" -AS Table | 
Set-Content $output1

copy-item $source $destination

##############################################################################