﻿<#	
	===========================================================================
	 Created on:   	9/11/2017 1:37 PM
	 Created by:   	Vikas Sukhija
	 Organization: 	
	 Filename:     	LyncTerminationTask.ps1
	===========================================================================
	.DESCRIPTION
		Process Lync Terminations
#>
##########ADd Functions#######################
function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}

##############Import Modules###################
Import-Module 'C:\Program Files\Common Files\Microsoft Lync Server 2010\Modules\Lync\Lync.psd1'

##############Add variables/Log################

$log = Write-Log -folder logs -Name "Lync_Task" -Ext txt
$count = "100"
$pool1 = "pool01.labtest.com"
$pool2 = "pool02.labtest.com"
$pool3 = "pool03.labtest.com"
$termcoll = @()

$ou1 = "OU=TerminatedAccts,DC=labtest,DC=com"
$ou2 = "OU=TerminatedAccts,OU=Europe,DC=labtest,DC=com"
$ou3 = "OU=TerminatedAccts,OU=NA-US1,DC=labtest,DC=com"
$ou4 = "OU=TerminatedAccts,OU=NA-US2,DC=labtest,DC=com"
$ou5 = "OU=TerminatedAccts,OU=NA-US3,DC=labtest,DC=com"
$ou6 = "OU=TerminatedAccts,OU=Asia,DC=labtest,DC=com"
$ou7 = "OU=TerminatedAccts,OU=INTL1,DC=labtest,DC=com"
$ou8 = "OU=TerminatedAccts,OU=INTL2,DC=labtest,DC=com"

$from = "LyncReport@labtest.com"
$to = "Lyncteam@labtest.com"
$smtpserver = "smtp.labtest.com"

#####################Start processing##################
Start-Transcript -Path $log
$termcoll1 = Get-CsUser -OU $ou1 | where{ ($_.RegistrarPool -like $pool1) -or ($_.RegistrarPool -like $pool2) -or ($_.RegistrarPool -like $pool3) }
$termcoll2 = Get-CsUser -OU $ou2 | where{ ($_.RegistrarPool -like $pool1) -or ($_.RegistrarPool -like $pool2) -or ($_.RegistrarPool -like $pool3) }
$termcoll3 = Get-CsUser -OU $ou3 | where{ ($_.RegistrarPool -like $pool1) -or ($_.RegistrarPool -like $pool2) -or ($_.RegistrarPool -like $pool3) }
$termcoll4 = Get-CsUser -OU $ou4 | where{ ($_.RegistrarPool -like $pool1) -or ($_.RegistrarPool -like $pool2) -or ($_.RegistrarPool -like $pool3) }
$termcoll5 = Get-CsUser -OU $ou5 | where{ ($_.RegistrarPool -like $pool1) -or ($_.RegistrarPool -like $pool2) -or ($_.RegistrarPool -like $pool3) }
$termcoll6 = Get-CsUser -OU $ou6 | where{ ($_.RegistrarPool -like $pool1) -or ($_.RegistrarPool -like $pool2) -or ($_.RegistrarPool -like $pool3) }
$termcoll7 = Get-CsUser -OU $ou7 | where{ ($_.RegistrarPool -like $pool1) -or ($_.RegistrarPool -like $pool2) -or ($_.RegistrarPool -like $pool3) }
$termcoll8 = Get-CsUser -OU $ou8 | where{ ($_.RegistrarPool -like $pool1) -or ($_.RegistrarPool -like $pool2) -or ($_.RegistrarPool -like $pool3) }

if ($termcoll1) { $termcoll += $termcoll1 }
if ($termcoll2) { $termcoll += $termcoll2 }
if ($termcoll3) { $termcoll += $termcoll3 }
if ($termcoll4) { $termcoll += $termcoll4 }
if ($termcoll5) { $termcoll += $termcoll5 }
if ($termcoll6) { $termcoll += $termcoll6 }
if ($termcoll7) { $termcoll += $termcoll7 }
if ($termcoll8) { $termcoll += $termcoll8 }

$termcoll.count
if (($termcoll.count -gt "0") -and ($termcoll.count -lt $count))
{
	Write-Host "Start disabling the Lync users" -ForegroundColor Yellow
	$termcoll | ForEach-Object{
		$obj = $_.identity
		Disable-csuser -identity $obj
		Write-Host "processed .............$obj" -ForegroundColor Yellow
	}
}
elseif ($termcoll.count -eq "0")
{
	Write-Host "Nothing to.............. process" -ForegroundColor green
}
else
{
	Write-Host "Lync Termination Count is greater that $count - please check" -ForegroundColor green
	Send-MailMessage -SmtpServer $smtpserver -From $from -To $to -Subject "Lync Termination Count is greater that $count - please check" -Body "Lync Termination Count is greater that $count - please check"
}
Write-Host "Counting all Active Users on Lync" -ForegroundColor green
$alllyncusers = get-csuser
$alllusr = $alllyncusers.count
Write-Host "Total Lync Users: $alllusr" -ForegroundColor Green
Stop-Transcript
Send-MailMessage -SmtpServer $smtpserver -From $from -To $to -Subject "Lync Daily Task" -Body "Attched log" -Attachments $log
#######################################################################
