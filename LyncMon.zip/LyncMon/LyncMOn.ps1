####################################################################
#       Author: Vikas Sukhija
#	Reviewer:
#       Date: 05/08/2015
#	Update: 
#       Description: Monitoring Lync "Messages in server"
#	If its go beyound threshold, Critical alert is generated
####################################################################

Import-Module 'C:\Program Files\Common Files\Microsoft Lync Server 2010\Modules\Lync\Lync.psd1'

$threshold = "100"

$fromadd = �Monitoring@labtest.com�
$email1=�Vikassukhija@labtest.com�
$smtpServer="smtpserver"

$server_list=@("serverDRP01",
"serverDRP02",
"serverFEP01",
"serverFEP02",
"serverFEP03")

$server_list | foreach-object {

$computern = $_

Write-host "processing ..............$computern" -foregroundcolor blue

$csstatus = Get-CsWindowsService -computerName $computern

$rtcsrvst = $csstatus | where{$_.Name -like "RTCSRV"}

$activitylevel = $rtcsrvst.activitylevel

$activitylevel1 = $activitylevel.split("=")

$activitylevel2 = $activitylevel1[2].split(",")

$alevel = $activitylevel2[0]

if([int]$alevel -ge $threshold) {

Write-host "Messages in Server $computern is $alevel" -foregroundcolor Red

$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "Event Notification : OPEN CRITICAL : Messages in Server $computern is above $threshold"
$msg.Body = "Event Notification : OPEN CRITICAL : Messages in Server $computern is above $threshold"
$smtp.Send($msg)
}
else {

Write-host "Messages in Server $computern is $alevel" -foregroundcolor green

}

}

############################################################################






