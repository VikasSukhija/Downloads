#########################################################################
#			Author: Vikas Sukhija
#			Reviewer:
#			date: 7/6/2016
#			Modified:7/11/2016						
#			Description: Fix o365 UPN
#			Update: Added reporting
#			modified: Rollback capability based on csv
#########################################################################

$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/","-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = ".\Logs" + "\" + "Processed_Rollback" + $date1 + "_" + $time + "_.log"
$report = ".\report" + "\" + "Report_Rollback" + $date1 + "_" + $time + "_.csv"

$collection = @()

Start-Transcript -Path $logs

If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}


$data = import-csv $args[0]    

foreach($i in $data){


$user = $i.Name
$rollbkupn = $i.ExistingUPN
$winupn = $i.WindowsEmailAddress

$mbx=Get-User $user

$mbcoll = "" | select Name,ExistingUPN,WindowsEmailAddress,RollbackedUPN

if($mbx){

	if($mbx.UserPrincipalName -eq $winupn) {
	Set-User -identity $mbx -UserPrincipalName $rollbkupn
	Write-host "$user will be rolled back to $rollbkupn" -foregroundcolor blue 
	$mbcoll.Name = $mbx.Name
	$mbcoll.ExistingUPN = $mbx.UserPrincipalName
	$mbcoll.WindowsEmailAddress = $mbx.WindowsEmailAddress
	$mbcoll.RollbackedUPN = $rollbkupn }

	else{	
	Write-host "$user UPN will not be modified" -foregroundcolor green
	$mbcoll.Name = $mbx.Name
	$mbcoll.ExistingUPN = $mbx.UserPrincipalName
	$mbcoll.WindowsEmailAddress = $mbx.WindowsEmailAddress
	$mbcoll.RollbackedUPN = "Not Rolledback" }
        }

$collection += $mbcoll
}

$collection | export-csv $report -notypeinfo

stop-transcript
##########################################################################