#############################################################################
#       Author: Alex Rodrick
#	Reviewer: Vikas Sukhija
#       Date: 4/14/2016
#       Description: Apply Voice email retetion policy
#############################################################################

# Add Exchange Shell...

If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)
{ Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010}


#format Date

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)

$output = ".\logs\" + "UMretentiongApplied_" + $date + "_.csv"

$pol = "VoicemailRetentionPolicy"

$ummbx = Get-UMMailbox -Resultsize:Unlimited | Get-Mailbox  | Where-Object{$_.RetentionPolicy -ne $pol}  | Select Name,Alias

if($ummbx -ne $null){
foreach($i in $ummbx)
  {
   Write-host "Processing ..."$i.Name"..." -foregroundcolor green
   Set-Mailbox $i.Alias -RetentionPolicy $pol
  }

$ummbx | export-csv $output -notypeinformation
}

else {
Write-host " Nothing to Process" -foregroundcolor magenta

}



 
#############################################################################