######################################################################################
#
#                       Author: Vikas Sukhija
#                       Description: Message Tracking Multiple users from CSV 
#                       based on diffrent dates
#                       Date:- 08/02/2014
######################################################################################

If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)

{ 
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}

$data = import-csv .\Trackingfile.csv

foreach ($i in $data)

{

$userid = $i.NetworkID
$start = $i.TERM_EFFECTIVE_DATE
$end = $i.Trackingtilldate
$sender = $i.Sender
$csv = ".\logs" + "\" + $userid + "_.csv"

@"
$userid
$start
$end
$sender
"@

Write-host "Message Tracking started for ------------------------$userid" -foregroundcolor Green

Get-transportserver | Get-MessageTrackingLog -Start $start -End $end -sender $sender �resultsize unlimited  | 
select Timestamp,clientip,ClientHostname,
ServerIp,ServerHostname,sender,EventId,
MessageSubject, TotalBytes , SourceContext,ConnectorId,
Source ,@{Name=�Recipents�;Expression={$_.recipients}} | export-csv $csv

}

######################################################################################


