﻿################################################################################## 
#       Author: Vikas Sukhija 
#       Date: 06/31/2013 
#       Modified:12/07/2013
#       Modified:02/02/2014
#       Description: Extract group members recursevely 
#       Modification: Take input from text files
#       Modification: added samaccountname & email
################################################################################### 
 
get-content .\groupname.txt | foreach-object {

$Group = $_
$groups = ".\results\" + "groups_" + $_ + "_.txt"
$members = ".\results\" + "members_" + $_ + "_.txt"
$uniquemembers1 = ".\results\" + "uniquemembers_" + $_ + "_.txt"
$uniquegroups1 = ".\results\" + "uniquegroups_" + $_ + "_.txt"
$uniquemembers2 = ".\results\" + "uniquememberssmmail_" + $_ + "_.txt"


######################check if object is group or not #############################
function checkgroup ($Group1)
{

$Search = New-Object DirectoryServices.DirectorySearcher([ADSI]"")
$Search.filter = "(&(objectCategory=group)(objectClass=group)(cn=$Group1))"
$input=$Search.Findall()

if($input -ne $null)
{
##Write-Host "$Group1 is a valid"
return $true
}
else 
{
##Write-Host "$Group1 is a invalid"
return $false
}
}
##################################Recurse thru groups ##############################

function getallmembersrecursively ($Group) 
{ 
$Search = New-Object DirectoryServices.DirectorySearcher([ADSI]"") 
$Search.filter = "(&(objectCategory=group)(objectClass=group)(cn=$Group))" 
$input=$Search.Findall() 
 
if($input -ne $null) 
{ 
Foreach($group in $input){ 
$groupname = $group.GetDirectoryEntry() 
$GPName = $groupname.DistinguishedName 
$GPMember = $groupname.member 
$GPName1 = [string]$GPName 
$gsplit1 = $GPName1.split(",") 
$fpiece1 = $gsplit1[0] 
$cnsplit1 = $fpiece1.split("=") 
$GPName2 = $cnsplit1[1] 
 
Write-Host "$GPName2 is a Group" 
Add-Content $groups $GPName2 

####get all groups from file to compare so as there is no circular nesting

$getallgroups = Get-Content $groups

Foreach($gmember in $GPMember){ 
$gsplit = $gmember.split(",") 
$fpiece = $gsplit[0] 
$cnsplit = $fpiece.split("=") 
$Name = $cnsplit[1] 

$result = checkgroup $Name

if ($result -eq "true")
{
	if ($getallgroups -contains $Name)
		{
			Write-Host "$Name equals $GPName2"
			#####not needed for troubleshooting######Add-Content .\conflict.txt "$Name equals $getallgroups -----"  
			
		}
    else 
        {
			#####not needed for troubleshooting######Add-Content .\donotconflict.txt "$Name recurse"
			getallmembersrecursively $Name
        }
}

else
{
Write-Host $Name
Add-Content $members $Name 
##############Write-Host "$Name not equals $GPName2"

} 
} 
} 
} 
}
#######################################################################
getallmembersrecursively $Group 
sleep 5 
#########################unique members################################ 

function checkuserDN ($usersm)  
{  
  
$Search = New-Object DirectoryServices.DirectorySearcher([ADSI]"")  
$Search.filter = "(&(objectCategory=user)(objectClass=user)(CN=$usersm))"  
$findusr=$Search.Findall()  
 
if ($findusr.count -gt 1) 
      {     
            $count = 0 
            foreach($i in $findusr) 
            { 
                  write-host $count ": " $i.path 
                  $count = $count + 1 
        write-host "multiple matches found" 
            } 
 
       exit 
      } 
      elseif ($findusr.count -gt 0) 
      { 
            return $findusr[0].path 
      } 
      else 
      { 
      write-host "no match found" 
 
      } 
} 

##########################################################################

function getusermail ($user)

{
$lddn = checkuserDN $user

$getuser=new-object directoryservices.directoryentry($lddn)

$getuser.mail


}

function getusersam ($user)

{
$lddn = checkuserDN $user

$getuser=new-object directoryservices.directoryentry($lddn)

$getuser.samaccountname


}


##########################################################################
 
$uniquemembers = Get-Content $members
$uniquemembers = $uniquemembers | select -uniq 
Add-Content $uniquemembers1 $uniquemembers 


$uniquegroups = Get-Content $groups
$uniquegroups = $uniquegroups | select -uniq 
Add-Content $uniquegroups1 $uniquegroups 
 
get-content $uniquemembers1 | foreach-object {

$sam = getusersam $_
$mail = getusermail $_

Add-content $uniquemembers2 "$sam,$mail"
}


} 
####################################################################### 

