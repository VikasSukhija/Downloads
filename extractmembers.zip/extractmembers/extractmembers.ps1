﻿################################################################################## 
#       Author: Vikas Sukhija 
#       Date: 06/31/2013 
#       Description: Extract group members recursevely 
################################################################################### 
 
$Group = Read-Host "Enter the group CN name" 

######################check if object is group or not #############################
function checkgroup ($Group1)
{

$Search = New-Object DirectoryServices.DirectorySearcher([ADSI]"")
$Search.filter = "(&(objectCategory=group)(objectClass=group)(cn=$Group1))"
$input=$Search.Findall()

if($input -ne $null)
{
##Write-Host "$Group1 is a valid"
return $true
}
else 
{
##Write-Host "$Group1 is a invalid"
return $false
}
}
##################################Recurse thru groups ##############################

function getallmembersrecursively ($Group) 
{ 
$Search = New-Object DirectoryServices.DirectorySearcher([ADSI]"") 
$Search.filter = "(&(objectCategory=group)(objectClass=group)(cn=$Group))" 
$input=$Search.Findall() 
 
if($input -ne $null) 
{ 
Foreach($group in $input){ 
$groupname = $group.GetDirectoryEntry() 
$GPName = $groupname.DistinguishedName 
$GPMember = $groupname.member 
$GPName1 = [string]$GPName 
$gsplit1 = $GPName1.split(",") 
$fpiece1 = $gsplit1[0] 
$cnsplit1 = $fpiece1.split("=") 
$GPName2 = $cnsplit1[1] 
 
Write-Host "$GPName2 is a Group" 
Add-Content .\groups.txt $GPName2 

####get all groups from file to compare so as there is no circular nesting

$getallgroups = Get-Content .\groups.txt

Foreach($gmember in $GPMember){ 
$gsplit = $gmember.split(",") 
$fpiece = $gsplit[0] 
$cnsplit = $fpiece.split("=") 
$Name = $cnsplit[1] 

$result = checkgroup $Name

if ($result -eq "true")
{
	if ($getallgroups -contains $Name)
		{
			Write-Host "$Name equals $GPName2"
			#####not needed for troubleshooting######Add-Content .\conflict.txt "$Name equals $getallgroups -----"  
			
		}
    else 
        {
			#####not needed for troubleshooting######Add-Content .\donotconflict.txt "$Name recurse"
			getallmembersrecursively $Name
        }
}

else
{
Write-Host $Name
Add-Content .\members.txt $Name 
##############Write-Host "$Name not equals $GPName2"

} 
} 
} 
} 
}
#######################################################################
getallmembersrecursively $Group 
sleep 5 
#########################unique members################################ 
 
$uniquemembers = Get-Content .\members.txt 
$uniquemembers = $uniquemembers | select -uniq 
Add-Content .\uniquemembers.txt $uniquemembers 
 
$uniquegroups = Get-Content .\groups.txt 
$uniquegroups = $uniquegroups | select -uniq 
Add-Content .\uniquegroups.txt $uniquegroups 
 
 
####################################################################### 

