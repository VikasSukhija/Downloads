#############################################################################
#       Author: Vikas Sukhija
#       Date: 11/04/2014
#       Description: Extract Recoverable deleted items
#############################################################################

# Add Exchange Shell...

. $env:ExchangeInstallPath\bin\RemoteExchange.ps1
Connect-ExchangeServer -auto


#format Date

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)

$output = ".\" + "RecoverabeQuotaReport_" + $date + "_.csv"


#create a collection to hold results(dynamic array)

$Collection = @()
$a= Get-Mailbox -resultsize unlimited

$a | foreach-object{

Write-host "Processing................. "$_.SamAccountName"" -foregroundcolor green

$st1 = Get-MailboxFolderStatistics  $_.Alias �FolderScope RecoverableItems |?{$_.Name -eq "Recoverable Items"} 
$st2 = Get-MailboxFolderStatistics  $_.Alias �FolderScope RecoverableItems |?{$_.Name -eq "Audits"} 
$st3 = Get-MailboxFolderStatistics  $_.Alias �FolderScope RecoverableItems |?{$_.Name -eq "Deletions"} 
$st4 = Get-MailboxFolderStatistics  $_.Alias �FolderScope RecoverableItems |?{$_.Name -eq "Purges"} 

$user = get-user $_.identity

$mbxr = �� | select Alias,Recoverable,Audits,Deletions,Purges
$mbxr.Alias = $_.Alias
$mbxr.Recoverable = $st1.FolderSize
$mbxr.Audits = $st2.FolderSize
$mbxr.Deletions = $st3.FolderSize
$mbxr.Purges = $st4.FolderSize

$Collection += $mbxr
}
 
#export the collection to csv 

$Collection | export-csv $output -notypeinformation

#######################################################################################
