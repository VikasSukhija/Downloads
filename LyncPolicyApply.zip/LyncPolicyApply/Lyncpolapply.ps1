##############################################################################################
#				Author: Manhur Mannan
#				Reviewer: Vikas Sukhija
#				Date: 09/01/2015
#				Review: 09/15/2015
#				Update: Fixed bug & logic,as it was working intermittently
#				Update: 01/21/2016
#				Desc: Apply Lync policy based on Ad group Membership
###############################################################################################

########################Import AD / Lync Modules########################################

Import-Module 'C:\Program Files\Common Files\Microsoft Lync Server 2010\Modules\Lync\Lync.psd1'
Import-Module activedirectory



######################Define LOgs/ Variables#############################################

$date = get-date -format d 
$date = $date.ToString().Replace(�/�, �-�) 
$time = get-date -format t 
$time = $time.ToString().Replace(":", "-") 
$time = $time.ToString().Replace(" ", "")

$output = ".\Logs" + "\"+ "LyncExternalAccess_" + $date + "_.csv"
$logs = ".\Logs" + "\" + "Powershell" + $date + "_" + $time + "_.txt"

$dir= ".\logs"
$limit = (Get-Date).AddDays(-30) 


$groupname = "Lyncexternalaccess"
$policyExt = "Allow Outside Access"
$SMTPServer = "SMTP SErver" 
$emailFrom = "DoNotReply@labtest.com" 
$emailTo = "Vikassukhija@labtest.com" 

Start-Transcript -Path $logs

#################### Get all Lync suers ################################################

$users = Get-CsUser -resultsize unlimited
$usercount = $users.count

"Total Enabled users = $usercount"

$resultarray =@()

Foreach ($user in $users)
    {
     $lncobj = new-object PSObject 
     $usersam = $user.SamAccountName
     $userid = $user.identity
     	  
     $groups = Get-ADPrincipalGroupMembership $usersam 

###########Check users is member of $groupname ##################################
      $mem = $null
      Foreach ($group in $groups)
       {
        If ($group.name -like $groupname) {
	$mem = "Yes"}

        } 
################################if user is member of $groupname##################

    If ($mem -eq "Yes")
            {
            Write-host "Processing.....memberof...... $usersam Member" -foregroundcolor Green
             $policies = Get-Csuser $userid
             $extpolicy = $policies.ClientVersionPolicy
             $policy = $extpolicy.FriendlyName
	     

                If($policy -ne $policyExt){
		Grant-CsExternalAccessPolicy -Identity $userid -PolicyName $policyExt
                "$usersam has been enabled for lync External Access policy"
		$lncobj | add-member -membertype NoteProperty -name "SamaccountName" -Value $usersam
		$lncobj | add-member -membertype NoteProperty -name "Access Level" -Value "Added"
		} 
                Else 
		 {
		  "$usersam is Already Enabled"
		  #$lncobj | add-member -membertype NoteProperty -name "SamaccountName" -Value $usersam
		  #$lncobj | add-member -membertype NoteProperty -name "Access Level" -Value "Already Added"
		 }
            } 
########################If user is not emember of $groupname##################
     Else 
            {
            Write-host "Processing....notmemberof........ $usersam Member" -foregroundcolor Yellow
            $policies = Get-Csuser $userid
            $extpolicy = $policies.ClientVersionPolicy
            $policy = $extpolicy.FriendlyName
             
             If($policy -eq $policyExt){
	     Grant-CsExternalAccessPolicy -Identity $userid -PolicyName $Null
             "$usersam has been disabled for lync External Access policy"
	      $lncobj | add-member -membertype NoteProperty -name "SamaccountName" -Value $usersam
	      $lncobj | add-member -membertype NoteProperty -name "Access Level" -Value "Removed"
                 } 
                Else 
		 {
		  "$usersam is not Enabled for External Access Policy"
		#$lncobj | add-member -membertype NoteProperty -name "SamaccountName" -Value $usersam
 		#$lncobj | add-member -membertype NoteProperty -name "Access Level" -Value "Not Enabled"
		 }
            } 
     $resultarray += $lncobj
    }
###############################send logs via email ####################################

$resultarray | select "SamaccountName","Access Level" -uniq | Export-csv $output -notypeinformation

# Variable initializing to send mail
$TXTFile = $output
$subject = "Lync Policy Applied via AD group Log" 
$emailBody = "Lync Policy Applied via AD group Log"

# Code to Send Mail 
Send-MailMessage -SmtpServer $SMTPServer -From $emailFrom -To $emailTo -Subject $subject -Body $emailBody -Attachment $TXTFile

######################################################################################

$path = $dir 
 
Get-ChildItem -Path $path  | Where-Object {  
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force 

######################################################################################

stop-transcript

