﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	10/19/2016 12:30 PM
	 Created by:   	Diwakar Sharma
     	 Reviewed by:   Vikas Sukhija (http://msexchange.me)
	 Organization: 	
	 Filename:   Additional SMTP o365  	
	===========================================================================
	.DESCRIPTION
		This script will be used to add additional SMTP addtess for o365 hybrid setup.
        There are situation where Email policy is uncheked so this script can be utilized.
#>
################Add Snapin & Logs/ variables#########################
$Error.clear()
If ((Get-PSSnapin | where { $_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010" }) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}
$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/", "-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log = ".\logs" + "\" + "Ps_log_" + $date1 + "_" + $time + "_.log"
$report1 = (Get-Location).path + "\" + "Report" + "\" + "Report_Hybemail" + $date1 + "_" + $time + "_.csv"

$hybemaildom = "@domain.mail.onmicrosoft.com"
$collection = @()

$email1 = "VikasS@labtest.com"
$from = "EolemailFix@labtest.com"
$smtpserver = "smtpserver"

Start-Transcript -Path $log

#############get all mailboxes where policy is not applied#####

$AliasAll = Get-Mailbox -ResultSize Unlimited | Where { $_.EmailAddressPolicyEnabled -ne "True" } | select Alias,emailaddresses
$Error.clear()
Foreach ($Als in $AliasAll)
{
	Write-Host "Processing ..............."$Als.alias"" -ForegroundColor green
	$mcoll = "" | select Alias, hybemail, Status
	$AddSMTP = $Als.Alias + $hybemaildom
	$mcoll.Alias = $Als.Alias
	$mcoll.hybemail = $AddSMTP
    $AddSMTP
    $alladdreses = $Als.EmailAddresses | select -ExpandProperty addressstring
    if($alladdreses -contains $AddSMTP){
    $mcoll.Status = "already Present"
    }
    else{
    $Error.clear()
	Set-Mailbox $Als.Alias -EmailAddresses @{ add = $AddSMTP }
	if ($error)
	{
		$mcoll.Status = "Error"
		$Error.clear()
	}
	else
	{
		$mcoll.Status = "Success"
	}}
	$collection+=$mcoll
}
$collection | Export-Csv $report1 -NoTypeInformation
#############Send Report##############################
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
$msg.From = $from
$attach = new-object Net.Mail.Attachment($report1)
$msg.To.Add($email1)
$msg.Subject = "Exchange Online Emal Address Fix Report"
$msg.Body = "Exchange Online Emal Address Fix Report"
$msg.Attachments.Add($attach)
$smtp.Send($msg)
get-date
Stop-Transcript
################################################################