#########################################################################
#			Author: Vikas Sukhija
#			Reviewer:
#			date: 9/9/2016
#			Modified:						
#			Description: Run Netapp Reclaim commands
#########################################################################


$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/","-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = ".\Logs" + "\" + "Processed_PS_" + $date1 + "_" + $time + "_.log"

$log1 = ".\Logs" + "\" + "snapdrive_" + $date1 + "_" + $time + "_.log"

$log2 = ".\Logs" + "\" + "snapdrive_Spacereclaim_" + $date1 + "_" + $time + "_.log"

Start-Transcript -Path $logs

##############Import Netap module#######################

Import-Module SnapDrive

if($error){Write-host "Snapdrive module not imported Exit pls" -foregroundcolor Red
Exit}
else{
Write-host "Snapdrive module imported" -foregroundcolor green }

###################variables ########################

$dag1 = "DAGVG01"

$day = (get-date).dayofweek

$tm = (get-date).Hour

$day1 = "Monday"

$day2 = "Tuesday"

$day3 = "Wednesday"

$day4 = "Thursday"

$day5 = "Friday"

$day6 = "Saturday"

$day7 = "Sunday"

$tm1 = "5"

$tm2 = "11"

$tm3 = "17"

$tm4 =  "23"

$runtime1 = "320"
$timeout = $runtime1/30

$hostname = hostname

if($hostname -like "*$dag1*"){

$dagex= $dag1 -replace "VG" ,"EX"

$dagd1 = "Y:\" + $dagex + "_DB01"
$dagd2 = "Y:\" + $dagex + "_DB02"
$dagd3 = "Y:\" + $dagex + "_DB03"
$dagd4 = "Y:\" + $dagex + "_DB04"
$dagd5 = "Y:\" + $dagex + "_DB05"
$dagd6 = "Y:\" + $dagex + "_DB06"
$dagd7 = "Y:\" + $dagex + "_DB07"
$dagd8 = "Y:\" + $dagex + "_DB08"
$dagd9 = "Y:\" + $dagex + "_DB09"
$dagd10 = "Y:\" + $dagex + "_DB10"

$dagl1 = "Y:\" + $dagex + "_LOG01"
$dagl2 = "Y:\" + $dagex + "_LOG02"
$dagl3 = "Y:\" + $dagex + "_LOG03"
$dagl4 = "Y:\" + $dagex + "_LOG04"
$dagl5 = "Y:\" + $dagex + "_LOG05"
$dagl6 = "Y:\" + $dagex + "_LOG06"
$dagl7 = "Y:\" + $dagex + "_LOG07"
$dagl8 = "Y:\" + $dagex + "_LOG08"
$dagl9 = "Y:\" + $dagex + "_LOG09"
$dagl10 = "Y:\" + $dagex + "_LOG10"
}



#######################################################

if((($day -eq $day1) - ($day -eq $day3) -or ($day -eq $day5)) -and ($tm -eq $tm1)){

Write-host "Processing .....Snapdrive Commands on Databases" -foregroundcolor green

sdcli spacereclaimer analyze -d $dagd1 >> $log1 

Write-host "Space reclaimer analysis on $dagd1 " -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd1 -t $runtime1

Write-host "Space reclaimer Start on $dagd1 " -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagd2 >> $log1 

Write-host "Space reclaimer analysis on $dagd2 " -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd2 -t $runtime1

Write-host "Space reclaimer Start on $dagd1 " -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagd3 >> $log1 

Write-host "Space reclaimer analysis on $dagd3 " -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd3 -t $runtime1

Write-host "Space reclaimer Start on $dagd1 " -foregroundcolor blue

}

if((($day -eq $day1) - ($day -eq $day3) -or ($day -eq $day5)) -and ($tm -eq $tm2)){

Write-host "Processing .....Snapdrive Commands" -foregroundcolor green

sdcli spacereclaimer analyze -d $dagd4 >> $log1 

Write-host "Space reclaimer analysis on $dagd4 " -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd4 -t $runtime1

Write-host "Space reclaimer Start on $dagd4 " -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagd5 >> $log1 

Write-host "Space reclaimer analysis on $dagd5 " -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd5 -t $runtime1

Write-host "Space reclaimer Start on $dagd5 " -foregroundcolor blue


}


if((($day -eq $day1) - ($day -eq $day3) -or ($day -eq $day5)) -and ($tm -eq $tm3)){

Write-host "Processing .....Snapdrive Commands" -foregroundcolor green

sdcli spacereclaimer analyze -d $dagd6 >> $log1 

Write-host "Space reclaimer analysis on $dagd6 " -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd6 -t $runtime1

Write-host "Space reclaimer Start on $dagd6" -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagd7 >> $log1 

Write-host "Space reclaimer analysis on $dagd7 " -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd7 -t $runtime1

Write-host "Space reclaimer Start on $dagd7 " -foregroundcolor blue

}

if((($day -eq $day1) - ($day -eq $day3) -or ($day -eq $day5)) -and ($tm -eq $tm4)){

Write-host "Processing .....Snapdrive Commands" -foregroundcolor green

sdcli spacereclaimer analyze -d $dagd8 >> $log1 

Write-host "Space reclaimer analysis on $dagd8 " -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd8 -t $runtime1

Write-host "Space reclaimer Start on $dagd8 " -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagd9 >> $log1 

Write-host "Space reclaimer analysis on $dagd9 " -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd9 -t $runtime1

Write-host "Space reclaimer Start on $dagd9 " -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagd10 >> $log1 

Write-host "Space reclaimer analysis on $dagd10" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagd10 -t $runtime1

Write-host "Space reclaimer Start on $dagd10 " -foregroundcolor blue


}

######################LOG Vol#######################################


if((($day -eq $day2) - ($day -eq $day4) -or ($day -eq $day6) -or ($day -eq $day7)) -and ($tm -eq $tm1)){

sdcli spacereclaimer analyze -d $dagl1 >> $log1 

Write-host "Space reclaimer analysis on $dagl1" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl1 -t $runtime1

Write-host "Space reclaimer Start on $dagl1" -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagl2 >> $log1 

Write-host "Space reclaimer analysis on $dagl2" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl2 -t $runtime1

Write-host "Space reclaimer Start on $dagl2" -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagl3 >> $log1 

Write-host "Space reclaimer analysis on $dagl3" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl3 -t $runtime1

Write-host "Space reclaimer Start on $dagl3" -foregroundcolor blue


}

if((($day -eq $day2) - ($day -eq $day4) -or ($day -eq $day6) -or ($day -eq $day7)) -and ($tm -eq $tm2)){

Write-host "Processing .....Snapdrive Commands" -foregroundcolor green

sdcli spacereclaimer analyze -d $dagl4 >> $log1 

Write-host "Space reclaimer analysis on $dagl4" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl4 -t $runtime1

Write-host "Space reclaimer Start on $dagl4" -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagl5 >> $log1 

Write-host "Space reclaimer analysis on $dagl5" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl5 -t $runtime1

Write-host "Space reclaimer Start on $dagl5" -foregroundcolor blue


}


if((($day -eq $day2) - ($day -eq $day4) -or ($day -eq $day6) -or ($day -eq $day7)) -and ($tm -eq $tm3)){

Write-host "Processing .....Snapdrive Commands" -foregroundcolor green

sdcli spacereclaimer analyze -d $dagl6 >> $log1 

Write-host "Space reclaimer analysis on $dagl6" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl6 -t $runtime1

Write-host "Space reclaimer Start on $dagl6" -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagl7 >> $log1 

Write-host "Space reclaimer analysis on $dagl7" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl7 -t $runtime1

Write-host "Space reclaimer Start on $dagl7" -foregroundcolor blue

}


if((($day -eq $day2) - ($day -eq $day4) -or ($day -eq $day6) -or ($day -eq $day8)) -and ($tm -eq $tm4)){

Write-host "Processing .....Snapdrive Commands" -foregroundcolor green

sdcli spacereclaimer analyze -d $dagl8 >> $log1 

Write-host "Space reclaimer analysis on $dagl8" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl8 -t $runtime1

Write-host "Space reclaimer Start on $dagl8" -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagl9 >> $log1 

Write-host "Space reclaimer analysis on $dagl9" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl9 -t $runtime1

Write-host "Space reclaimer Start on $dagl9" -foregroundcolor blue

sdcli spacereclaimer analyze -d $dagl10 >> $log1 

Write-host "Space reclaimer analysis on $dagl10" -foregroundcolor magenta

sdcli spacereclaimer start -d $dagl10 -t $runtime1

Write-host "Space reclaimer Start on $dagl10" -foregroundcolor blue

}

$count=0

do{

sdcli spacereclaimer status >> $log2 
add-content $log2 "--------------------------------------------------------"
timeout 1800

$count = $count +1} While($count -lt $timeout)


Stop-Transcript

##############################################################





