######################################################################
#		Author: Vikas Sukhija (http://msexchange.me)
#		Reviewer:	
#		Date: 01/06/2016
#		Description: Using Troubleshoot-Databasespace.ps1 to 
#		generate email alerts to exchange Team( good for Non Scom
#               Enviornemnt)
######################################################################
######################ADD Exchange Shell##############################

If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}

#############Logs & Variables#####################

$dbthreshold = "30"
$logthreshold = "15"

$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/","-")

$time = get-date -format t
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")


$path = "C:\Scripts\Trobleshoot-Database"
$limit = (Get-Date).AddDays(-30)

$logs = "C:\Scripts\Trobleshoot-Database\logs" + "\" + "Processed_DB_" + $date1 + "_" + $time + "_.log"

$smtpserver = "smtpserver"
$from = "Monitoring@labtest.com"
$to = "Vsukhija@labtest.com"
$subj = "Database Script Execution Error"
$exscripts = "C:\Program Files\Microsoft\Exchange Server\V14\scripts\"

########Function for error email######

Function erremail($smtpserver,$from,$To,$subj) {

if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $from
#mail recipient
$msg.To.Add($to)
$msg.Subject = $subj
$msg.Body = $error
$smtp.Send($msg)
$error.clear()
       }
}
############################################################

#######Change to Exscripts####################

cd $exscripts

$collevents = @()

$servers = Get-ExchangeServer | Where{$_.ServerRole -like "*mailbox*"}

$servers | foreach-object{

$servername = $_.Name
$servername

$collevents = .\Troubleshoot-DatabaseSpace.ps1 -Server $servername -PercentEdbFreeSpaceThreshold $dbthreshold -PercentLogFreeSpaceThreshold $logthreshold -MonitoringContext

$collevents | foreach-object {

$eventid = $_.Eventid
$eventtype = $_.Eventtype
$eventmessage = $_.Eventmessage
$date = get-date
add-content $logs "$date $servername $eventid $eventmessage"

if(($eventid -ne "5100") -and ($eventid -ne "5101") -and ($eventid -ne "5102")){
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $from
#mail recipient
$msg.To.Add($to)
$msg.Subject = "Event Notification : OPEN CRITICAL : Datbase Disk Space $eventid"
$msg.Body = $eventmessage
$smtp.Send($msg)

	}
  }

}
#erremail $smtpserver $from $to $subj
############################################################
########################Recycle logs ##########################

Get-ChildItem -Path $path  | Where-Object {  
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force 