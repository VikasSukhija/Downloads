###################################################################
##           Script to check the status of machines              
##           Author: Vikas Sukhija                 		          
##           Date: 01-28-2016                     		  
##           Update:  Converted from VBscript
##https://gallery.technet.microsoft.com/scriptcenter/Ping-Machines-and-report-19d590ce          
###################################################################

$path = ".\results.xls"

$objExcel = new-object -comobject excel.application 

if (Test-Path $path) 
{ 
$objWorkbook = $objExcel.WorkBooks.Open($path) 
$objWorksheet = $objWorkbook.Worksheets.Item(1) 
}

else { 
$objWorkbook = $objExcel.Workbooks.Add() 
$objWorksheet = $objWorkbook.Worksheets.Item(1)
}

$objExcel.Visible = $True

#########Add Header####

$objWorksheet.Cells.Item(1, 1) = "MachineName"
$objWorksheet.Cells.Item(1, 2) = "Result"

$machines = gc .\machinelist.txt
$count = $machines.count

$row=2

$machines | foreach-object{
$ping=$null
$machine = $_
$ping = Test-Connection $machine -Count 1 -ea silentlycontinue

if($ping){

$objWorksheet.Cells.Item($row,1) = $machine
$objWorksheet.Cells.Item($row,2) = "UP"

$row++}
else {

$objWorksheet.Cells.Item($row,1) = $machine
$objWorksheet.Cells.Item($row,2) = "DOWN"

$row++}
}

# Format the excel
 
# To wrap the text           
$d = $objWorksheet.UsedRange 
$null = $d.EntireColumn.AutoFit()

##to set column width and cell alignment
$objWorksheet.Columns.Item(1).columnWidth = 24
$objWorksheet.Columns.Item(2).columnWidth = 24
$objWorksheet.Columns.HorizontalAlignment = -4131
$objWorksheet.rows.item(1).Font.Bold = $True 

##to apply filter
$headerRange = $objWorksheet.Range("a1","n1")
$headerRange.AutoFilter() | Out-Null
#################################################################


