##############################################################################
#			Author: Vikas SUkhija
#			Reviewer:
#			Date: 7/9/2015	
#			Description: Notify Access permissions to share owners
##############################################################################

#############################Logs & Variables#################################

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = ".\Logs" + "\" + "Powershell" + $date + "_" + $time + "_.txt"

new-item -path .\logs\tmpfile.txt -type file -force
$tmpfile = ".\logs\tmpfile.txt"

Start-Transcript -Path $logs 

$smtpserver = "smtpserver"
$from = "DoNotReply@labtest.com"
$errmail = "vikas.sukhija@labtest.com"

$dir= ".\logs"
$limit = (Get-Date).AddDays(-30)

$regex1="(Readwrite(.*)_RW)"
$regex2="(Readonly(.*)_RO)"


####################ADD Quest Shell###########################################

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles.ADManagement"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}


$data = import-csv .\inputfile.csv

foreach($i in  $data){

$share = $i.ShareName

$owner = $i.owner

$email1 = $owner

$access = get-acl $share


$sowner = $access.owner

$collaccess = $access.access


$collaccess | foreach {

$FileSystemRights = $_.FileSystemRights
$IdentityReference = $_.IdentityReference
$AccessControlType = $_.AccessControlType

Add-content $tmpfile "`r`n $IdentityReference --> $FileSystemRights --> $AccessControlType"

#######################Compare with RO & RW group##
###############################

if($IdentityReference -match $regex1){

[string]$getIdenRW = $IdentityReference 
$get_Rw = get-qadgroupmember $getIdenRW | select Name, DisplayName | out-string}

if($IdentityReference -match $regex2){
[string]$getIdenRO = $IdentityReference 
$get_RO = get-qadgroupmember $getIdenRO | select Name, DisplayName | out-string}

}


$gettmpfile = gc $tmpfile | out-string

$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpserver)
$msg.From = $from
#mail recipient
$msg.To.Add($email1)

$msg.Subject = "$share - Access Details"

#####################compose Message to be sent to owners##################
$msg.Body = @"

Dear Share Owner,

Please find below the list of persons who currently have access to the share drive mentioned in the subject of this mail.

The purpose of this mail is to review if these persons still need access to this share?

  -  If they do, there is no action required from your part
  -  If you feel somebody needs to be removed from this list, please "reply all" to this email including the list of name(s) who should be removed.


Thanks & Regards
Your IT Department

----------------------------------------------------------------

Bellow you will find a display of the Access Rights on your share drive :

Please notice that following groups are System Groups required for Backup and System access purpose:
 - "BUILTIN\Administrators"
 - "BUILTIN\Backup Operators"
 - "CREATOR OWNER"
 - "NT AUTHORITY\SYSTEM" 

----------------------------------------------------------------

$gettmpfile 

----------------------------------------------------------------

$getIdenRW

$get_Rw

-----------------------------------------------------------------

$getIdenRO

$get_RO


"@

$smtp.Send($msg)


}

######################Reccycle Logs###################################

$path = $dir 
 
Get-ChildItem -Path $path  | Where-Object {  
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force 

Stop-Transcript

#######################################################################