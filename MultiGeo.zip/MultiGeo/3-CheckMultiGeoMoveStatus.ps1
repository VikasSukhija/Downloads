﻿<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	1/28/2022
    Created by:   	Vikas Sukhija
    Organization: 	
    Filename:     	3-CheckMultiGeoMoveStatus.ps1
    ===========================================================================
    .DESCRIPTION
    This Script will add users to Certain group
    module: vsadmin and SPO
#>
[CmdletBinding()]
  param
  (
    $Org="techwizard",
    $UsersCSV = './Users.CSV'
  ) 
if(-not(Get-Module -ListAvailable -Name 'vsadmin')){Install-Module -Name 'vsadmin'}
Import-Module 'vsadmin'
#####################Load variables and log##########
$log = Write-Log -Name "MultiGeoMoveStatus-Log" -folder "logs" -Ext "log"
$Report = Write-Log -Name "MultiGeoMoveStatus-Report" -folder "Report" -Ext "CSV"
$collusers = @()
#############################################################
 Write-Log -Message "Start ................Script" -path $log
 Write-Log -Message "Get Crendetials for Admin ID" -path $log
if(Test-Path -Path ".\Password.xml"){
  Write-Log -Message "Password file Exists" -path $log
}else{
  Write-Log -Message "Generate password" -path $log
  $Credential = Get-Credential 
  $Credential | Export-Clixml ".\Password.xml"
}
#############################################################
$Credential = $null
$Credential = Import-Clixml ".\Password.xml"
########################Start Script##############################
Write-Log -Message "Start....................Script" -path $log
try{
  $data = Import-Csv $UsersCSV
  Write-Log -Message "Import...................CSV" -path $log
  LaunchSPO -orgName $Org -Credential $Credential
  Write-Log -Message "Connect to SPO" -path $log
}
catch{
  $exception = $_.Exception.Message
  Write-Log -Message $exception -path $log -Severity error
}

foreach($i in $data){
  $error.clear()
  $coll = "" | Select UserPrincipalName, MoveJobID, SourceDataLocation,DestinationDataLocation,TimeStamp,MoveState,ISValidPDL,HasODBInCurrentLocation, ISContentMoved, ErrorMessage,Siteid, MoveDirection,MoveJobPhase,MoveJobType, StartedDate, FinishedDate
  $getaduser = $upn = $null
  $upn = $i.UserPrincipalName
  $coll.UserPrincipalName = $upn
  $getaduser = get-aduser -filter{UserPrincipalName -eq $upn}
  if($getaduser){
    $getstate = Get-SPOUserAndContentMoveState -UserPrincipalName $upn -Verbose
    $coll.MoveJobID = $getstate.MoveJobID
    $coll.SourceDataLocation = $getstate.SourceDataLocation
    $coll.DestinationDataLocation = $getstate.DestinationDataLocation
    $coll.TimeStamp = $getstate.TimeStamp
    $coll.MoveState = $getstate.MoveState
    $coll.ISValidPDL = $getstate.ISValidPDL
    $coll.HasODBInCurrentLocation = $getstate.HasODBInCurrentLocation
    $coll.ISContentMoved = $getstate.ISContentMoved
    $coll.ErrorMessage = $getstate.ErrorMessage
    $coll.Siteid = $getstate.Siteid
    $coll.MoveDirection = $getstate.MoveDirection
    $coll.MoveJobPhase = $getstate.MoveJobPhase
    $coll.MoveJobType = $getstate.MoveJobType
    $coll.StartedDate = $getstate.StartedDate
    $coll.FinishedDate = $getstate.FinishedDate
  }
  else{
    $coll.MoveJobID = "Notfound"
    $coll.SourceDataLocation = "Notfound"
    $coll.DestinationDataLocation = "Notfound"
    $coll.TimeStamp = "Notfound"
    $coll.MoveState = "Notfound"
    $coll.ISValidPDL = "Notfound"
    $coll.HasODBInCurrentLocation = "Notfound"
    $coll.ISContentMoved = "Notfound"
    $coll.ErrorMessage = "Notfound"
    $coll.Siteid = "Notfound"
    $coll.MoveDirection = "Notfound"
    $coll.MoveJobPhase = "Notfound"
    $coll.MoveJobType = "Notfound"
    $coll.StartedDate = "Notfound"
    $coll.FinishedDate = "Notfound"  
    Write-Log -Message "$upn - Notfound" -path $log
  }
  $collusers+=$coll
  }
$collusers | Export-Csv $Report -NoTypeInformation
Write-Log -Message "CSV Report..........Generated" -path $log
Write-Log -Message "Script............Finished" -path $log
RemoveSPO
########################Script Finished####################################