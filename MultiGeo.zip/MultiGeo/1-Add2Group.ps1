﻿<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	1/28/2022
    Created by:   	Vikas Sukhija
    Organization: 	
    Filename:     	1-ADD2Group.ps1
    ===========================================================================
    .DESCRIPTION
    This Script will add users to Certain group
    module: vsadmin and AD
#>
[CmdletBinding()]
  param
  (
    $Group="Office365-MultiGeo-Accounts",
    $UsersCSV = './Users.CSV'
  ) 

if(-not(Get-Module -ListAvailable -Name 'vsadmin')){Install-Module -Name 'vsadmin'}
Import-Module 'vsadmin'
#####################Load variables and log##########
$log = Write-Log -Name "ADD2Group-Log" -folder "logs" -Ext "log"
$Report = Write-Log -Name "ADD2Group-Report" -folder "Report" -Ext "CSV"
$collusers = @()
########################Start Script##############################
Write-Log -Message "Start....................Script" -path $log
try{
  $data = Import-Csv $UsersCSV
  Write-Log -Message "Import...................CSV" -path $log
}
catch{
  $exception = $_.Exception.Message
  Write-Log -Message $exception -path $log -Severity error
}

foreach($i in $data){
  $error.clear()
  $coll = "" | Select UserPrincipalName, Status
  $getaduser = $upn = $null
  $upn = $i.UserPrincipalName
  $coll.UserPrincipalName = $upn
  $getaduser = get-aduser -filter{UserPrincipalName -eq $upn}
  if($getaduser){
    Add-ADGroupMember -Identity $Group -Members $getaduser.samaccountname
    if($error){$coll.Status = "Error"; Write-Log -Message "Error - ADDING $upn to  $Group" -path $log -Severity Error}
    Else{$coll.Status = "Success";Write-Log -Message "ADDED $upn to  $Group" -path $log}
  }
  else{
    $coll.Status = "UserNotFound"
    Write-Log -Message "$upn - Notfound" -path $log
  }
  $collusers+=$coll
  }
$collusers | Export-Csv $Report -NoTypeInformation
Write-Log -Message "CSV Report..........Generated" -path $log
Write-Log -Message "Script............Finished" -path $log
$wsh = New-Object -ComObject Wscript.Shell
$wsh.Popup("Wait For Replication Before Moving To Next STEP")
########################Script Finished####################################
