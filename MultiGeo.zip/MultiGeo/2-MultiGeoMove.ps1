﻿<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	1/28/2022
    Created by:   	Vikas Sukhija
    Organization: 	
    Filename:     	2-MultiGeoMove.ps1
    ===========================================================================
    .DESCRIPTION
    This Script will add users to Certain group
    module: vsadmin and SPO
#>
[CmdletBinding()]
  param
  (
    $Org="techwizard",
    $UsersCSV = './Users.CSV'
  ) 
if(-not(Get-Module -ListAvailable -Name 'vsadmin')){Install-Module -Name 'vsadmin'}
Import-Module 'vsadmin'
#####################Load variables and log##########
$log = Write-Log -Name "MultiGeoMove-Log" -folder "logs" -Ext "log"
$Report = Write-Log -Name "MultiGeoMove-Report" -folder "Report" -Ext "CSV"
$collusers = @()
#############################################################
 Write-Log -Message "Start ................Script" -path $log
 Write-Log -Message "Get Crendetials for Admin ID" -path $log
if(Test-Path -Path ".\Password.xml"){
  Write-Log -Message "Password file Exists" -path $log
}else{
  Write-Log -Message "Generate password" -path $log
  $Credential = Get-Credential 
  $Credential | Export-Clixml ".\Password.xml"
}
#############################################################
$Credential = $null
$Credential = Import-Clixml ".\Password.xml"
########################Start Script##############################
Write-Log -Message "Start....................Script" -path $log
try{
  $data = Import-Csv $UsersCSV
  Write-Log -Message "Import...................CSV" -path $log
  LaunchSPO -orgName $Org -Credential $Credential
  Write-Log -Message "Connect to SPO" -path $log
}
catch{
  $exception = $_.Exception.Message
  Write-Log -Message $exception -path $log -Severity error
}

foreach($i in $data){
  $error.clear()
  $coll = "" | Select UserPrincipalName, GEO, Status
  $getaduser = $upn = $null
  $upn = $i.UserPrincipalName
  $coll.UserPrincipalName = $upn
  $coll.GEO = $i.GEO
  $getaduser = get-aduser -filter{UserPrincipalName -eq $upn}
  if($getaduser){
    Start-SPOUserAndContentMove -UserPrincipalName $upn -DestinationDataLocation $i.GEO
    if($error){$coll.Status = "Error"; Write-Log -Message "Error - Starting Move for $upn" -path $log -Severity Error}
    Else{$coll.Status = "MoveSubmitted";Write-Log -Message "Started Move for $upn" -path $log}
  }
  else{
    $coll.Status = "UserNotFound"
    Write-Log -Message "$upn - Notfound" -path $log
  }
  $collusers+=$coll
  }
$collusers | Export-Csv $Report -NoTypeInformation
Write-Log -Message "CSV Report..........Generated" -path $log
Write-Log -Message "Script............Finished" -path $log
RemoveSPO
########################Script Finished####################################
