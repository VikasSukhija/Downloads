<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	10/22/2021
    Created by:   	Vikas Sukhija
    Organization: 	
    Filename:     	PasswordExpiryAlert.ps1
    ===========================================================================
    .DESCRIPTION
    This Script get the user whose password has expired and and send them alert
#>
[CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true)]
    $daystoexpiryleft,
    [Parameter(Mandatory = $true)]
    [ValidateSet($true,$false)]
    $SendAlert,
    [Parameter(Mandatory = $true)]
    $smtpserver,
    [Parameter(Mandatory = $true)]
    $from,
    [Parameter(Mandatory = $true)]
    $erroremail,
    [string]
    $emailbodyfilepath = './EmailBody.html',
    $countofchanges = '1000',
    $logrecyclelimit = '60'
  ) 
#####################Load variables and log##########
$log = Write-Log -Name "PasswordExpiryAlert-Log" -folder "logs" -Ext "log"
$ObjFilter = "(&(objectClass=user)(objectCategory=person)(!useraccountcontrol:1.2.840.113556.1.4.803:=2)(mail=*))"
########################Start Script##############################
Write-Log -Message "Start....................Script" -path $log
$collusers = @()
try
{
  Write-Log -Message "Fetch all Enabled Email Users with Password Expiry Status True" -path $log
  $collusers = Get-ADUser -LDAPFilter $ObjFilter -properties passwordexpired,mail,Passwordneverexpires,"msDS-UserPasswordExpiryTimeComputed" | Select-Object DistinguishedName, GivenName,SamAccountName, PasswordExpired,Passwordneverexpires, UserPrincipalName,mail,@{Name="PasswordExpiryDate";Expression={[datetime]::FromFileTime($_."msDS-UserPasswordExpiryTimeComputed")}}
  $collusers = $collusers.where{($_.passwordexpired -eq $false) -and ($_.Passwordneverexpires -eq $false) -and ($_.Passwordexpirydate -le $(get-date (get-date).AddDays($daystoexpiryleft)))} | Select-Object DistinguishedName, GivenName,SamAccountName, PasswordExpired,Passwordneverexpires, UserPrincipalName,mail,PasswordExpiryDate,@{n="daysleft";e={($_.PasswordExpiryDate - $(get-date)).days}}
  Write-Log -Message "Fetched users with PassWord Expiry Date $($collusers.count)" -path $log
}
catch
{
  $exception = $_.Exception.Message
  Write-Log -Message $exception -path $log -Severity error
  Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Error - PasswordExpiryAlert" -Body $exception
  exit
}

#######Actionable users and send expiry alert mail#########################
if(($collusers.count -gt "0")-and ($collusers.count -lt  $countofchanges)){
  foreach($user in $collusers)
  {
    $sam = $user.SamAccountName
    Write-Log -message "Samaccountname - $sam Given Name - $($user.GivenName) Expiry Date - $($user.Passwordexpirydate) - daysleft - $($user.daysleft) " -path $log
    if($SendAlert -eq $true){
      try{
        $emailbody = Get-Content -Path $emailbodyfilepath -raw
        $getdate = get-date ($user.PasswordExpiryDate) -Format MM/dd/yyyy
        Send-MailMessage -SmtpServer $smtpserver -From $from -To $user.mail -Subject "Action Required Change your password before it expires in $($user.daysleft) days" -BodyAsHtml ($emailbody -f $($user.GivenName),$($user.daysleft),$getdate)
      }
      catch{
        $exception = $_.Exception.Message
        Write-Log -Message $exception -path $log -Severity error
        Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Error - PasswordExpiryAlert" -Body $exception
      }
    }
  }
}
elseif($collusers.count  -gt $countofchanges){
   Write-Log -Message "Count is $($collusers.count)greater than $countofchanges" -path $log -Severity error
   Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Error Count is $($collusers.count)greater than $countofchanges - PasswordExpiryAlert" -Body "Error Count is $($collusers.count)greater than $countofchanges - PasswordExpiryAlert"
   exit;
 }
########################Recycle reports & logs#############################
Set-Recyclelogs -foldername "logs" -limit $logrecyclelimit -confirm:$false
Write-Log -Message "Script............Finished" -path $log
Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Log - FixPHSPasswordExpiry" -Body "Log - PasswordExpiryAlert" -Attachments $log
########################Script Finished####################################

