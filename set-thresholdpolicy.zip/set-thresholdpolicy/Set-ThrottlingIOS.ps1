#################################################################################
#             Author: Vikas Sukhija
#	      Date:  04/07/2014 
#             Description: APply throtlling Policy if not already applied
#             to set of users
#################################################################################

###############################LOgs##############################################

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)

$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")


$log1 = ".\Logs" + "\" + "Throtlling1_" + $date + $time +"_.log"
$log2 = ".\Logs" + "\" + "Throtlling2_" + $date + $time +"_.log"

#############Add Exchange 2010 Shell & define variabbles##########################

If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)

{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}

$throttlingpolicy = "iosusers"
$smtpServer = "SMTPServer"
$from= "DoNotReply@labtest.com"
$to= "VikasSukhija@labtest.com"

####################Load users from the text file#################################

$users = get-content .\users.txt

$users | foreach-object {

$getthrotstatus = get-mailbox $_ | select throttlingpolicy

if($getthrotstatus -ne $null)
	{

	if ($getthrotstatus.ThrottlingPolicy -like $throttlingpolicy)
		{ 
		write-host "User $_ is already part of IOSusers Policy" -foregroundcolor Green
		Add-content $log1 "User $_ is already part of $throttlingpolicy Policy"
		}
	else

		{

		set-mailbox -identity $_ -throttlingpolicy $throttlingpolicy
		write-host "User $_ added to $throttlingpolicy Policy" -foregroundcolor Blue
		Add-content $log2 "User $_ added to $throttlingpolicy Policy"
		}
         }

else
	{
	write-host "Null value"  -foregroundcolor Red
	}	

}



################################################################################

if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $from
#mail recipient
$msg.To.Add($to)
$msg.Subject = "Throttling Policy error"
$msg.Body = $error
$smtp.Send($msg)
       }
  else

      {
    Write-host "no errors till now"
      }

###################################################################################