#############################################################################
#       Author: Vikas Sukhija
#       Date: 06/12/2012
#       Description: Extract the quota for all users
#############################################################################

# Add Exchange Shell...

If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)
{ Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010}

#format Date

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)

$output = ".\" + "QuotaReport_" + $date + "_.csv"


#create a collection to hold results(dynamic array)

$Collection = @()
Get-Mailbox -ResultSize Unlimited | foreach-object{
$st = get-mailboxstatistics $_.identity
$TotalSize = $st.TotalItemSize.Value.ToMB()
$user = get-user $_.identity


 
$mbxr = �� | select DisplayName, RecipientType,TotalItemSizeinMB, QuotaStatus,
UseDatabaseQuotaDefaults,IssueWarningQuota,ProhibitSendQuota,ProhibitSendReceiveQuota, 
Itemcount, Email,ServerName,Company,Hidden, OrganizationalUnit,
RecipientTypeDetails,UserAccountControl
 
$mbxr.DisplayName = $_.DisplayName
$mbxr.RecipientType = $user.RecipientType 
$mbxr.TotalItemSizeinMB = $TotalSize
$mbxr.QuotaStatus = $st.StorageLimitStatus
$mbxr.UseDatabaseQuotaDefaults = $_.UseDatabaseQuotaDefaults
$mbxr.IssueWarningQuota = $_.IssueWarningQuota.Value
$mbxr.ProhibitSendQuota = $_.ProhibitSendQuota.Value
$mbxr.ProhibitSendReceiveQuota = $_.ProhibitSendReceiveQuota.Value
$mbxr.Itemcount = $st.Itemcount
$mbxr.Email = $_.PrimarySmtpAddress
$mbxr.ServerName = $st.ServerName
$mbxr.Company = $user.Company
$mbxr.Hidden = $_.HiddenFromAddressListsEnabled
$mbxr.RecipientTypeDetails = $_.RecipientTypeDetails
$mbxr.OrganizationalUnit = $_.OrganizationalUnit
$mbxr.UserAccountControl = $_.UserAccountControl
$Collection += $mbxr
}
 
#export the collection to csv , change the path accordingly

$Collection | export-csv $output

#######################################################################################
