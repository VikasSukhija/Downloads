##################################################################################
#       Author:Vikas Sukhija
#       Reviewer: 
#       Date: 09/30/2014
#       Description: Monitor vault cache
##################################################################################

$date = get-date -format d
# replace \ by -
$time = get-date -format t
$month = get-date 
$month1 = $month.month
$year1 = $month.year

$date = $date.ToString().Replace(�/�, �-�)

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log1 = ".\Logs" + "\" + "JNLCount_" + $date + "_" + $time + "_.log"

################Define Variables############
$email1 = "Vikassukhija@labtest.com"
$fromadd = "VaultCacheMonitoring@labtest.com"
$smtpserver ="smtpserver"

$date1 = get-date
$date2 = get-date -Hour 0 -Minute 0 -Second 0

$EvMbx = @("Server1","Server2","Server3","Server4","Server5") # Define the servers## 
###############that needs folder monitoring############################

##########################################################################

$EvMbx | foreach-object {

$path = "\\$_\e$\Cache\VCBuilds"  ##### Define Remote path in our case folder to be monitored#########
##############on the server was in E: drive (e:\cache\vcbuilds)###################

$items=Get-ChildItem $path  | where {($_.LastWriteTime -le $date1) -and ($_.LastWriteTime -gt $date2)}

if($items -eq $null)
{
Write-host "Vcbuild folder is not updating for $_ server EV services need restart" -foregroundcolor red

#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "WARNING : Vault cache Sync not working server $_ :ACtion: Restart Vault Enterprise Vault Admin Service"
$smtp.Send($msg)

}
else 
{
Write-host "$_ Count: "$items.count"" -foregroundcolor Green
}

}

##################################################################################
###############################################error reprting######################
if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "vault cache rebuild Mon Script error"
$msg.Body = $error
$smtp.Send($msg)
       }
  else

      {
    Write-host "no errors till now" -foregroundcolor Green
      }
######################################################################################