<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	6/8/2022 1:46 PM
    Created by:   	Vikas Sukhija
    Organization: 	
    Filename:     	syncazkeyvault2onprem.ps1
    ===========================================================================
    .DESCRIPTION
       Sync Password from AzKeyvault
#>
##########################Load variables & Logs####################
$log = Write-Log -Name "syncazkeyvault2onprem" -folder logs -Ext log
New-FolderCreation -foldername temp
$VaultName = "AZ-TEST-Vault"
$configfile = "C:\Secured\Config.ini"
$logrecyclelimit = 60
$currentdatetime = (get-date).AddHours(-1).ToUniversalTime()
##########Start Script main##############################
Write-Log -message "Start ......... Script" -path $log
Write-Log -Message "Get Crendetials for Admin ID" -path $log
if(Test-Path -Path ".\Password.xml"){
  Write-Log -Message "Password file Exists" -path $log
}else{
  Write-Log -Message "Generate password" -path $log
  $Credential = Get-Credential 
  $Credential | Export-Clixml ".\Password.xml"
}
###################################################################
$Credential = $null
$Credential = Import-Clixml ".\Password.xml"
write-log -message "Start.............Script" -path $log
Connect-AzAccount -Credential $Credential
function Sync-azkeyvault
{
Param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String]$Sections,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String]$SecretName,
    [String]$PasswordKey='Password',
    $tags = $false
  )
try
  { 
  if($tags -eq $false){
    $getkeyvaultsecret=$null
    #write-log -message "Connected to Azure to retrieve Secrets from vault" -path $log
    $checkkeyvaultsecret = Get-AzKeyVaultSecret -VaultName $VaultName -Name $SecretName
    if($checkkeyvaultsecret.Updated -ge $currentdatetime){
    $getkeyvaultsecret = Get-AzKeyVaultSecret -VaultName $VaultName -Name $SecretName -AsPlainText
    #write-log -message "Secret Retrieved - $SecretName" -path $log
    if($getkeyvaultsecret){ # now encrypt the secret
    Save-EncryptedPassword -password $getkeyvaultsecret -path ".\temp\$SecretName.txt"
    $getencpassword = Get-Content ".\temp\$SecretName.txt"
    write-log -message "Setting secret $SecretName in INI file" -path $log
    $ini = $null
    $ini = Set-IniContent -FilePath $configfile -Sections $Sections -NameValuePairs @{$PasswordKey=$getencpassword}
    $ini | Out-IniFile $configfile -Pretty -Force -Encoding 'ASCII'
    Remove-Item -Path ".\temp\$SecretName.txt"
    }
    }
    else{
    write-log -message "No change in Secret - $SecretName" -path $log
    }
    }
   if($tags -eq $true){
    $getkeyvaultsecret=$null
    #write-log -message "Connected to Azure to retrieve Tags from vault" -path $log
    $checkkeyvaultsecret = Get-AzKeyVaultSecret -VaultName $VaultName -Name $SecretName
    if($checkkeyvaultsecret.Updated -ge $currentdatetime){
    $getkeyvaultsecret = Get-AzKeyVaultSecret -VaultName $VaultName -Name $SecretName
    #write-log -message "Tags Retrieved - $SecretName" -path $log
    if($getkeyvaultsecret){ # now encrypt the secret
    write-log -message "Setting Tags $SecretName in INI file" -path $log
    $ini = $null
    $ini = Set-IniContent -FilePath $configfile -Sections $Sections -NameValuePairs $getkeyvaultsecret.Tags
    $ini | Out-IniFile $configfile -Pretty -Force -Encoding 'ASCII'
    }
    }
    else{
    write-log -message "No change in tags - $SecretName" -path $log
    }

    }
  }
  catch
  {
    write-log -message "$($_.Exception.Message)" -path $log -Severity Error
    break
  }
  } #Sync-azkeyvault

Sync-azkeyvault -Sections 'ServiceAccount' -SecretName 'AutomationAccount' -tags $true
Sync-azkeyvault -Sections 'ServiceAccount' -SecretName 'AutomationAccount' -PasswordKey 'Password'

Disconnect-AzAccount
########################Recycle reports & logs##############
Set-Recyclelogs -foldername "logs" -limit $logrecyclelimit -Confirm:$false
write-log -message "Script.........Finished" -path $log
##############################recycle azure folder###########################################
$hostanme = hostname
$getcurrentuser = whoami
$secureAzDirectory = "Users\$($getcurrentuser.Split("\")[1])\.Azure"
Set-Recyclelogs -ComputerName $hostanme -DriveName c -folderpath $secureAzDirectory -limit 0 -Verbose -Confirm:$false #empty azure folder
##############################################################################################