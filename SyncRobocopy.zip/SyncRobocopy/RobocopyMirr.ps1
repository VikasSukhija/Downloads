################################################################
# 			Author: Vikas Sukhija (http://msexchange.me)
#			Date: 02/05/2016
#			Update:
#			Desc: Sync directories
#
################################################################

$date = get-date -format d
# replace \ by -
$time = get-date -format t
$month = get-date 
$month1 = $month.month
$year1 = $month.year


$date = $date.ToString().Replace(�/�, �-�)

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = ".\Logs" + "\" + "Powershell" + $date + "_" + $time + "_.log"

$regex = "(.*)\\"

$path = ".\logs\"
$limit = (Get-Date).AddDays(-30) #for log recycling

start-transcript -Path $logs

$data = import-csv .\sd.csv

foreach($dt in $data){

$source = $dt.source
$destination = $dt.destination

$rblogs = $source -replace $regex

write-host "Robocopy started for source $source and destionation $destination" -foregroundcolor yellow

start-process powershell ".\rcpy.bat $source $destination $rblogs"

timeout 60


write-host "Robocopy Process for source $source and destionation $destination invoked" -foregroundcolor green

}

########################Recycle logs ######################################

Get-ChildItem -Path $path  | Where-Object {  
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force 


Stop-transcript

##################################################################


