######################################################################
#             Author: Vikas Sukhija
#             Date: 08/20/2014
#             Description: Conver the structured text to csv 
#             example:- exchange search and delete logs
#####################################################################

Param(
  
$textlogfile = $(Read-Host "enter the name of structured text file")

)

$collection=@()


#########trim the  white spaces lines from the structured text########

(gc $textlogfile) | ? {$_.trim() -ne "" } | set-content .\output1.txt

$content = Get-Content .\output1.txt

######Calculate the number of structured fields, in this case its 9, so $i=$i+9

for($i=0;$i -lt $content.length;$i=$i+9)

{

$DisplayName = $content[$i+2]
$Disp=$DisplayName.split(":")[1].trim()

$Success = $content[$i+5]
$Succep=$Success.split(":")[1].trim()

$ResultItemsCount = $content[$i+7]
$Resc=$ResultItemsCount.split(":")[1].trim()

$ResultItemsSize = $content[$i+8]
$Resirep=$ResultItemsSize.split(":")[1].trim()

$coll = "" | select DisplayName,Success,ResultItemsCount,ResultItemsSize

$coll.DisplayName = $Disp
$coll.Success = $Succep
$coll.ResultItemsCount = $Resc
$coll.ResultItemsSize = $Resirep
$collection +=$coll

}

$collection | export-csv .\output.csv -notypeinformation

##########################################################################