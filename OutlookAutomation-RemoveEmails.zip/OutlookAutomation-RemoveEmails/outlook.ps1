#####################################################################################
# 			Author: Vikas Sukhija
# 			Date:- 11/10/2014
#                       Description:- Delete EnterPriseVault Shortcuts
#                       Prerequisites :- Powershell/Outlook
#####################################################################################

###############################Logs##################################################
$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log1 = ".\Logs" + "\" + "Processed_1" + $date + "_.log"
$log2 = ".\Logs" + "\" + "Processed_2" + $date + "_.log"


$logs = ".\Logs" + "\" + "Powershell" + $date + "_" + $time + "_.txt"

$messageclass = "IPM.Note.EnterpriseVault.ShortCut"

#########################Creating custom Button######################################
function button ($title,$mailbx,$TF) {

[void][System.Reflection.Assembly]::LoadWithPartialName( "System.Windows.Forms") 
[void][System.Reflection.Assembly]::LoadWithPartialName( "Microsoft.VisualBasic") 

    $form = New-Object "System.Windows.Forms.Form";
    $form.Width = 500;
    $form.Height = 150;
    $form.Text = $title;
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen;
    
    $textLabel1 = New-Object "System.Windows.Forms.Label";
    $textLabel1.Left = 25;
    $textLabel1.Top = 15;

    $textLabel1.Text = $mailbx;

    $textLabel3 = New-Object "System.Windows.Forms.Label";
    $textLabel3.Left = 25;
    $textLabel3.Top = 65;
 
    $textLabel3.Text = $TF;
    
    $textBox1 = New-Object "System.Windows.Forms.TextBox";
    $textBox1.Left = 150;
    $textBox1.Top = 10;
    $textBox1.width = 200;    

    $textBox3 = New-Object "System.Windows.Forms.TextBox";
    $textBox3.Left = 150;
    $textBox3.Top = 65;
    $textBox3.width = 200;
    
    $defaultValue = ""
    $textBox1.Text = $defaultValue;
    $textBox3.Text = $defaultValue;
    
    $button = New-Object "System.Windows.Forms.Button";
    $button.Left = 360;
    $button.Top = 65;
    $button.Width = 100;
    $button.Text = "Ok";
    
    $eventHandler = [System.EventHandler]{
    $textBox1.Text;
    $textBox3.Text;
    $form.Close();};

    $button.Add_Click($eventHandler) ;
    
    $form.Controls.Add($button);
    $form.Controls.Add($textLabel1);
    $form.Controls.Add($textLabel3);
    $form.Controls.Add($textBox1);
    $form.Controls.Add($textBox3);
    $ret = $form.ShowDialog();
    return  $textBox1.Text, $textBox3.Text
}

$return= button "Enter Folders" "Enter mailbox" "Target Folder"

#############################################################################


#Start-Transcript -Path $logs 

$mbx = $return[0]  
$tfold = $return[1]

Write-host "Mailbox is $mbx" -foregroundcolor Green
Write-host "Target folder $tfold" -foregroundcolor Green

$date1 = get-date
add-content $log2 "$date1 - Script Started" 
######################Get All folders##############################################

$logN = ".\Logs" + "\" + $mbx + "_.log"
if(test-path $logN)
{
Del $logN
}

function Get-MailboxFolder($folder)
{
"{0}" -f $folder.name

foreach ($f in $folder.folders)
{
Get-MailboxFolder $f
}
}

$ol = new-object -com Outlook.Application
$ns = $ol.GetNamespace("MAPI")
$mailbox = $ns.stores | where {$_.DisplayName -like $mbx}
$mailbox.GetRootFolder().folders | foreach { $fl= Get-MailboxFolder $_
ADD-Content $logN $fl}


Function RemoveMessages ($mbx,$fold,$tfold)
{
#############################outlook Call#############################################

$outlook = new-object -com outlook.application;
$ns = $outlook.GetNameSpace("MAPI");
$inbox = $ns.Folders.Item($mbx).folders.Item($fold)
$messages = $inbox.items
$totalemail = $messages.count
write-host "Total Messages to process $totalemail"  -foregroundcolor green
$date1 = get-date
add-content $log2 "$date1 - Total Messages to process $totalemail" 
$messcount = $messages.count
$countprocessed = 0
$countprocessed1 = 0
#########################Find messages with Class ##########################

foreach($message in $messages){
$mclass = $message.MessageClass
write-host $mclass -foregroundcolor blue
if($mclass -like $messageclass)
		{
                $countprocessed = $countprocessed +1 
		}		
}

write-host "Total Messages to be processed $countprocessed"  -foregroundcolor Green
$date1 = get-date
add-content $log2 "$date1 - Total Messages to be processed $countprocessed" 

################################Move Messages#################################
$countprocessed1 = $countprocessed

while($countprocessed1 -ne "0")
{
$countprocessed1=0
$outlook = new-object -com outlook.application;
$ns = $outlook.GetNameSpace("MAPI");
$inbox = $ns.Folders.Item($mbx).folders.Item($fold)
$messages = $inbox.items
$totalemail = $messages.count
write-host "Total Messages to process $totalemail"  -foregroundcolor green

############################################################################
foreach($message in $messages){
$mclass = $message.MessageClass
write-host $mclass -foregroundcolor blue
if($mclass -like $messageclass)
		{
                $MoveTarget = $ns.Folders.Item($mbx).folders.Item($tfold)
        	[void]$message.Move($MoveTarget)
                $countprocessed1 = $countprocessed1 +1
		}		
}
write-host "Total Messages processed $countprocessed1"  -foregroundcolor Red


}

}

get-content $logN | foreach{if($_ -notlike "Deleted Items"){ RemoveMessages $mbx $_ $tfold}}

#Stop-Transcript
#####################################END######################################