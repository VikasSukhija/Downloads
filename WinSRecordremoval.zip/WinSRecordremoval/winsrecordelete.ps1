###############################################################################
#                         Author: Vikas Sukhija
#                         Reviewer:
#                         Date: 01/17/2015
#                         Description: To remove record from Multiple wins
#                         Servers input from Text file
#
#                         WINS Record Types
###############################################################################
#computer_name[00h]
#Registered by the Workstation Service on the WINS client. In general, this name is called the NetBIOS computer name.
#
#computer_name[03h]
#Registered by the Messenger service on the WINS client. This service is used by the client when sending and receiving messages. This name is usually appended to both #the NetBIOS computer name for the WINS client computer and the name of the user currently logged on to that computer when sending messages on the network.

#computer_name[06h]
#Registered by the Routing and Remote Access service on the WINS client (when the service is started).

#domain_name[1Bh]
#Registered by each Windows NT Server 4.0 domain controller running as the domain master browser. This name record is used to allow remote browsing of domains. When a #WINS server is queried for this name, a WINS server returns the IP address of the computer that registered this name.

#computer_name[1Fh]
#Registered by the Network Dynamic Data Exchange (NetDDE) services. This appears only if the NetDDE services are started on the computer.

#computer_name[20h]
#Registered by the Server service on the WINS client. This service is used to provide points of service to the WINS client to provide sharing of its files on the #network.

#computer_name[21h]
#Registered by the RAS Client service on the WINS client (when the RAS Client is started).

#computer_name[BEh]
#Registered by the Network Monitoring Agent Service and appearing only if the service is started on the WINS client computer. If the computer name has fewer than 15 #characters, the remaining character spaces are padded with plus (+) symbols.

#computer_name[BFh]
#Registered by the Network Monitoring Utility (included with Microsoft Systems Management Server). If the computer name has fewer than 15 characters, the remaining #character spaces are padded with plus (+) symbols.

#username[03h]
#User names for currently logged-on users are registered in the WINS database. Each user name is registered by the Server service component so that users can receive #any net send commands sent to the user name. If more than one user logs on with the same user name, only the first computer logged on with that name registers the #name.

#domain_name[00h]
#Registered by the Workstation Service so that it can receive browser broadcasts from LAN Manager-based computers.

#domain_name[1Ch]
#Registered for use by the domain controllers within the domain. These contain up to 25 IP addresses.

#domain_name[1Dh]
#Registered for use by master browsers, of which there is only one per subnet. Backup browsers use this name to communicate with the master browser, retrieving the #list of available servers from the master browser. WINS servers always return a positive registration response for domain_name[1D], even though the WINS server does #not register this name in its database. Therefore, when a WINS server is queried for the domain_name[1D], the WINS server returns a negative response, which forces #the client to broadcast for name resolution.

#group_name[1Eh]
#A normal group name. Any computers configured to be network browsers can broadcast to this name, and listen for broadcasts to this name, to elect a master browser. A #statically mapped group name uses this name to register itself on the network. When a WINS server receives a name query for a name ending with [1E], the WINS server #always returns the network broadcast address for the local network of the requesting client. The client can then use this address to broadcast to the group members. #These broadcasts are for the local subnet and should not cross routers.

#group_name[20h]
#A special group name called the Internet Group is registered with WINS servers to identify groups of computers for administrative purposes. For example, "printersg" #could be a registered group name used to identify an administrative group of print servers.

#--__MSBROWSE__[01h]
#Registered by the master browser for each subnet. When a WINS server receives a name query for this name, the WINS server always returns the network broadcast address #for local network of the requesting client.
############################################################################### 
###############################Logs & Variables##############################
$days = (get-date).adddays(-60)
$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t
$month = get-date 
$month1 = $month.month
$year1 = $month.year
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")


$log1 = ".\Logs" + "\" + "winsdelrec_" + $date + "_" + $time + "_.log"
$log2 = ".\Logs" + "\" + "winsdelrec_Error" + $date + "_" + $time + "_.log"


#################get wins server & record to be deleted##########################
$servers = gc .\winsserver.txt

$servers | foreach-object{

$winsserver = $_

write-host "processing wins server........ $winsserver" -foregroundcolor blue

$records = import-csv .\recordsdel.csv 
foreach ($i in $records) {
$name = $i.name
$endchar = $i.endchar
$endchar1 = $endchar.Replace("h","")
$ip = $i.ipaddress
$delrec=netsh wins server $winsserver delete name Name=$name EndChar=$endchar1 IP={$ip} 
add-type -AssemblyName microsoft.visualbasic 
$cmp = "microsoft.visualbasic.strings" -as [type]

	if($cmp::instr($delrec, "Command completed successfully"))
	{
	$date = get-date
	ADD-content   $log1   "$date $ip $endchar1 record delted from Wins server $winsserver"
	Write-host "$date $ip $endchar1 record delted from Wins server $winsserver" -foreground green
	}
        else
        {
	$date = get-date
	ADD-content   $log2   "$date server $winsserver $delrec"
        Write-host "$date server $winsserver error $delrec" -foreground red
        }

    }
}

##########################################################################################
####################################powershell eror#######################################

if ($error -ne $null)
      {
  $date = get-date
  ADD-content   $log2   "$date $error"

       }

##########################################################################################