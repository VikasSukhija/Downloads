##################################################################################
#			Author: Manhur Mannan
#			Reviewer: Vikas Sukhija
#			Date: 03/07/2015
#			Description: Take WSP Backups & retention
##################################################################################
#############################ADD SHell############################################
If ((Get-PSSnapin | where {$_.Name -match "Microsoft.SharePoint"}) -eq $null)
{
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}

###################Define Variables#####################

$Dname = ((get-date).AddDays(0).toString('yyyyMMdd')) 
$dirName = "WSPBackup_$Dname"
$dir= "E:\Scripts\SharepointBackup\backup\WSP"
$limit = (Get-Date).AddDays(-60)


#####################Solution Extraction#################

new-item -path $dir -name $dirName -type directory


Write-Host Exporting solutions to $dirName 


foreach ($solution in Get-SPSolution) 
{ 
    $id = $Solution.SolutionID 
    $title = $Solution.Name 
    $filename = $Solution.SolutionFile.Name
    Write-Host "Exporting �$title� to �\$filename" -nonewline 
    try { 
        $solution.SolutionFile.SaveAs("$dir\$dirName\$filename") 
        Write-Host " � done" -foreground green 
    } 
    catch 
    { 
        Write-Host " � error : $_" -foreground red 
    } 
}
 
##########################Retention##########################
$path = $dir

Get-ChildItem -Path $path  | Where-Object { 
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force

##############################################################