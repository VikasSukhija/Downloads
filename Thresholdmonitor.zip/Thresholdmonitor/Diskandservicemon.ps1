﻿##################################################################
#          Author:  vikas Sukhija
#          Date:  07/30/2013
#          Description:- Monitordisksapce & services from servers
#################################################################
#######################Define Logs #############################
$days = (get-date).adddays(-60)
$date = get-date -format d
$date = $date.ToString().Replace(“/”, “-”)
$time = get-date -format t
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")
$ouput = ".\logs\" + "Monitor" + $date + $time + "_.csv"
$ouput1 = ".\logs\" + "services" + $date + $time + "_.log"
$str = $null
$str = "ServerName,Drive,TotalSize(GB),FreeSpace(GB),Free Space(%)" -join ','

Add-content $ouput $str
#######################define variables###################################

$smtpserver = "smtpservername"
$From = "donotreply@labtest.com"


##########################################################################

$data = Import-csv ".\config.csv" 

foreach ($i in $data)

{

$servername = $i.ServerName
$monitordrive  = $i.InstallPath
$email = $i.email
$threshold = $i.threshold
$services = $i.services
$svc = "*" + $services + "*"

$serstatus = Get-Service -ComputerName $servername | where{$_.DisplayName -like $svc }



foreach($service in $serstatus)

{  


if ($service.status -like "Stopped")

  {
$Servicename = $service.DisplayName
$message = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpserver)
$message.From = $From
$message.To.Add($email)
$message.IsBodyHtml = $False
$message.Subject = "Warning Service $Servicename on $servername is stopped"
$smtp.Send($message)

add-content $ouput1 "Warning Service $Servicename on $servername is stopped"
}

}

$colDisks = get-wmiobject Win32_LogicalDisk -computername $servername -Filter "DriveType = 3" 
foreach ($objdisk in $colDisks)
{

if($objDisk.DeviceID -like $monitordrive)
  {
$CompName = $servername.ToUpper()
$DriveLetter = $objDisk.DeviceID
$TotalSize = "{0:N0}" -f ($objDisk.Size/1GB)
$Freespace = "{0:N0}" -f ($objDisk.FreeSpace/1GB)
$FreePercentage = "{0:P0}" -f ([double]$objDisk.FreeSpace/[double]$objDisk.Size)

$Con_string = $null
$Con_string = $CompName,$DriveLetter,$TotalSize,$Freespace,$FreePercentage -join ',' 

Add-content $ouput $Con_string

  if ($FreePercentage -le $threshold)

{

$message = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpserver)
$message.From = $From
$message.To.Add($email)
$message.IsBodyHtml = $False
$message.Subject = "Warning Space for $CompName is less then $threshold "
$smtp.Send($message)

}

}
  

}
}

############################################################################


