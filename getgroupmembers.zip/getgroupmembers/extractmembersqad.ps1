################################################################################## 
#       Author: Vikas Sukhija 
#       Date: 06/31/2013 
#       Description: Extract group members recursevely 
################################################################################### 

# Add Quest Shell...

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}

# read name of group

$Group = Read-Host "Enter the group name" 

$members = Get-QADGroupMember $Group -Indirect |  select Name, Type | Export-Csv .\members.csv

###################################################################################






