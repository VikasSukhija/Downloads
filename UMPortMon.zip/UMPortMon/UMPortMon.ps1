#########################################################################
#			Author: Vikas Sukhija
#			Date: 4/4/2016
#			Reviewer:
#			Desc: Monitor Port for unified messsaging & 
#			send alert if it changes
#			Refrence: http://blogs.technet.com/b/wsnetdoc/archive/2011/11/07/windows-powershell-script-test-port.aspx
#########################################################################
#--------For Log Files--------------

$date = get-date -format d 
$date = $date.ToString().Replace(�/�, �-�) 
$time = get-date -format t 
$time = $time.ToString().Replace(":", "-") 
$time = $time.ToString().Replace(" ", "") 

$logs = ".\Logs" + "\" + "UMporttest" + $date + "_" + $time + "_.log"

$smtpServer = "smtpserver"
$fromadd = "SystemsMonitoring@labtest.com"

$email1 = "Sukhija1@labtest.com"

$port1 = "5065"
$port2 = "5067"


Start-Transcript -Path $logs 

################LOad Test Port Function######################

write-host "Loading test port function" -foregroundcolor green

. .\test-port.ps1

$arrsrvpo = @()

$umsrvs = gc .\UMsrvsWport.txt

$umsrvs | foreach-object {

$srv = $_.split(":")[0]
$port = $_.split(":")[1]


#####################Test ports now####################

if($port1 -eq $port) {
Write-host "$port1 is the current port on server $srv" -foregroundcolor green

$tport1 = Test-Port -computer $srv -port $port1 -tcp
$tport2 = Test-Port -computer $srv -port $port2 -tcp

if(($tport1.open -like $false) -and ($tport2.open -like $true)){

$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "Open Critical: Port $port1 is not open on $srv - Pls change it in avaya session manager to $port2"
$msg.Body = "Port $port1 is not open on $srv - Pls change it in avaya session manager to $port2"
$smtp.Send($msg)

#################update ports file##################
$arrsrvpo += $srv + ":" + $port2

	}
else{
$arrsrvpo += $srv + ":" + $port1}

}

if($port2 -eq $port) {

Write-host "$port2 is the current port on server $srv" -foregroundcolor green

$tport1 = Test-Port -computer $srv -port $port1 -tcp
$tport2 = Test-Port -computer $srv -port $port2 -tcp

if(($tport2.open -like $false) -and ($tport1.open -like $true)){

$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)

$msg.Subject = "Open Critical: Port $port2 is not open on $srv - Pls change it in avaya session manager to $port1"
$msg.Body = "Port $port2 is not open on $srv - Pls change it in avaya session manager to $port1"
$smtp.Send($msg)

#################update ports file##################

$arrsrvpo += $srv + ":" + $port1
	}
else{
$arrsrvpo += $srv + ":" + $port2}

}

}

$arrsrvpo > ".\UMsrvsWport.txt"

stop-transcript

##############################################################

