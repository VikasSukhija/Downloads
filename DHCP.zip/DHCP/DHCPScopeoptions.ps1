##################################################################
#              Author: Vikas SUkhija (http://msexchange.me)
#              Description: Find DHCP SCope Options Values 
#              for particular scope option
#              Date: 12/17/2014
#	       Modified: 12/6/2015
#	       Update: Included subnet.subnetname,primarydns,secondarydns,
#	               Total Ips, Free Ips, Leaseperiod
####################################################################
############Import Module & define variables##################

Import-module .\Microsoft.DHCP.PowerShell.Admin.psm1

$collection =@()
$idval = "6"  ### DNS Scope Option

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
               $time = $time.ToString().Replace(" ", "")
$output = ".\" + "DHCPScopeOptions_" + $date + "_" + $time + "_.csv"


##########################################
$srv = Show-DHCPServers
$servers= $srv | select server
$servers | foreach{ 
$server = $_.server
Write-host "Processing Server...............$server" -foregroundcolor Green
$scope=Get-DHCPScope -server  $server
#$scope
$scp = $scope | where {$_.state -like "Active"} | Select Name,Address,IPRanges,Lease
#$scp

	$scp | foreach{ 
	$addr = $_.Address
	$opt = Get-DHCPScope -server $server -scope $_.Address 
	$sts = Get-DHCPStatistics -Server $server | Select -expandproperty ScopeStatistics | where{$_.scope -like $addr} | select TotalAddresses,Usedaddresses
        $optscope = $opt | Select -expandproperty options | where{$_.optionId -like $idval} | select Values 

$coll = �� | select ServerName,Name,Subnet,DNSserver,IPRange,TotalIPs,FreeIps,LeasePeriod

$Tot = $sts.TotalAddresses
$used = $sts.UsedAddresses
$free = [int]$Tot -[int]$used
$coll.ServerName = $server
$coll.Name = $_.Name
$coll.Subnet = $_.Address
$coll.DNSserver = $optscope.values
$coll.IPrange = $_.IPRanges
$coll.TotalIPs = $sts.TotalAddresses
$coll.FreeIps = $free
$coll.LeasePeriod = $_.Lease

$collection += $coll


        }

}

$collection | select ServerName,Name,Subnet,@{Name=�DNSserver�;Expression={$_.DNSserver}},@{Name=�IPRange�;Expression={$_.IPRange}},TotalIPs,FreeIps,Leaseperiod | export-csv $output -notypeinfo

#######################################################################


