########################################################################
#			Author: Vikas Sukhija
#			Reviewer: 
#			Modfied: 07/08/1015
#			Description: SID --> Userid conversion
#
#
########################################################################

Import-Module ActiveDirectory

$getsid = gc .\sids.txt


$collection = @()

$getsid | foreach-object{

$user = get-aduser $_

$coll = "" | select SID , UserID


$coll.SID = $_
$coll.UserID = $user.name

$collection += $coll

}

$collection | export-csv .\SID2UID.csv -notypeinfo

#######################################################################