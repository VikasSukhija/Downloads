########################################################################
#       Author: Vikas Sukhija
#       Date: 10/10/2013
#       Description: Analyze OAB errors
########################################################################
#######################Define Parameters################################

Param (

$eventtype,
$computerName,
$eventid

)

#########################Add Exchange Shell#############################

If ((Get-PSSnapin | where {$_.Name -match "Exchange.Management"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin
}

#########################Add log files#################################

$date = get-date -format d
$date = $date.tostring()
$date = $date.replace("/","-")

$log1 = ".\logs\" + "EventAnalysis" + $date + "_.log"
$log2 = ".\logs\" + "OABissues" + $date + "_.log"


#######################get event id & split the message #################
$date = get-date 
$date = $date.ToShortDateString()

$collevent = Get-EventLog -LogName $eventtype -ComputerName $computerName `
 -after $date | Where {$_.Eventid -eq $eventid}

$time = get-date -format t
$collevent.count
$eventcount = $collevent.count
Add-content $log1 "$time - Number of Events - $eventcount"

foreach($event in $collevent)  {

$evn = $event.Message

$evn1 = $evn -replace "OALGen will skip user entry "

$evn2 = $evn1 -replace "in address","="

$evn3 = $evn2.split("=")

$evn4= $evn3[0].trim()

$str = $evn4.substring(1,$evn4.length-2)

write-host $str
$time = get-date -format t

add-content $log1 "$time - User mentioned in eventid - $str"

$mailbox = get-mailbox  $str

if($mailbox -ne $null)

{
$time = get-date -format t
$alias = $mailbox.alias

Write-host "$time - $alias mailbox has issues with OAB"
add-content $log1 "$time - $alias mailbox has issues with OAB"
add-content $log2 "$alias mailbox has issues with OAB"

}
}
#####################Send email to Messaging Team######################

$email = "Vikas.Sukhija@labtest.com"
$from = "donotreply@labtest.com"
$subject = "Oab Errors to be fixed"
$body = get-content $log2 | out-string
$smtpserver ="smtpserver"

$message = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpserver)

$message.From = $from
$message.To.Add($email)
$message.body = $body
$message.subject = $subject

$smtp.Send($message)

########################################################################