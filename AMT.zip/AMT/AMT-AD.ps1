##################################################################################
#       Author:Vikas SUkhija
#       
#       Date: 07/30/2014
#       Description: Disable accounts on the basis of netwrok id
#
##################################################################################

$date = get-date -format d
# replace \ by -
$time = get-date -format t
$month = get-date 
$month1 = $month.month
$year1 = $month.year


$date = $date.ToString().Replace(�/�, �-�)

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log1 = ".\Logs" + "\" + "Accountdisabled_" + $date + "_.log"
$log2 = ".\Logs" + "\" + "Accountalreadydisabled_" + $date +"_.log"



If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles.ADManagement"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}



$file = ".\terminated.txt"


get-content $file | foreach-object{

$statusofuser = get-qaduser $_
$userid = $statusofuser.Name

if($statusofuser.AccountIsDisabled -like $false)

{
Write-host "$userid is not disabled so it will be disabled"
Add-content $log1 "$userid is not disabled so it will be disabled"
Disable-QADUser -Identity $userid

}

Else
{
Write-host "$userid is already disabled"
Add-content $log2 "$userid is already disabled"

}

}

###################################################################################