####################################################################
#       Author: Vikas Sukhija
#       Date: 03/17/2015
#       Description: Check for CCMexe handle counts
#	Restart if High handle count is detected
####################################################################

$fromadd = �SystemsMonitoring@labtest.com�
$email1=�Vikas@labtest.com�
$email2="sukhija@labtest.com"
$smtpServer="smtp.labtest.com"

$process = "CcmExec"
$handlelimit = "6000"


$server_list=@("Server01",
"Server02",
"Server03",
"Server04",
"Server05",
"Server06",
"Server07")

####################################################################

$server_list | foreach-object {
$host1 = $_
$data = @()
$handles = Get-Process -Name $process -ComputerName $_

$handlecount = $handles.handles


if($handlecount -ge$handlelimit)
 {
Write-host "Handle count $handlecount for $process is above limit $handlelimit" -foregroundcolor Red
Write-host "Restart $process on server $_" -foregroundcolor Green
	
Restart-Service -InputObject $(Get-Service -ComputerName $_ -Name $process)


#########################send email if any error occurs#######################

if ($error -ne $null)
      {

$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.To.Add($email2)
$msg.Subject = "Auto restart error for service $process for High handle utilization on  $host1"
$msg.Body = $error
$smtp.Send($msg)
       }

else
      {

$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.To.Add($email2)
$msg.Subject = "Auto restart successful for service $process High handle utilization on  $host1"
$msg.Body = "Service $process  has been restarted on $host1"
$smtp.Send($msg)

}

#############################################################################

}

Else

{
Write-host "Handle count $handlecount for $process is below limit $handlelimit on server $host1" -foregroundcolor Green

}
}

##############################################################################

