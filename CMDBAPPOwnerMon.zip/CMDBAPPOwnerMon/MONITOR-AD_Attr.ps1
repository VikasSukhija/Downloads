﻿########################################################################################################
#           Refrence: http://www.lazywinadmin.com/2013/10/powershell-monitor-and-report-active.html
#           Modified by: Vikas Sukhija so that it can monitor AD attributes instead of Group membership
#           Date:- 05/18/2014
#           Description:- This script will Track changes to users AD attributes
#                
#########################################################################################################  
  
        # Monitor the following Users
        $users =  get-content .\Sids.txt
        # The report is saved locally 
        $ScriptPath = (Split-Path ((Get-Variable MyInvocation).Value).MyCommand.Path) 
        $DateFormat = Get-Date -Format "yyyyMMdd_HHmmss" 

        # Email information
        $Emailfrom   = "CMDBCHGMonitor@labtest.com" 
        $Emailto   = "AmitKumar@labtest.com"
	$Emailbcc ="vikassukhija@labtest.com" 
        $email1 = "vikassukhija@labtest.com"
        $EmailServer  = "smtpserver" 
  
        # Quest Active Directory Snapin 
        If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles.ADManagement"}) -eq $null)
           {
  		Add-PSSnapin Quest.ActiveRoles.ADManagement
	   }
        
    

FOREACH ($item in $users){

            # Let's get the Current state
            $UserName = Get-Qaduser $item | Select-Object Name,DisplayName,Department,Manager,DN,Title,l,sid
            $usrcsv =  $UserName.sid
            $usrname = $UserName.Name

            $EmailSubject = "PS MONITORING - $usrname Attributes Change" 
   
            # Store the user attributes in this file 
            $StateFile = ".\datastore\$($UserName.domain.name)_$($usrcsv)-Attributes.csv" 
            $ADCFile = ".\datastore\$($UserName.domain.name)_$($usrcsv)-ADCAttributes.csv"

            $UserName | Export-csv $ADCFile -NoTypeInformation -Encoding Unicode
   
            # If the file doesn't exist, create one

            If (!(Test-Path $StateFile)){  
                $UserName | Export-csv $StateFile -NoTypeInformation -Encoding Unicode
                }

   
          # Now get current Attributes and start comparing it to the last lot we recorded 
            
       $Changes =  Compare-Object $(Import-Csv $ADCFile) $(Import-Csv $StateFile) -property Name,DisplayName,Department,Manager,DN,Title,l | 
                Select-Object Name,DisplayName,Department,Manager,DN,Title,l, @{n='State';e={If ($_.SideIndicator -eq "=>"){"Previous State" } Else { "Current State" }
                                  }
                    }
	    $Changes
  
            # If we have some changes, mail them to $Email 
            If ($Changes) {  
                $body = $($Changes | Format-List | Out-String) 
                $msg = new-object Net.Mail.MailMessage
                $smtp = new-object Net.Mail.SmtpClient($EmailServer)
                $msg.From = $Emailfrom
	        $msg.To.Add($emailTo)
 		$msg.bcc.Add($Emailbcc)
	        $msg.Subject = $EmailSubject
                $msg.Body = $body
                $smtp.Send($msg)
                } 
            #Save current state to the csv 
            $UserName | Export-csv $StateFile -NoTypeInformation -Encoding Unicode
        }
    
    

##########################end region script################

if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($EmailServer)

#Mail sender
$msg.From = $Emailfrom
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "CMDB attribute script Monitor Error"
$msg.Body = $error
$smtp.Send($msg)
$error.clear()
       }
  else

      {
    Write-host "no errors till now"

      }
###############################################################