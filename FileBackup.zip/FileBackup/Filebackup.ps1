###############################################################################
#		This script  will copy file & reatin it for 30 days
#		Author: Vikas Sukhija
# 		Date:- 05/11/2015
#		Modified:- 05/23/2015
###########################Variables#########################################

$Dname = ((get-date).AddDays(0).toString('yyyyMMdd'))
$dirName = "FileBackup_$Dname" 
$dir= "C:\Scripts\FileBackup\Backup"
$limit = (Get-Date).AddDays(-30) #for Retention

$Filepath = "\\NetworkPath\Share"
$filename = "File.txt"

$copyfile = $Filepath + "\" + $filename
$destination = $dir + "\" + $dirName + "\" + $filename

##########################Backup###########################################

new-item -path $dir -name $dirName -type directory


try { 
    
 Copy-item $copyfile $destination
    
    } 
    catch  
    {  
        Write-Host " � error : $_" -foreground red  
    }  

###########################Recycle##########################################

$path = $dir 
 
Get-ChildItem -Path $path  | Where-Object {  
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force 

##############################################################################