##################################################################################
#       Author:Vikas Sukhija
#       Reviewer: 
#       Date: 09/02/2014
#       Description: Monitor Jopurnal Mailboxes
##################################################################################

$date = get-date -format d
# replace \ by -
$time = get-date -format t
$month = get-date 
$month1 = $month.month
$year1 = $month.year

$date = $date.ToString().Replace(�/�, �-�)

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log1 = ".\Logs" + "\" + "JNLCount_" + $date + "_" + $time + "_.log"


$email1 = "Vikas@labtest.com"
$from = "Systems.Monitoring@labtest.com"
$smtpserver ="smtp.labtest.com"


$JNLMbx = @("Journal Archive01","Journal Archive02","Journal Archive03","Journal Archive04",
"Journal Archive05","Journal Archive MP01","Journal Archive MP02","Journal Archive MP03",
"Journal Archive MP04","Journal Archive MP05","Journal Archive MP04","Journal Archive MP05")

##############ADD Exchange Shell ################################################

If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}

$JNLMbx | foreach-object {

$itemc = (Get-MailboxStatistics $_).itemcount

if($itemc -gt "15000")
   {
	Write-host "Count for $_ is $itemc" -foregroundcolor Red
	Add-content $log1 "Count for $_ is $itemc"
        $subject = "Event Notification : OPEN CRITICAL : Count for $_ is $itemc"
	$message = new-object Net.Mail.MailMessage
	$smtp = new-object Net.Mail.SmtpClient($smtpserver)
	$message.From = $from
	$message.To.Add($email1)
	$message.subject = $subject
        $smtp.Send($message)

   }
else
   {

   Write-host "Count for $_ is $itemc" -foregroundcolor Green
   Add-content $log1 "Count for $_ is $itemc"
   
   }

}

##################################################################################