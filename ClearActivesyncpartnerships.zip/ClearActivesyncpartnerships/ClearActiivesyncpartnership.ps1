########################################################################################
#		This script  will Clear Activesync Partnerships that are 
#                older specified days
# 
#		Author: Vikas Sukhija
# 		Date:- 01/7/2015
#
########################################################################################
#Start-Transcript

If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}

#format Date

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)

$days = (get-date).adddays(-30)

$output = ".\logs\" + "Clearpartnership" + $date + "_.txt"

$casm = get-casmailbox -resultsize unlimited | where {$_.HasActiveSyncDevicePartnership -eq $true}


$casm | foreach-object{
$user = get-user $_.name
$devices = Get-ActiveSyncDeviceStatistics -Mailbox $_.Identity | Where-Object {$_.LastSuccessSync -le $days}

if($devices -ne $null)
{
$devices | foreach{
$deviicemod = $_.DeviceModel
$usrname = $user.name

Write-host  "processing....$usrname....Device....$deviicemod" -foreground green

Add-content $output "processing....$usrname....Device....$deviicemod"

Remove-ActiveSyncDevice ([string]$_.Guid) -confirm:$false
}
}
}

#Stop-Transcript
#############################################################################################