﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	1/6/2017 10:46 AM
	 Created by:   	Vikas Sukhija (http://syscloudpro.com)
	 Organization: 	
	 Filename:     	O365GrpWrtBack.ps1
	===========================================================================
	.DESCRIPTION
		This Script will writeback the Office 365 Groups as Mailcontacts
        to onpremise enviornment so that email routing can happen from onpremise 
        Users to Office365 Groups
#>
##############Load Functions & modules#################
$Error.clear()
. .\LoadFunctions.ps1

If ((Get-PSSnapin | where { $_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010" }) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}

LaunchEOL -user "EolAdmin@domain.com" -Encrypted "01000000d"
if ($error) { ProgressBar -title "Error loading Functions" -timer 10; exit }

#########Variables and Logs #########
$log = Write-Log -Name "Transcript_o365group", "o365_group_log" -Ext log -folder logs
$report = Write-Log -Name "Report_o365groups", "Report_Contacts" -Ext csv -folder report
$hybmaildomain = "@domain.mail.onmicrosoft.com"
$Collection = @()
$o365groupsOU = "domain.com/o365Groups"
$countofchanges = "10"

$email1 = "VikasS@labtest.com"
$from = "o365GroupWriteBack@labtest.com"
$smtpserver = "smtpserver"

Start-Transcript -Path $log[0]
#######Fetch all office 365 groups####
try
{
	$o365groups = Get-EOLUnifiedGroup -ResultSize:unlimited | select Alias, DisplayName, Guid, EmailAddresses, PrimarySmtpAddress, RequireSenderAuthenticationEnabled, AccessType, ManagedBy, ManagedByDetails -ErrorAction Stop
}
catch
{
	$_
	$exception = $_.Exception.Message
	$date = get-date
	Add-Content $log[1] "$date - Error Fetching all Unified groups"
	Add-Content $log[1] $exception
	Send-Email -From $from -To $email1 -subject "O365 group writeback Error fetching Groups" -smtpserver $smtpserver -body $exception
	break
}
############Fetch All Mail Contacts####
try
{
	$o365onpremContacts = Get-MailContact -OrganizationalUnit $o365groupsOU -ResultSize:unlimited | select Alias, DisplayName, CustomAttribute1, EmailAddresses, PrimarySmtpAddress, RequireSenderAuthenticationEnabled -ErrorAction Stop
}
catch
{
	$_
	$exception = $_.Exception.Message
	$date = get-date
	Add-Content $log[1] "$date - Error Fetching all Unified groups"
	Add-Content $log[1] $exception
	Send-Email -From $from -To $email1 -subject "O365 group writeback Error fetching Contacts" -smtpserver $smtpserver -body $exception
	break
}

if ($o365onpremContacts)
{
	try
	{
		######################Find Additions and Deletions###########
		$cmpo365groups = $o365groups | select Alias, guid
		$cmpo365onpremContacts = $o365onpremContacts | select Alias, @{ n = 'guid'; e = { $_.customattribute1 } }
		
		$Changes = Compare-Object $cmpo365groups $cmpo365onpremContacts -property guid |
		Select-Object guid, @{
			n = 'State'; e = {
				If ($_.SideIndicator -eq "=>") { "Delete" }
				elseif ($_.SideIndicator -eq "<=") { "ADD" }
				else { "Ignore" }
			}
		}
		if ($changes)
		{
			$Changes | Export-Csv $report[0] -NoTypeInformation
		}
	}
	catch
	{
		$_
		$exception = $_.Exception.Message
		$date = get-date
		Add-Content $log[1] "$date - Error Finding Changes"
		Add-Content $log[1] $exception
		Send-Email -From $from -To $email1 -subject "O365 group writeback Error Finding Changes" -smtpserver $smtpserver -body $exception
		break
	}

####Process Changes#########
	if ($changes)
	{
		if ($Changes.count -ge $countofchanges)
		{
			Write-Host "Exit as Changes are more than $countofchanges"
			ProgressBar -Title "Exit as Changes are more than $countofchanges" -Timer 10
			Send-Email -From $from -To $email1 -subject "O365 group writeback Exit - Changes are more than $countofchanges" -smtpserver $smtpserver
			Exit
		}
		else
		{
			$Changes | ForEach-Object{
				$uniqueid = $_.guid
				$getgrp = $o365groups | where{ $_.guid -eq $uniqueid }
				$getmailcontact = $o365onpremContacts | where{ $_.customattribute1 -eq $uniqueid }
				$alscontact = $getmailcontact.Alias
				$Als = $getgrp.Alias
				$Disp = $getgrp.DisplayName
				$hybemail = $Als + $hybmaildomain
				$umeamil = $getgrp.emailaddresses
				$prim = $getgrp.primarysmtpaddress
				$sendout = $getgrp.RequireSenderAuthenticationEnabled
				$mcoll = "" | select Alias, DisplayName, guid, PrimarySmtp, Status
				if ($_.state -eq "ADD")
				{
					####ADD the mail.onmicrosft address to Unified group/create Contact####
					Try
					{
						if ($umeamil -contains "smtp:$hybemail")
						{
							
							New-MailContact -Name $Disp -Alias $Als -ExternalEmailAddress $hybemail -OrganizationalUnit $o365groupsOU
							ProgressBar -Title "Creating Mail contact $Disp" -Timer 10
							while (!(Get-MailContact $Als -ErrorAction SilentlyContinue))
							{
								ProgressBar -Title "Creating Mail contact $Disp" -Timer 10
							}
							Set-MailContact -Identity $Als -RequireSenderAuthenticationEnabled:$sendout -customattribute1:$uniqueid
							$chckpem = (get-mailcontact $als).emailaddresses | Select -ExpandProperty addressstring
							if ($chckpem -contains $prim)
							{
								Write-Host "Primary $prim Address is alredy Present in $Als" -ForegroundColor Green
							}
							else
							{
								Write-Host "Primary $prim Address will be added to $Als" -ForegroundColor Green
								Set-MailContact -Identity $Als -EmailAddresses @{ add = $prim }
							}
						}
						else
						{
							set-eolunifiedgroup -identity $Als -EmailAddresses @{ add = $hybemail }
							New-MailContact -Name $Disp -Alias $Als -ExternalEmailAddress $hybemail -OrganizationalUnit $o365groupsOU
							ProgressBar -Title "Creating Mail contact $Disp" -Timer 10
							while (!(Get-MailContact $Als -ErrorAction SilentlyContinue))
							{
								ProgressBar -Title "Creating Mail contact $Disp" -Timer 10
							}
							Set-MailContact -Identity $Als -RequireSenderAuthenticationEnabled:$sendout -customattribute1:$uniqueid
							$chckpem = (get-mailcontact $als).emailaddresses | Select -ExpandProperty addressstring
							if ($chckpem -contains $prim)
							{
								Write-Host "Primary $prim Address is alredy Present in $Als" -ForegroundColor Green
							}
							else
							{
								Write-Host "Primary $prim Address will be added to $Als" -ForegroundColor Green
								Set-MailContact -Identity $Als -EmailAddresses @{ add = $prim }
							}
						}
						$mcoll.Alias = $als
						$mcoll.DisplayName = $disp
						$mcoll.guid = $uniqueid
						$mcoll.primarysmtp = $prim
						$mcoll.status = "Created"
					}
					catch
					{
						$exception = $_.Exception.Message
						$date = get-date
						Add-Content $log[1] "$date - Exception occured Processing $Disp"
						Add-Content $log[1] $exception
						Send-Email -From $from -To $email1 -subject "O365 group writeback Exception occured Processing $Disp" -smtpserver $smtpserver -body $exception
						$mcoll.Alias = $als
						$mcoll.DisplayName = $disp
						$mcoll.guid = $uniqueid
						$mcoll.primarysmtp = $prim
						$mcoll.status = "Error"
					}
					
				}
				if ($_.state -eq "Delete")
				{
					try
					{
						Remove-MailContact -Identity $alscontact -Confirm:$false
						$mcoll.Alias = $alscontact
						$mcoll.DisplayName = $getmailcontact.DisplayName
						$mcoll.guid = $uniqueid
						$mcoll.primarysmtp = $getmailcontact.PrimarySMTPAddress
						$mcoll.status = "Removed"
						ProgressBar -Title "Removing Mail contact $alscontact" -Timer 10
					}
					catch
					{
						$exception = $_.Exception.Message
						$date = get-date
						Add-Content $log[1] "$date - Exception occured deleting $alscontact"
						Add-Content $log[1] $exception
						Send-Email -From $from -To $email1 -subject "O365 group writeback Exception occured deleting $alscontact" -smtpserver $smtpserver -body $exception
						$mcoll.Alias = $alscontact
						$mcoll.DisplayName = $getmailcontact.DisplayName
						$mcoll.guid = $uniqueid
						$mcoll.primarysmtp = $getmailcontact.PrimarySMTPAddress
						$mcoll.status = "Error"
					}
				}
				$Collection += $mcoll
			}
		}
	}
	if ($Collection)
	{
		$Collection | Export-Csv $report[1] -NoTypeInformation
		Send-Email -From $from -To $email1 -subject "O365 group writeback Report" -smtpserver $smtpserver -attachment $report[1]
	}
}
else
{
	Write-Host "All Contacts will be Created" -ForegroundColor Green
	try
	{
		$o365groups | ForEach-Object{
			$Disp = $_.DisplayName
			$Als = $_.Alias
			$hybemail = $Als + $hybmaildomain
			$uniqueid = $_.guid
			$sendout = $_.RequireSenderAuthenticationEnabled
			$prim = $_.primarysmtpaddress
			$umeamil = $_.emailaddresses
			if ($umeamil -notcontains "smtp:$hybemail")
			{
				set-eolunifiedgroup -identity $Als -EmailAddresses @{ add = $hybemail }
			}
			New-MailContact -Name $Disp -Alias $Als -ExternalEmailAddress $hybemail -OrganizationalUnit $o365groupsOU
			while (!(Get-MailContact $Als -ErrorAction SilentlyContinue))
			{
				ProgressBar -Title "Creating Mail contact $Disp" -Timer 10
			}
			Set-MailContact -Identity $Als -RequireSenderAuthenticationEnabled:$sendout -customattribute1:$uniqueid
			$chckpem = (get-mailcontact $als).emailaddresses | Select -ExpandProperty addressstring
			if ($chckpem -contains $prim)
			{
				Write-Host "Primary $prim Address is alredy Present in $Als" -ForegroundColor Green
			}
			else
			{
				Write-Host "Primary $prim Address will be added to $Als" -ForegroundColor Green
				Set-MailContact -Identity $Als -EmailAddresses @{ add = $prim }
			}
		}
		
	}
	catch
	{
		$_
		$date = get-date
		Add-Content $log[1] "$date - Error Creating All Contacts"
		Add-Content $log[1] $exception
		Send-Email -From $from -To $email1 -subject "O365 group writeback Error Creating All Contacts" -smtpserver $smtpserver -body $exception
	}
	
}
RemoveEOL
Stop-Transcript
#############################################################
