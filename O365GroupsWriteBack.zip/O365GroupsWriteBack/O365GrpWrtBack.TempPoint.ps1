﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.3.131
	 Created on:   	1/6/2017 10:46 AM
	 Created by:   	SUKHIJV
	 Organization: 	
	 Filename:     	O365GrpWrtBack.ps1
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
