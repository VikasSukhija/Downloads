﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	1/6/2017 10:52 AM
	 Created by:   	Vikas Sukhija
	 Organization: 	
	 Filename:     	LoadFunctions.ps1
	===========================================================================
	.DESCRIPTION
		Load Functions to be used inside other scripts, in this case all functions
        will be loaded to O365 groups Write back script
#>
function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}
################Email Function#####################

function Send-Email
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		$From,
		[Parameter(Mandatory = $true)]
		[array]$To,
		[array]$bcc,
		[array]$cc,
		$body,
		$subject,
		$attachment,
		[Parameter(Mandatory = $true)]
		$smtpserver
	)
	
	$message = new-object System.Net.Mail.MailMessage
	$message.From = $from
	if ($To -ne $null)
	{
		$To | ForEach-Object{
			$to1 = $_
			$to1
			$message.To.Add($to1)
		}
	}
	if ($cc -ne $null)
	{
		$cc | ForEach-Object{
			$cc1 = $_
			$cc1
			$message.CC.Add($cc1)
		}
	}
	if ($bcc -ne $null)
	{
		$bcc | ForEach-Object{
			$bcc1 = $_
			$bcc1
			$message.bcc.Add($bcc1)
		}
	}
	$message.IsBodyHtml = $True
	if ($subject -ne $null)
	{
		$message.Subject = $Subject
	}
	if ($attachment -ne $null)
	{
		$attach = new-object Net.Mail.Attachment($attachment)
		$message.Attachments.Add($attach)
	}
	if ($body -ne $null)
	{
		$message.body = $body
	}
	$smtp = new-object Net.Mail.SmtpClient($smtpserver)
	$smtp.Send($message)
}
function ProgressBar
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		$Title,
		[Parameter(Mandatory = $true)]
		[int]$Timer
	)
	
	For ($i = 1; $i -le $Timer; $i++)
	{
		Start-Sleep 1;
		Write-Progress -Activity $Title -status "$i" -percentComplete ($i /10 * 100)
	}
}

function LaunchEOL
{
	param
	(
		[Parameter(Mandatory = $true)]
		[string]$User,
		[Parameter(Mandatory = $true)]
		$Encrypted
	)
	
	$password = ConvertTo-SecureString -string $Encrypted
	$Cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $user, $password
	$UserCredential = $Cred
	
	$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
	
	Import-PSSession $Session -Prefix "EOL" -AllowClobber
}



Function RemoveEOL
{
	
	$Session = Get-PSSession | where { $_.ComputerName -like "outlook.office365.com" }
	Remove-PSSession $Session
	
}
