##############################################################################
#			Author: AMit Mittal
#			Reviewer: Vikas Sukhija
#			Date: 08/10/2015
#			Modified: 08/19/2015
#			Desc: get access details on Calenadr confrernce rooms
##############################################################################

$ConPermission = @()

$rooms = get-mailbox -RecipientTypeDetails roommailbox -resultsize unlimited

Foreach ($Mailbox in $rooms)
{

$perm = Get-mailboxfolderpermission -identity ($Mailbox.alias+':\calendar')
$userN = $null
$userC = $null
$userA = $null
$userPA = $null
$userNEA = $null
$userR =  $null
$userE = $null
$userPE = $null
$userO = $null
$userAO = $null
$userL = $null

   foreach ($acc in $perm){
       $user = $null
       $user = $acc.user
       $user = $user.ToString()
       $access =  $acc.accessrights
	Switch($access){ 
    	None { $userN += $user + ","}
	Contributor { $userC += $user + ","}
	author { $userA += $user + ","}
	PublishingAuthor { $userPA += $user + ","}
	NonEditingAuthor { $userNEA += $user + ","}
	Reviewer { $userR += $user + ","}
	Editor { $userE += $user + ","}
	PublishingEditor { $userPE += $user + ","}
	Owner { $userO += $user + ","}
	Availabilityonly { $userAO += $user + ","}
	Limiteddetails { $userL += $user + ","}
	default {"Something else happened"}
		}
    }

$roomp = "" | select ConfRoomname,None,Contributor,author,PublishingAuthor,NonEditingAuthor,Reviewer,Editor,PublishingEditor,Owner,Availabilityonly,Limiteddetails
$roomp.ConfRoomname = $Mailbox.displayname
$roomp.None = $userN
$roomp.Contributor = $userC
$roomp.author = $userA
$roomp.PublishingAuthor = $userPA
$roomp.NonEditingAuthor = $userNEA
$roomp.Reviewer = $userR
$roomp.Editor = $userE
$roomp.PublishingEditor = $userPE
$roomp.Owner = $userO
$roomp.Availabilityonly = $userAO
$roomp.Limiteddetails = $userL
$ConPermission += $roomp
}

$ConPermission | export-csv .\ConfPermissions.csv -notypeinformation

######################################################################################