#####################################################################################
##           Script will Upload files to FTP   
##           Author:  Vikas Sukhija                           								
##           		                 								
##           Date: 02-24-2013
##           Modified Date:- 02-26-2013 (included loging & monitoring)
#####################################################################################
#############################Define Log Files########################################

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t
$month = get-date 
$month1 = $month.month
$year1 = $month.year
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log1 = ".\Logs" + "\" + "FTP_" + $date + "_.log"
$log2 = ".\Logs" + "\" + "FTP_" + $month1 +"_" + $year1 +"_.log"
$log3 = ".\Logs" + "\" + "FTP_" + $date + $time + "_.log"

$logs = ".\Logs" + "\" + "Powershell" + $date + "_" + $time + "_.txt"

#Start-Transcript -Path $logs 
$dt = Get-Date
Add-Content $log3 "$dt : Script Started"

###########################Variables######################################

$smtpServer = "smtp.lab.com" # Change 
$fromadd = "DoNotReplyftp@lab.com" # Change 
$email1 = "Vikas.Sukhija@lab.com"  # Change 
$ftp = "ftp://127.0.0.1/" # Change
$user = "vikas"  # Change
$pass = "password" # Change
$uploadfpath = "C:\Uploadftp\ftpfiles" # Define the Folder from where files will be uploaded 

###########################################################################

$checkitems = Get-ChildItem $uploadfpath
$countitems = $checkitems.count
if ($countitems -eq 0)
{
Write-Host "No items to process" -ForegroundColor Green
$dt = Get-Date
Add-Content $log3 "$dt : No items to process, script will exit"
exit
}
$dt = Get-Date
Add-Content $log3 "$dt : Total number of items to process $countitems"

$processed = ".\processed\$date" + "-" + $time
if((test-path $processed) -like $false)
{
New-Item -Path "$processed" -type directory
}
  

#####################################################################################

if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "FTP Script error"
$msg.Body = $error
$smtp.Send($msg)
$dt = Get-Date
Add-Content $log3 "$dt : Script Terminated because of error: $error"
$error.clear()
exit

       }
  else

      {
    Write-host "no errors till now"
      }

$webclient = New-Object System.Net.WebClient 
 
$webclient.Credentials = New-Object System.Net.NetworkCredential($user,$pass)  
 
#Upload each file in upload directory...

foreach($item in (dir $uploadfpath "*.*")){ 
    Write-host  "Uploading $item..."  -ForegroundColor Green
	$dt = Get-Date
	Add-Content $log3 "$dt : Uploading $item..."
    $uri = New-Object System.Uri($ftp+$item.Name) 
    $webclient.UploadFile($uri, $item.FullName)
      if($error -ne $null)
        {
	Write-Host "Items will not be moved" -ForegroundColor Red
        }
		else
		{
	Write-Host "Moving $item to processed" -ForegroundColor green
	Move-Item "$uploadfpath\$item" $processed
	$dt = Get-Date
	Add-Content $log3 "$dt : Moving $item to processed"
	    }
 } 

if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "FTP Script error"
$msg.Body = $error
$smtp.Send($msg)
$dt = Get-Date
Add-Content $log3 "$dt : Script encountered error: $error"
$error.clear()
       }
  else

      {
    Write-host "no errors till now"
      }
$dt = Get-Date
Add-Content $log3 "$dt : Script Processing finished"

#Stop-Transcript
#########################################################################################