﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	12/8/2016 4:19 PM
	 Created by:   	Vikas Sukhija (http://msexchange.me)
	 Organization: 	
	 Filename:     	EmailAddressChange.ps1
	===========================================================================
	.DESCRIPTION
		This Script will monitor changes in Primary SMTP address of Users,
		if there is a change then responsible team will be notified.
#>
################Add Modules Exchange#############################
$error.clear()
If ((Get-PSSnapin | where { $_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010" }) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}

###############ADD Logs & Variables################################
$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/", "-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log = (Get-Location).Path + "\Logs" + "\" + "Processed_PS_Logs" + $date1 + "_" + $time + "_.log"
$report1 = (Get-Location).Path + "\Report" + "\" + "Report_Emchange" + $date1 + "_" + $time + "_.csv"

$limit = (Get-Date).AddDays(-60) #for report recycling
$path1 = (Get-Location).Path + "\Logs"
$path2 = (Get-Location).Path + "\Report"

$email1 = "VikasS@labtest.com"
$from = "EmailAddressChange@labtest.com"
$smtpserver = "smtpserver"

$collmbx = @()
$collection = @()
$collection1 = @()
$Statefile = ".\State-Email.csv"
$regex = '^\d+$'

################Email Function#####################

function Send-Email
{
	[CmdletBinding()]
	param
	(
		$From,
		[array]$To,
		[array]$bcc,
		[array]$cc,
		$body,
		$subject,
		$attachment,
		$smtpserver
	)
	$message = new-object System.Net.Mail.MailMessage
	$message.From = $from
	if ($To -ne $null)
	{
		$To | ForEach-Object{
			$to1 = $_
			$to1
			$message.To.Add($to1)
		}
	}
	if ($cc -ne $null)
	{
		$cc | ForEach-Object{
			$cc1 = $_
			$cc1
			$message.CC.Add($cc1)
		}
	}
	if ($bcc -ne $null)
	{
		$bcc | ForEach-Object{
			$bcc1 = $_
			$bcc1
			$message.bcc.Add($bcc1)
		}
	}
	$message.IsBodyHtml = $True
	if ($subject -ne $null)
	{
		$message.Subject = $Subject
	}
	if ($attachment -ne $null)
	{
		$attach = new-object Net.Mail.Attachment($attachment)
		$message.Attachments.Add($attach)
	}
	if ($body -ne $null)
	{
		$message.body = $body
	}
	$smtp = new-object Net.Mail.SmtpClient($smtpserver)
	$smtp.Send($message)
}
################################################################
if ($error)
{
	Write-Host "Error in initialization";
	Send-Email -To $email1 -From $from -subject "Email Address Change Script initialization failure" -smtpserver $smtpserver
	timeout 10; exit
}

Start-Transcript -path $log
get-date
################ Collect All mailboxes###########################

$collmbx = get-mailbox -resultsize unlimited | where{ $_.CustomAttribute11 -match $regex } | select Name, CustomAttribute11, PrimarySMTPAddress
$collmbx += get-remotemailbox -resultsize unlimited | where{ $_.CustomAttribute11 -match $regex } | select Name, CustomAttribute11, PrimarySMTPAddress
if ($error)
{
	Write-Host "Error in Fetching mailboxes data from Exchnage";
	Send-Email -To $email1 -From $from -subject "Email Address Change error fetching mailboxes" -smtpserver $smtpserver
	Stop-Transcript; timeout 10; exit
}
If (!(Test-Path $Statefile))
{
	$collmbx | select Name, CustomAttribute11,PrimarySMTPAddress | Export-csv $Statefile -NoTypeInformation
}

#########################Start comparison##########################

$stcsv = import-csv $Statefile
$coll = @()

$Changes = Compare-Object $stcsv $collmbx -property CustomAttribute11,PrimarySMTPAddress |
Select-Object CustomAttribute11, PrimarySMTPAddress, @{
	n = 'State'; e = {
		If ($_.SideIndicator -eq "=>") { "Current" }
		elseif ($_.SideIndicator -eq "<=") { "Previous" }
		else { "Ignore" }
	}
}
###################################################################
if ($changes)
{
	$Changes | foreach-object{
		$mcoll = "" | select Name, CustomAttribute11, PreviousSMTP, NewSMTP
		if ($_.state -eq "Previous")
		{
			$cus1 = $_.CustomAttribute11
			$Name = ($collmbx | where{$_.CustomAttribute11 -eq $cus1}).name
			$PreviousSMTP = $_.PrimarySMTPAddress
			foreach ($chg in $Changes)
			{
				if (($cus1 -eq $chg.CustomAttribute11) -and ($chg.state -eq "Current"))
				{
					$NewSMTP = $chg.PrimarySMTPAddress
					$mcoll.Name = $Name
					$mcoll.CustomAttribute11 = $cus1
					$mcoll.PreviousSMTP = $PreviousSMTP
					$mcoll.NewSMTP = $NewSMTP
					
				}
			}
			
		}
		$collection += $mcoll
		
	}
	$collection1 = $collection | where{ $_.name -ne $null }
	if ($collection1) { $collection1; $collection1 | Export-Csv $report1 -NoTypeInformation }
}

$collmbx | Export-Csv $Statefile -NoTypeInformation # new state

if($collection1){Send-Email -To $email1 -From $from -subject "Email Address Changes" -attachment $report1 -smtpserver $smtpserver}

####################################################
if ($error)
{
	Send-Email -To $email1 -From $from -subject "Email Address Change error Report" -body $Error -smtpserver $smtpserver
}

Get-ChildItem -Path $path1 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

Get-ChildItem -Path $path2 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

get-date
Stop-Transcript