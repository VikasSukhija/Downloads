##############################################################################################
##           Author: Vikas Sukhija                   
##           Date: 07-10-2012 
##           modified : 06-08-2013 (made it folder independent)                                                                                                                
##           Description:- This script is used for feeding data to AD attributes 
##           userid,Email,Physicaladdress,City,State,Zip,Country,CountryCode,OfficeTelephone 
##           New Version: make it more user friedndly by using functions & Gui
##           Added more common fields
##           Modified : 9/14/2014  
##           Modified : 9/17/2014 (Added Check Boxes)                                      
#############################################################################################

###################Created Checked Boxes for Inputs##########################################


Function Checkbox {

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")  

$form = New-Object �System.Windows.Forms.Form�;
$form.Width = 300;
$form.Height = 600;
$form.Text = "Select AD Fields";
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen;

#################check boxes############################
$checkBox = New-Object System.Windows.Forms.GroupBox
$checkBox.Location = New-Object System.Drawing.Size(20,20) 
$checkBox.size = New-Object System.Drawing.Size(175,500) 
$checkBox.text = "Select Fields:" 
$Form.Controls.Add($checkBox) 

$FirstName = New-Object System.Windows.Forms.checkbox
$FirstName.Location = New-Object System.Drawing.Size(10,20)
$FirstName.Size = New-Object System.Drawing.Size(200,20)
$FirstName.Checked = $true
$FirstName.Text = "FirstName"
$checkBox.Controls.Add($FirstName)

$LastName = New-Object System.Windows.Forms.checkbox
$LastName.Location = New-Object System.Drawing.Size(10,40)
$LastName.Size = New-Object System.Drawing.Size(200,20)
$LastName.Checked = $true
$LastName.Text = "LastName"
$checkBox.Controls.Add($LastName)


$DisplayName = New-Object System.Windows.Forms.checkbox
$DisplayName.Location = New-Object System.Drawing.Size(10,60)
$DisplayName.Size = New-Object System.Drawing.Size(200,20)
$DisplayName.Checked = $true
$DisplayName.Text = "DisplayName"
$checkBox.Controls.Add($DisplayName)

$Description = New-Object System.Windows.Forms.checkbox
$Description.Location = New-Object System.Drawing.Size(10,80)
$Description.Size = New-Object System.Drawing.Size(200,20)
$Description.Checked = $true
$Description.Text = "Description"
$checkBox.Controls.Add($Description)

$physicalDeliveryOfficeName = New-Object System.Windows.Forms.checkbox
$physicalDeliveryOfficeName.Location = New-Object System.Drawing.Size(10,100)
$physicalDeliveryOfficeName.Size = New-Object System.Drawing.Size(200,20)
$physicalDeliveryOfficeName.Checked = $true
$physicalDeliveryOfficeName.Text = "physicalDeliveryOfficeName"
$checkBox.Controls.Add($physicalDeliveryOfficeName)

$telephoneNumber = New-Object System.Windows.Forms.checkbox
$telephoneNumber.Location = New-Object System.Drawing.Size(10,120)
$telephoneNumber.Size = New-Object System.Drawing.Size(200,20)
$telephoneNumber.Checked = $true
$telephoneNumber.Text = "telephoneNumber"
$checkBox.Controls.Add($telephoneNumber)

$Email = New-Object System.Windows.Forms.checkbox
$Email.Location = New-Object System.Drawing.Size(10,140)
$Email.Size = New-Object System.Drawing.Size(200,20)
$Email.Checked = $true
$Email.Text = "Email"
$checkBox.Controls.Add($Email)

$wWWHomePage = New-Object System.Windows.Forms.checkbox
$wWWHomePage.Location = New-Object System.Drawing.Size(10,160)
$wWWHomePage.Size = New-Object System.Drawing.Size(200,20)
$wWWHomePage.Checked = $true
$wWWHomePage.Text = "wWWHomePage"
$checkBox.Controls.Add($wWWHomePage)

$StreetAddress = New-Object System.Windows.Forms.checkbox
$StreetAddress.Location = New-Object System.Drawing.Size(10,180)
$StreetAddress.Size = New-Object System.Drawing.Size(200,20)
$StreetAddress.Checked = $true
$StreetAddress.Text = "StreetAddress"
$checkBox.Controls.Add($StreetAddress)

$PostOfficeBox = New-Object System.Windows.Forms.checkbox
$PostOfficeBox.Location = New-Object System.Drawing.Size(10,200)
$PostOfficeBox.Size = New-Object System.Drawing.Size(200,20)
$PostOfficeBox.Checked = $true
$PostOfficeBox.Text = "PostOfficeBox"
$checkBox.Controls.Add($PostOfficeBox)

$City = New-Object System.Windows.Forms.checkbox
$City.Location = New-Object System.Drawing.Size(10,220)
$City.Size = New-Object System.Drawing.Size(200,20)
$City.Checked = $true
$City.Text = "City"
$checkBox.Controls.Add($City)

$state = New-Object System.Windows.Forms.checkbox
$state.Location = New-Object System.Drawing.Size(10,240)
$state.Size = New-Object System.Drawing.Size(200,20)
$state.Checked = $true
$state.Text = "state"
$checkBox.Controls.Add($state)

$PostalCode = New-Object System.Windows.Forms.checkbox
$PostalCode.Location = New-Object System.Drawing.Size(10,260)
$PostalCode.Size = New-Object System.Drawing.Size(200,20)
$PostalCode.Checked = $true
$PostalCode.Text = "PostalCode"
$checkBox.Controls.Add($PostalCode)

$country = New-Object System.Windows.Forms.checkbox
$country.Location = New-Object System.Drawing.Size(10,280)
$country.Size = New-Object System.Drawing.Size(200,20)
$country.Checked = $true
$country.Text = "country"
$checkBox.Controls.Add($country)

$countrycode = New-Object System.Windows.Forms.checkbox
$countrycode.Location = New-Object System.Drawing.Size(10,300)
$countrycode.Size = New-Object System.Drawing.Size(200,20)
$countrycode.Checked = $true
$countrycode.Text = "countrycode"
$checkBox.Controls.Add($countrycode)

$HomePhone = New-Object System.Windows.Forms.checkbox
$HomePhone.Location = New-Object System.Drawing.Size(10,320)
$HomePhone.Size = New-Object System.Drawing.Size(200,20)
$HomePhone.Checked = $true
$HomePhone.Text = "HomePhone"
$checkBox.Controls.Add($HomePhone)

$Pager = New-Object System.Windows.Forms.checkbox
$Pager.Location = New-Object System.Drawing.Size(10,340)
$Pager.Size = New-Object System.Drawing.Size(200,20)
$Pager.Checked = $true
$Pager.Text = "Pager"
$checkBox.Controls.Add($Pager)

$mobile = New-Object System.Windows.Forms.checkbox
$mobile.Location = New-Object System.Drawing.Size(10,360)
$mobile.Size = New-Object System.Drawing.Size(200,20)
$mobile.Checked = $true
$mobile.Text = "mobile"
$checkBox.Controls.Add($mobile)

$facsimileTelephoneNumber = New-Object System.Windows.Forms.checkbox
$facsimileTelephoneNumber.Location = New-Object System.Drawing.Size(10,380)
$facsimileTelephoneNumber.Size = New-Object System.Drawing.Size(200,20)
$facsimileTelephoneNumber.Checked = $true
$facsimileTelephoneNumber.Text = "facsimileTelephoneNumber"
$checkBox.Controls.Add($facsimileTelephoneNumber)

$Title = New-Object System.Windows.Forms.checkbox
$Title.Location = New-Object System.Drawing.Size(10,400)
$Title.Size = New-Object System.Drawing.Size(200,20)
$Title.Checked = $true
$Title.Text = "Title"
$checkBox.Controls.Add($Title)

$Department = New-Object System.Windows.Forms.checkbox
$Department.Location = New-Object System.Drawing.Size(10,420)
$Department.Size = New-Object System.Drawing.Size(200,20)
$Department.Checked = $true
$Department.Text = "Department"
$checkBox.Controls.Add($Department)

$Company = New-Object System.Windows.Forms.checkbox
$Company.Location = New-Object System.Drawing.Size(10,440)
$Company.Size = New-Object System.Drawing.Size(200,20)
$Company.Checked = $true
$Company.Text = "Company"
$checkBox.Controls.Add($Company)

$Manager = New-Object System.Windows.Forms.checkbox
$Manager.Location = New-Object System.Drawing.Size(10,460)
$Manager.Size = New-Object System.Drawing.Size(200,20)
$Manager.Checked = $true
$Manager.Text = "Manager"
$checkBox.Controls.Add($Manager)

$IPPhone = New-Object System.Windows.Forms.checkbox
$IPPhone.Location = New-Object System.Drawing.Size(10,480)
$IPPhone.Size = New-Object System.Drawing.Size(200,20)
$IPPhone.Checked = $true
$IPPhone.Text = "IPPhone"
$checkBox.Controls.Add($IPPhone)



################buttons###################################

$Button = New-Object System.Windows.Forms.Button 
$Button.Location = New-Object System.Drawing.Size(200,30) 
$Button.Size = New-Object System.Drawing.Size(50,50) 
$Button.Text = "Ok" 

$eventHandler = [System.EventHandler]{
$FirstName.Text;
$LastName.Text;
$form.Close();};

$Button.Add_Click($eventHandler) 
$Form.Controls.Add($Button) 


################end buttons###############################

$Form.Add_Shown({$Form.Activate()})
[void] $Form.ShowDialog()
$ret=@()
 if ($FirstName.Checked -like $true) {$ret += $FirstName.Text}
 if ($LastName.Checked -like $true)  {$ret += $LastName.Text}
 if ($DisplayName.Checked -like $true)  {$ret += $DisplayName.Text}
 if ($Description.Checked -like $true)  {$ret += $Description.Text}
 if ($physicalDeliveryOfficeName.Checked -like $true)  {$ret += $physicalDeliveryOfficeName.Text}
 if ($telephoneNumber.Checked -like $true)  {$ret += $telephoneNumber.Text}
 if ($Email.Checked -like $true)  {$ret += $Email.Text}
 if ($wWWHomePage.Checked -like $true)  {$ret += $wWWHomePage.Text}
 if ($StreetAddress.Checked -like $true)  {$ret += $StreetAddress.Text}
 if ($PostOfficeBox.Checked -like $true)  {$ret += $PostOfficeBox.Text}
 if ($City.Checked -like $true)  {$ret += $City.Text}
 if ($state.Checked -like $true)  {$ret += $state.Text}
 if ($PostalCode.Checked -like $true)  {$ret += $PostalCode.Text}
 if ($country.Checked -like $true)  {$ret += $country.Text}
 if ($countrycode.Checked -like $true)  {$ret += $countrycode.Text}
 if ($HomePhone.Checked -like $true)  {$ret += $HomePhone.Text}
 if ($Pager.Checked -like $true)  {$ret += $Pager.Text}
 if ($mobile.Checked -like $true)  {$ret += $mobile.Text}
 if ($facsimileTelephoneNumber.Checked -like $true)  {$ret += $facsimileTelephoneNumber.Text}
 if ($Title.Checked -like $true)  {$ret += $Title.Text}
 if ($Department.Checked -like $true)  {$ret += $Department.Text}
 if ($Company.Checked -like $true)  {$ret += $Company.Text}
 if ($Manager.Checked -like $true)  {$ret += $Manager.Text}
 if ($IPPhone.Checked -like $true)  {$ret += $IPPhone.Text}
return $ret
}

$getlist = Checkbox
$result = $getlist 

############################################################################################

# Add Quest Shell...

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}

############################Function for Ad attribute overwrite#########################################

Function Adattribute ($userid,$attribute,$adatt)
 {

	$userobject = get-qaduser -SamAccountName $userid -IncludedProperties �Co�,�C�,"IPPhone" 

	$givenName = $userobject.givenName
	$sn = $userobject.sn
	$DisplayName = $userobject.DisplayName
	$Description = $userobject.Description
	$physicalDeliveryOfficeName = $userobject.physicalDeliveryOfficeName
	$telephoneNumber = $userobject.telephoneNumber
	$Email = $userobject.Email
	$wWWHomePage = $userobject.wWWHomePage
	$StreetAddress = $userobject.StreetAddress
	$PostOfficeBox = $userobject.PostOfficeBox
	$l = $userobject.l
	$st = $userobject.st
	$PostalCode = $userobject.PostalCode
	$c = $userobject.c
	$co = $userobject.co
	$HomePhone = $userobject.HomePhone
	$Pager = $userobject.Pager
	$mobile = $userobject.mobile
	$facsimileTelephoneNumber = $userobject.facsimileTelephoneNumber
	$Title = $userobject.Title
	$Department = $userobject.Department
	$Company = $userobject.Company
	$Manager = $userobject.Manager
        $IPPhone = $userobject.IPPhone

    # adding log to if attribute is blank

    $attrib = "$" + $attribute

    if ($attrib -like $null)
           {
            Write-host $userobject has blank $attribute
            $Log1 = ".\logs\" + "Blank" + $attribute + $now + �.log�
            Add-content  $Log1 �$userobject has blank $attribute�
            
            # If address is Blank than populate the $attribute from the csv file
            
            Get-QADUser -SamAccountName $userid | Set-QADUser -ObjectAttributes @{$attribute = $adatt.Trim()}
            $userobject = get-qaduser -SamAccountName $i.userid -IncludedProperties �CO�,"C","IPPhone" 
            $attrib = $userobject.$attribute

            Write-host $userobject has $attribute as $attrib
            $Log3 = ".\logs\" + "Set" + $attribute + $now + �.log�
            Add-content  $Log3 �For $userobject $attribute as $attrib has been set�
            } 
    else
            {
           # adding log to check current $attribute is not blank , than $attribute will be overwritten.
            $Log2 = ".\logs\" + "Current" + $attribute + $now + �.log�
            Get-QADUser -SamAccountName $i.userid | Set-QADUser -ObjectAttributes @{$attribute = $adatt.Trim()}
            $userobject = get-qaduser -SamAccountName $i.userid -IncludedProperties �CO�,"C","IPPhone" 
            $attrib = $userobject.$attribute
            Write-host $userobject has been overwritten with $attribute as Current $attrib
            Add-content  $Log2 �$userobject has been overwritten with $attribute as $attrib�
             }
 }

###############################################Function Completed####################################

############################Function for Ad attribute No overwrite###################################

Function AdattributeNoOV ($userid,$attribute,$adatt)
 {

	$userobject = get-qaduser -SamAccountName $userid -IncludedProperties �Co�,�C�,"IPPhone" 

	$givenName = $userobject.givenName
	$sn = $userobject.sn
	$DisplayName = $userobject.DisplayName
	$Description = $userobject.Description
	$physicalDeliveryOfficeName = $userobject.physicalDeliveryOfficeName
	$telephoneNumber = $userobject.telephoneNumber
	$Email = $userobject.Email
	$wWWHomePage = $userobject.wWWHomePage
	$StreetAddress = $userobject.StreetAddress
	$PostOfficeBox = $userobject.PostOfficeBox
	$l = $userobject.l
	$st = $userobject.st
	$PostalCode = $userobject.PostalCode
        $c = $userobject.c
	$co = $userobject.co
	$HomePhone = $userobject.HomePhone
	$Pager = $userobject.Pager
	$mobile = $userobject.mobile
	$facsimileTelephoneNumber = $userobject.facsimileTelephoneNumber
	$Title = $userobject.Title
	$Department = $userobject.Department
	$Company = $userobject.Company
	$Manager = $userobject.Manager
        $IPPhone = $userobject.IPPhone

    # adding log to if attribute is blank

    $attrib = "$" + $attribute

    if ($attrib -like $null)
           {
            Write-host $userobject has blank $attribute
            $Log1 = ".\logs\" + "Blank" + $attribute + $now + �.log�
            Add-content  $Log1 �$userobject has blank $attribute�
            
            # If address is Blank than populate the $attribute from the csv file
            
            Get-QADUser -SamAccountName $userid | Set-QADUser -ObjectAttributes @{$attribute = $adatt.Trim()}
            $userobject = get-qaduser -SamAccountName $i.userid -IncludedProperties �CO�,"C","IPPhone" 
            $attrib = $userobject.$attribute

            Write-host $userobject has $attribute as $attrib
            $Log3 = ".\logs\" + "Set" + $attribute + $now + �.log�
            Add-content  $Log3 �For $userobject $attribute as $attrib has been set�
            } 
    else
            {
           # adding log to check current $attribute is not blank , than $attribute will be not be overwritten.
            $Log2 = ".\logs\" + "Current" + $attribute + $now + �.log�
            $userobject = get-qaduser -SamAccountName $i.userid -IncludedProperties �CO�,"C","IPPhone" 
            $attrib = $userobject.$attribute
            Write-host $userobject already has $attribute as $attrib
            Add-content  $Log2 �$userobject already has $attribute as $attrib�
             }
 }

###############################################Function Completed####################################

############################Function for Ad attribute Manager overwrite#########################################

Function AdattributeMN ($userid,$attribute,$adatt)
 {

	$userobject = get-qaduser -SamAccountName $userid -IncludedProperties �Co�,�C�,"IPPhone" 
	$Manager = $userobject.Manager
   
    # adding log to if attribute is blank

    $attrib = "$" + $attribute

    if ($attrib -like $null)
           {
            Write-host $userobject has blank $attribute
            $Log1 = ".\logs\" + "Blank" + $attribute + $now + �.log�
            Add-content  $Log1 �$userobject has blank $attribute�
            
            # If address is Blank than populate the $attribute from the csv file
            
            Get-QADUser -SamAccountName $userid | Set-QADUser -ObjectAttributes @{$attribute = (get-qaduser -SamAccountName $adatt.Trim()).DN}
            $userobject = get-qaduser -SamAccountName $i.userid -IncludedProperties �CO�,"C","IPPhone" 
            $attrib = $userobject.$attribute

            Write-host $userobject has $attribute as $attrib
            $Log3 = ".\logs\" + "Set" + $attribute + $now + �.log�
            Add-content  $Log3 �For $userobject $attribute as $attrib has been set�
            } 
    else
            {
           # adding log to check current $attribute is not blank , than $attribute will be overwritten.
            $Log2 = ".\logs\" + "Current" + $attribute + $now + �.log�
            Get-QADUser -SamAccountName $userid | Set-QADUser -ObjectAttributes @{$attribute = (get-qaduser -SamAccountName $adatt.Trim()).DN}
            $userobject = get-qaduser -SamAccountName $i.userid -IncludedProperties �CO�,"C","IPPhone" 
            $attrib = $userobject.$attribute
            Write-host $userobject has been overwritten with $attribute as Current $attrib
            Add-content  $Log2 �$userobject has been overwritten with $attribute as $attrib�
             }
 }

###############################################Function Completed####################################

############################Function for Ad attribute No overwrite Manager###################################

Function AdattributeNoOVMN ($userid,$attribute,$adatt)
 {

	$userobject = get-qaduser -SamAccountName $userid -IncludedProperties �Co�,�C�,"IPPhone" 

	$Manager = $userobject.Manager

    # adding log to if attribute is blank

    $attrib = "$" + $attribute

    if ($attrib -like $null)
           {
            Write-host $userobject has blank $attribute
            $Log1 = ".\logs\" + "Blank" + $attribute + $now + �.log�
            Add-content  $Log1 �$userobject has blank $attribute�
            
            # If address is Blank than populate the $attribute from the csv file
            
            Get-QADUser -SamAccountName $userid | Set-QADUser -ObjectAttributes @{$attribute = (get-qaduser -SamAccountName $adatt.Trim()).DN}
            $userobject = get-qaduser -SamAccountName $i.userid -IncludedProperties �CO�,"C","IPPhone" 
            $attrib = $userobject.$attribute

            Write-host $userobject has $attribute as $attrib
            $Log3 = ".\logs\" + "Set" + $attribute + $now + �.log�
            Add-content  $Log3 �For $userobject $attribute as $attrib has been set�
            } 
    else
            {
           # adding log to check current $attribute is not blank , than $attribute will be not be overwritten.
            $Log2 = ".\logs\" + "Current" + $attribute + $now + �.log�
            $userobject = get-qaduser -SamAccountName $i.userid -IncludedProperties �CO�,"C","IPPhone" 
            $attrib = $userobject.$attribute
            Write-host $userobject already has $attribute as $attrib
            Add-content  $Log2 �$userobject already has $attribute as $attrib�
             }
 }

###############################################Function Completed####################################




# Import CSV file that is populated with checked input Attributes

$now=Get-Date -format �dd-MMM-yyyy HH:mm�

# replace : by -

$now = $now.ToString().Replace(�:�, �-�)

$data = import-csv .\Users.csv

$overwrite = new-object -comobject wscript.shell 
$Answer = $overwrite.popup("Do you want to Overwrite AD Attributes?",0,"Overwrite Attributes",4)
 
If ($Answer -eq 6) {


# Loop thru the data from CSV

foreach ($i in $data)

{

$userid = $i.userid
$givenName = $i.givenName
$sn = $i.sn
$DisplayName = $i.DisplayName
$Description = $i.Description
$physicalDeliveryOfficeName = $i.physicalDeliveryOfficeName
$telephoneNumber = $i.telephoneNumber
$Email = $i.Email
$wWWHomePage = $i.wWWHomePage
$StreetAddress = $i.StreetAddress
$PostOfficeBox = $i.PostOfficeBox
$l = $i.l
$st = $i.st
$PostalCode = $i.PostalCode
$co = $i.co
$c = $i.c
$HomePhone = $i.HomePhone
$Pager = $i.Pager
$mobile = $i.mobile
$facsimileTelephoneNumber = $i.facsimileTelephoneNumber
$Title = $i.Title
$Department = $i.Department
$Company = $i.Company
$Manager = $i.Manager
$IPPhone = $i.IPPhone

if($result -contains "FirstName"){ Adattribute $userid givenName $givenName }
if($result -contains "LastName"){ Adattribute $userid sn $sn }
if($result -contains "DisplayName"){ Adattribute $userid DisplayName $DisplayName }
if($result -contains "Description"){ Adattribute $userid Description $Description }
if($result -contains "physicalDeliveryOfficeName"){ Adattribute $userid physicalDeliveryOfficeName $physicalDeliveryOfficeName }
if($result -contains "telephoneNumber"){ Adattribute $userid telephoneNumber $telephoneNumber }
if($result -contains "Email"){ Adattribute $userid mail $Email }
if($result -contains "wWWHomePage"){ Adattribute $userid wWWHomePage $wWWHomePage }
if($result -contains "StreetAddress"){ Adattribute $userid StreetAddress $StreetAddress }
if($result -contains "PostOfficeBox"){ Adattribute $userid PostOfficeBox $PostOfficeBox }
if($result -contains "City"){ Adattribute $userid l $l }
if($result -contains "State"){ Adattribute $userid st $st }
if($result -contains "PostalCode"){ Adattribute $userid PostalCode $PostalCode }
if($result -contains "country"){ Adattribute $userid c $c }
if($result -contains "countrycode"){ Adattribute $userid co $co }
if($result -contains "HomePhone"){ Adattribute $userid HomePhone $HomePhone }
if($result -contains "Pager"){ Adattribute $userid Pager $Pager }
if($result -contains "mobile"){ Adattribute $userid mobile $mobile }
if($result -contains "facsimileTelephoneNumber"){ Adattribute $userid facsimileTelephoneNumber $facsimileTelephoneNumber }
if($result -contains "Title"){ Adattribute $userid Title $Title }
if($result -contains "Department"){ Adattribute $userid Department $Department }
if($result -contains "Company"){ Adattribute $userid Company $Company }
if($result -contains "Manager"){ AdattributeMN $userid Manager $Manager }
if($result -contains "IPPhone"){ Adattribute $userid IPPhone $IPPhone }

}

}

else
{

# Loop thru the data from CSV

foreach ($i in $data)

{

$userid = $i.userid
$givenName = $i.givenName
$sn = $i.sn
$DisplayName = $i.DisplayName
$Description = $i.Description
$physicalDeliveryOfficeName = $i.physicalDeliveryOfficeName
$telephoneNumber = $i.telephoneNumber
$Email = $i.Email
$wWWHomePage = $i.wWWHomePage
$StreetAddress = $i.StreetAddress
$PostOfficeBox = $i.PostOfficeBox
$l = $i.l
$st = $i.st
$PostalCode = $i.PostalCode
$co = $i.co
$c = $i.c
$HomePhone = $i.HomePhone
$Pager = $i.Pager
$mobile = $i.mobile
$facsimileTelephoneNumber = $i.facsimileTelephoneNumber
$Title = $i.Title
$Department = $i.Department
$Company = $i.Company
$Manager = $i.Manager
$IPPhone = $i.IPPhone

if($result -contains "FirstName"){ AdattributeNoOV $userid givenName $givenName }
if($result -contains "LastName"){ AdattributeNoOV $userid sn $sn }
if($result -contains "DisplayName"){ AdattributeNoOV $userid DisplayName $DisplayName }
if($result -contains "Description"){ AdattributeNoOV $userid Description $Description }
if($result -contains "physicalDeliveryOfficeName"){ AdattributeNoOV $userid physicalDeliveryOfficeName $physicalDeliveryOfficeName }
if($result -contains "telephoneNumber"){ AdattributeNoOV $userid telephoneNumber $telephoneNumber }
if($result -contains "Email"){ AdattributeNoOV $userid mail $Email }
if($result -contains "wWWHomePage"){ AdattributeNoOV $userid wWWHomePage $wWWHomePage }
if($result -contains "StreetAddress"){ AdattributeNoOV $userid StreetAddress $StreetAddress }
if($result -contains "PostOfficeBox"){ AdattributeNoOV $userid PostOfficeBox $PostOfficeBox }
if($result -contains "City"){ AdattributeNoOV $userid l $l }
if($result -contains "State"){ AdattributeNoOV $userid st $st }
if($result -contains "PostalCode"){ AdattributeNoOV $userid PostalCode $PostalCode }
if($result -contains "country"){ AdattributeNoOV $userid c $c}
if($result -contains "countrycode"){ AdattributeNoOV $userid co $co }
if($result -contains "HomePhone"){ AdattributeNoOV $userid HomePhone $HomePhone }
if($result -contains "Pager"){ AdattributeNoOV $userid Pager $Pager }
if($result -contains "mobile"){ AdattributeNoOV $userid mobile $mobile }
if($result -contains "facsimileTelephoneNumber"){ AdattributeNoOV $userid facsimileTelephoneNumber $facsimileTelephoneNumber }
if($result -contains "Title"){ AdattributeNoOV $userid Title $Title }
if($result -contains "Department"){ AdattributeNoOV $userid Department $Department }
if($result -contains "Company"){ AdattributeNoOV $userid Company $Company }
if($result -contains "Manager"){ AdattributeNoOVMN $userid Manager $Manager }
if($result -contains "IPPhone"){ AdattributeNoOV $userid IPPhone $IPPhone }

}

}

##########################################################################################################



