################################################################################################
##                                                                                            
##           Author: Vikas Sukhija                  		                              
##           Date: 07-10-2012                       		      			     
##           Description:- This script is used for Migration of mailboxes                     
##           (Importing Legacy DN)       			      	              			      
################################################################################################


# Add exchange Shell


If ((Get-PSSnapin | where {$_.Name -match "Exchange.Management"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin
}


# Import CSV file that is populated with user id (email address) & Legacy DN

$now=Get-Date -format "dd-MMM-yyyy HH:mm"

# replace : by -

$now = $now.ToString().Replace(�:�, �-�)

$data = import-csv $args[0]

# Loop thru the data from CSV


foreach ($i in $data)

{

$Log1 = ".\logs\" + "legacyDN" + $now + ".log"
$lDN = "X500:"
$legacyDN = $lDN + $i.legacyExchangeDN
$mailbox = get-mailbox $i.userid
$mailbox.emailaddresses+=$legacyDN
$mailbox | set-mailbox
Write-host "$legacyDN has been added to $mailbox"
add-content $Log1 "$legacyDN has been added to $mailbox"


}

####################################################################################################