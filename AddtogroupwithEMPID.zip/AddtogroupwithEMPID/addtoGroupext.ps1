###########################################################################################
##                                                                                            
##           Author: Vikas Sukhija                  		                              
##           Date: 26-11-2012 
##	     Modified: 18-09-2015
##	     Update :  Update users from EMployeeid                    		      			      
##           Description:- If user is not a member of group this script add it after reading   
##           from CSV     			      		                              			      
###########################################################################################
#Add Quest Shell...

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}

#####define Variables/Log ########

$date = get-date -format d
$time = get-date -format t

$date = $date.ToString().Replace(�/�, �-�)

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log1 = ".\Logs" + "\" + "Addtogrp_" + $date + $time + "_.log"
$log2 = ".\Logs" + "\" + "Usrnotadded_" + $date + $time + "_.log"
$log3 = ".\Logs" + "\" + "UsrAdded_" + $date + $time + "_.log"

$usertoadd = @()

$grp="Define group name" #group Common name Name example "Test Dl1" , full dn is not needed
$attrib = "extensionattribute11"

$coll = @()

start-transcript -path $log1

#########################

# import csv file

$data = import-csv $args[0]

$Can = �CN=$grp�

$dt = get-date


Write-host "`n Group to which users will be added $Can" -foregroundcolor magenta


foreach($i in $data) {

$empid = $i.empid
$usertoadd= $null

$user = Get-QADUser -LdapFilter "($attrib=$empid)"

Write-host "`n $empid matched $user" -foregroundcolor Green


  if (($user.memberof -like �$Can,*�))

  {

  write-host �$user is a member & will not be added to $grp group�
  add-content $log2 �$user is a member & will not be added to $grp group�

  }

  else
 
  {

  write-host �$user is not a member & will be added to $grp group�

  add-qadgroupmember $grp $user  
  add-content $log3 �$user is a member & will be added to $grp group�
  
    }

}

$dt = get-date

Write-host  "all users addition to group finished... $dt...." -foregroundcolor green


stop-transcript


########################################################################################