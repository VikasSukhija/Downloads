﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	8/17/2017 2:26 PM
	 Updated on: 12/8/2017
	 Created by:   	Vikas Sukhija (http://SysCloudPro.com)
	 Organization: 	
	 Filename:     	SpOnlineOwnerReport.ps1
	 Update: SharePoint Online Site Collections including Group Sites excluding Videos, OneDrive
	===========================================================================
	.DESCRIPTION
		This will report All owners of Sharepoint SItecollections
#>
#############Load Functions#################
$error.clear()
try { stop-transcript | out-null }
catch { $error.clear() }

function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}

function LaunchSHO
{
	param
	(
		$orgName,
		$cred
	)
	
	Write-Host "Enter Sharepoint Online Credentials" -ForegroundColor Green
	$userCredential = $cred
	Connect-SPOService -Url "https://$orgName-admin.sharepoint.com" -Credential $userCredential
}

Function RemoveSHO
{
	
	disconnect-sposervice
}

function LaunchEOL
{
	param
	(
		$cred
	)
	
	$UserCredential = $cred
	
	$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
	
	Import-PSSession $Session -Prefix "EOL" -AllowClobber
}



Function RemoveEOL
{
	
	$Session = Get-PSSession | where { $_.ComputerName -like "outlook.office365.com" }
	Remove-PSSession $Session
	
}
##########################Load variables & Logs####################
$log = Write-Log -Name "process_SpSiteonlineOwnerReport" -folder logs -Ext log
$output1 = Write-Log -Name "SPOCollection" -folder Report -Ext html
$orgname = "orgname"
$collection1 = @()
$collection = @()

##########Start Script main##############

Start-Transcript -Path $log
$cred = Get-Credential
try
{
	LaunchSHO -orgName $orgname -cred $cred
}
catch
{
	write-host "$($_.Exception.Message)" -foregroundcolor red
	Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "SP Online ConnectionError Site owner Report" -Body $($_.Exception.Message)
	break
}
#-Filter { Template -ne "Group#0" }
$collection1 = Get-SPOSite -Limit All | where{($_.lockstate -eq "Unlock") -and ($_.Url -notlike "*/portals/*")} | select url, owner, template, StorageUsageCurrent, StorageQuota

try
{
	Write-Host "Connecting to EOL" -ForegroundColor Green
	LaunchEOL -cred $cred
}
catch
{
	write-host "$($_.Exception.Message)" -foregroundcolor red
	Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "SP Online -EOL Connection Error Site owner Report" -Body $($_.Exception.Message)
	break
}
$collection1 | ForEach-Object{
	$url = $_.url
	$Owner = $_.owner
	$Template = $_.template
	$StorageUsageCurrent = $_.StorageUsageCurrent
	$StorageQuota = $_.StorageQuota
	Write-Host "processing...............$url" -ForegroundColor Green
	if (($Template -eq "GROUP#0") -and ($Owner -eq ""))
	{
		$own = (Get-SPOSite $url).owner
		$own = $own -replace "_o", ""
		$managedby = (Get-EOLUnifiedGroup $own).managedby
		$Owner = $managedby
	}
	if ($Template -eq "GROUP#0") { $Template = "Office 365 Group Site"}
	if ($Template -eq "STS#0") { $Template = "Classic Team Site"}
	if ($Template -eq "SITEPAGEPUBLISHING#0") { $Template = "Communication Site" }
	
	<#$owner
	$Template
	$StorageUsageCurrent
	$StorageQuota#>
	
	$coll = "" | select url, owner, template, StorageUsageCurrent, StorageQuota
	$coll.url = $url
	$coll.owner = $Owner
	$coll.template = $Template
	$coll.StorageUsageCurrent = $StorageUsageCurrent
	$coll.StorageQuota = $StorageQuota
	$collection+=$coll
}
RemoveSHO
RemoveEOL
############Format HTML###########
$HTMLFormat = "<style>"
$HTMLFormat = $HTMLFormat + "BODY{background-color:GainsBoro;}"
$HTMLFormat = $HTMLFormat + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$HTMLFormat = $HTMLFormat + "TH{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:darksalmon}"
$HTMLFormat = $HTMLFormat + "TD{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:LightBlue}"
$HTMLFormat = $HTMLFormat + "</style>"
################################

$collection | ConvertTo-HTML -Head $HTMLFormat -Body "<H2><Font Size = 4,Color = DarkCyan>SharePoint Online Site Collections including Group Sites excluding Videos, OneDrive</Font></H2>" -AS Table |
Set-Content $output1
copy-item $output1 .\SPOCollection.aspx

Stop-Transcript
##############################################################################

