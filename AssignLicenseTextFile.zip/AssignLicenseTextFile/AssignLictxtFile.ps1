﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	5/16/2017 8:45 PM
	 Created by:   	Vikas Sukhija
	 Organization: 	
	 Filename:     	AssignLictxtFile.ps1
	===========================================================================
	.DESCRIPTION
		Apply o365 services to List of users from text file
#>
$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/", "-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = (Get-Location).path + "\Logs" + "\" + "Processed_PS_" + $date1 + "_" + $time + "_.log"
$report1 = (Get-Location).path + "\report" + "\" + "Report_Licassign_existinguser" + $date1 + "_" + $time + "_.csv"
$report2 = (Get-Location).path + "\report" + "\" + "Report_Licassign_Newuser" + $date1 + "_" + $time + "_.csv"

$collusers1 = @()
$collusers2 = @()
$collusers3 = @()
$collection1 = @()
$collection2 = @()
$licenseent = "Labtest:ENTERPRISEPACK"
$svctoenable = @("TEAMS1", "YAMMER_ENTERPRISE")
$Disabledsvcs = @("Deskless", "FLOW_O365_P2", "POWERAPPS_O365_P2", "PROJECTWORKMANAGEMENT", "SWAY", "INTUNE_O365", "RMS_S_ENTERPRISE", "OFFICESUBSCRIPTION", "MCOSTANDARD", "SHAREPOINTWAC", "SHAREPOINTENTERPRISE", "EXCHANGE_S_ENTERPRISE")

$users = Get-Content .\users.txt

$mode = "Write" ################### for Assigning Licenses change mode to "Write"

Start-Transcript -Path $logs

if ($mode -eq "Write") { Write-host "Script will run in Implementation mode" -foregroundcolor green }
else { Write-host "Script will run in Readonly mode" -foregroundcolor Blue }

$AllLicensingPlans = Get-MsolAccountSku | where{ $_.AccountSkuId -eq $licenseent }

if ($error -ne $null)
{
	Write-host "Error occured, script will exit" -ForegroundColor Yellow
	timeout 10
	exit
}
##########Collect Users for which service is not enabled#################
$users | ForEach-Object{
	$user = $_
	$user
	$lic = get-msoluser -UserPrincipalName $user
	$sts = $lic.Licenses | where{ $_.AccountSkuId -eq $licenseent }
	$status = $sts.servicestatus
	if ($status -ne $null)
	{
		foreach ($svc in $status)
		{
			$svcnm = $svc.Serviceplan.ServiceName
			$svcsts = $svc.ProvisioningStatus
			foreach ($newsvc in $svctoenable)
			{
				if (($svcnm -eq $newsvc) -and ($svcsts -ne "Disabled"))
				{
					Write-Host "$svcnm is enabled for user $user" -foregroundcolor Magenta
				}
				elseif(($svcnm -eq $newsvc) -and ($svcsts -eq "Disabled"))
				{
					Write-Host "$svcnm is disabled for user $user" -foregroundcolor Magenta
					$collusers1 += $user		
				}
			}
		}
	}
	else
	{
		Write-Host "$user is not licensed in o365" -ForegroundColor green
		$collusers2 += $user
	}
}
$collusers1 = $collusers1 | Select-Object -Unique
$collusers2 = $collusers2 | Select-Object -Unique
#################enable service for Already existing user##########
Write-Host "Enabling services for existing Users" -ForegroundColor Green
if($collusers1){
$collusers1 | foreach-object{
		$mcoll = "" | Select-Object UserPrincipalName, DisabledSVC
		$USR = $_
		Write-Host "Processing................$USR" -ForegroundColor Magenta
		$lic1 = get-msoluser -UserPrincipalName $USR
		foreach ($sts in $lic1.Licenses)
		{
			if ($sts.AccountSkuId -eq $licenseent)
			{
				$status1 = $sts.servicestatus
			}
		}
		
		$mcoll.UserPrincipalName = $USR
		
		if ($status1 -ne $null)
		{
			$collnmsts1 = @()
			$collnmsts = @()
			foreach ($svc1 in $status1)
			{
				$svcnm1 = $svc1.Serviceplan.ServiceName
				$svcsts1 = $svc1.ProvisioningStatus
				if ($svcsts1 -eq "Disabled")
				{
					$collnmsts1 += $svcnm1
				}
			}
			[System.Collections.ArrayList]$collnmsts2 = $collnmsts1 #convert to array list
			foreach ($svcs in $svctoenable) { $collnmsts2.remove($svcs) } #remove the services that needs to be enabled
			$collnmsts2 | ForEach-Object{ $collnmsts += $_ }
			$mcoll.DisabledSVC = $collnmsts
			$O365Licences = $null
			for ($i = 0; $i -lt $AllLicensingPlans.Count; $i++)
			{
				$O365Licences = New-MsolLicenseOptions -AccountSkuId $AllLicensingPlans[$i].AccountSkuId -DisabledPlans $collnmsts
			}
			Write-Host "Processing ........................ $USR" -ForegroundColor Green
			if ($mode -eq "Write")
			{
				Set-MsolUserLicense -UserPrincipalName $USR -LicenseOptions $O365Licences -Verbose
			}
			if ($error)
			{
				Write-Host "Exiting Script -- Error setting License for $USR" -ForegroundColor Red; exit
			}
		}
		else
		{
			Write-Host "Processing ........................ $USR" -ForegroundColor Green
			$mcoll.DisabledSVC = "NA"
		}
		$collection1 += $mcoll
	}
}
###################Enable service for new o365 users############
Write-Host "Enabling services for New Users" -ForegroundColor Green
$collusers2 | ForEach-Object{
	$mcoll = "" | Select-Object UserPrincipalName, Licensestatus
	$USR = $_
	Write-Host "Processing................$USR" -ForegroundColor Magenta
	$O365Licences = $null
	$O365Licences = New-MsolLicenseOptions -AccountSkuId $licenseent -DisabledPlans $Disabledsvcs
	if ($mode -eq "Write")
	{
		Set-MsolUser -UserPrincipalName $USR -UsageLocation US
		Set-MsolUserLicense -addlicenses $licenseent -UserPrincipalName $USR -LicenseOptions $O365Licences
	}
	if ($error)
	{
		Write-host "Error occured applying license for $USR" -foregroundcolor yellow
		$mcoll.Userprincipalname = $USR
		$mcoll.Licensestatus = "error"
		$error.clear()
	}
	else
	{
		Write-host "Applying license for $USR" -foregroundcolor blue
		$mcoll.Userprincipalname = $USR
		$mcoll.Licensestatus = "Applied"
	}
	$collection2 += $mcoll
}
#########################export collections##############
if ($collection1) { $collection1 | Select-Object UserPrincipalName, @{ Name = "DisabledSVC"; Expression = { $_.DisabledSVC } } | Export-Csv $report1 -NoTypeInformation }
if ($collection2) { $collection2 | Export-Csv $report2 -NoTypeInformation }

Stop-Transcript
########Script Finished########