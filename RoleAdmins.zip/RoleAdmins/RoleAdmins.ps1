﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	6/5/2018 9:47 AM
	 Created by:   	Vikas Sukhija (http://SysCloudPro.com)
	 Organization: 	
	 Filename:     	RoleAdmins.ps1
	===========================================================================
	.DESCRIPTION
		To extract the Admins from o365
#>
###connect to MSOL#################
Connect-MsolService
$collection =@()
$AllRoles = Get-MsolRole

$AllRoles | ForEach-Object{
	$rolName = $_.Name
	$rolobjid = $_.Objectid
	$description = $_.Description
	Write-Host "Extracting........$rolName" -ForegroundColor Green
	$getroleadmins = Get-MsolRoleMember -RoleObjectId $rolobjid
	$getroleadmins | ForEach-Object{
		$mcoll = "" | select USerId, RoleName, Description
		$uid=$null
		$uid = $_.EmailAddress
		$mcoll.USerId = $uid
		$mcoll.RoleName = $rolName
		$mcoll.description = $description
		$collection += $mcoll
	}
}
$collection | Export-Csv .\o365Admins.csv -NoTypeInformation

##############################################