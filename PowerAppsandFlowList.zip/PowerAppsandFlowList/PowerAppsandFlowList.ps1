<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	01/10/2019 1:46 PM
    Created by:   	Vikas Sukhija
    Organization: 	
    Filename:     	PowerAppsandFlowList.ps1
    ===========================================================================
    .DESCRIPTION
    Extract and publish all the powerapps and flows in the enviornment
#>
function Write-Log
{
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [array]$Name,
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [string]$Ext,
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [string]$folder,
    
    [Parameter(ParameterSetName = 'Create',Position = 0)][switch]$Create,
    
    [Parameter(Mandatory = $true,ParameterSetName = 'Message')]
    [String]$Message,
    [Parameter(Mandatory = $true,ParameterSetName = 'Message')]
    [String]$path,
    [Parameter(Mandatory = $false,ParameterSetName = 'Message')]
    [ValidateSet('Information','Warning','Error')]
    [string]$Severity = 'Information',
    
    [Parameter(ParameterSetName = 'Message',Position = 0)][Switch]$MSG
  )
  switch ($PsCmdlet.ParameterSetName) {
    "Create"
    {
      $log = @()
      $date1 = Get-Date -Format d
      $date1 = $date1.ToString().Replace("/", "-")
      $time = Get-Date -Format t
	
      $time = $time.ToString().Replace(":", "-")
      $time = $time.ToString().Replace(" ", "")
	
      foreach ($n in $Name)
      {$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"}
      return $log
    }
    "Message"
    {
      $date = Get-Date
      $concatmessage = "|$date" + "|   |" + $Message +"|  |" + "$Severity|"
      switch($Severity){
        "Information"{Write-Host -Object $concatmessage -ForegroundColor Green}
        "Warning"{Write-Host -Object $concatmessage -ForegroundColor Yellow}
        "Error"{Write-Host -Object $concatmessage -ForegroundColor Red}
      }
      
      Add-Content -Path $path -Value $concatmessage
    }
  }
}
function ProgressBar
{
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true)]
    $Title,
    [Parameter(Mandatory = $true)]
    [int]$Timer
  )
	
  For ($i = 1; $i -le $Timer; $i++)
  {
    Start-Sleep -Seconds 1;
    Write-Progress -Activity $Title -Status "$i" -PercentComplete ($i /10 * 100)
  }
}
function LaunchMSOL 
{
  param
  (
    $UserCredential
  )
  Import-Module msonline
  Write-Host "Enter MS Online Credentials" -ForegroundColor Green
  Connect-MsolService -Credential $UserCredential
}
	
Function RemoveMSOL {Write-Host "Close Powershell Window - No disconnect available" -ForegroundColor yellow}
#################Check if logs folder is created##################
$logpath  = (Get-Location).path + "\logs" 
$testlogpath = Test-Path -Path $logpath
if($testlogpath -eq $false)
{
  ProgressBar -Title "Creating logs folder" -Timer 10
  New-Item -Path (Get-Location).path -Name Logs -Type directory
}

$reportpath = (Get-Location).path + "\Report"
$testReportpath = Test-Path -Path $reportpath
if($testReportpath -eq $false)
{
  ProgressBar -Title "Creating Report folder" -Timer 10
  New-Item -Path (Get-Location).path -Name Report -Type directory
}

##########################Load variables & Logs####################
$log = Write-Log -Name "process_PowerappsFlowListReport" -folder logs -Ext log
$output1 = Write-Log -Name "PowerAppsList" -folder Report -Ext html
$output2 = Write-Log -Name "FlowList" -folder Report -Ext html
$collection1 = @()
$collection = @()

$smtpserver = "smtpserver"
$from = "DoNotReply@labtest.com"
$erroremail = "sukhijavikas@labtest.com"

#####################userid/password##########################
$userId = 'sukhija@labtest.com'
$encrypted1 = Get-Content .\password1.txt
$pwd = ConvertTo-SecureString -string $encrypted1
$Credential = New-Object System.Management.Automation.PSCredential -ArgumentList $userId, $pwd

##########Start Script main##############
Start-Transcript -Path $log

############Format HTML###########
$HTMLFormat = "<style>"
$HTMLFormat = $HTMLFormat + "BODY{background-color:GainsBoro;}"
$HTMLFormat = $HTMLFormat + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$HTMLFormat = $HTMLFormat + "TH{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:darksalmon}"
$HTMLFormat = $HTMLFormat + "TD{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:LightBlue}"
$HTMLFormat = $HTMLFormat + "</style>"
################################

try
{
  Add-PowerAppsAccount -Username $userId -Password $pwd
  LaunchMSOL -UserCredential $Credential
}
catch
{
  Write-Host "$($_.Exception.Message)" -foregroundcolor red
  Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Error - Loading PowerAPPS and Flow Module" -Body $($_.Exception.Message)
  break
}


$collection1 = Get-AdminPowerApp | select DisplayName, AppName, Owner, EnvironmentName, CreatedTime, LastModifiedTime

$collection1 | ForEach-Object{
  $coll = "" | select DisplayName, AppName, Owner, EnvironmentName, CreatedTime, LastModifiedTime
  $coll.DisplayName = $_.DisplayName
  $coll.AppName = $_.AppName
  $coll.Owner = $_.Owner.UserPrincipalName
  $coll.EnvironmentName = $_.EnvironmentName
  $coll.CreatedTime = $_.CreatedTime
  $coll.LastModifiedTime = $_.LastModifiedTime
  $collection += $coll
}

$count = $collection.count
$collection |
ConvertTo-Html -Head $HTMLFormat -Body "<H2><Font Size = 4,Color = DarkCyan>All PowerApps = $count</Font></H2>" -AS Table |
Set-Content $output1
Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "PowerApps - Report"  -Attachments $output1
#########################fetch all flows###############################
$collection1 = @()
$collection = @()

$collection1 = Get-AdminFlow | select DisplayName, FlowName, CreatedBy, EnvironmentName, Enabled,CreatedTime, LastModifiedTime

$collection1 | ForEach-Object{
  $coll = "" | select DisplayName, FlowName, CreatedBy, EnvironmentName, Enabled,CreatedTime, LastModifiedTime
  $coll.DisplayName = $_.DisplayName
  $coll.FlowName = $_.FlowName
  $objectid = $_.CreatedBy.objectid
  $msoluser = Get-MsolUser -ObjectId $objectid  -ErrorAction SilentlyContinue
  Write-Host "Processing ..................."$msoluser.UserPrincipalName""
  $coll.CreatedBy = $msoluser.UserPrincipalName
  $coll.Enabled = $_.Enabled
  $coll.EnvironmentName = $_.EnvironmentName
  $coll.CreatedTime = $_.CreatedTime
  $coll.LastModifiedTime = $_.LastModifiedTime
  $collection += $coll
}

$count = $collection.count
$collection |
ConvertTo-Html -Head $HTMLFormat -Body "<H2><Font Size = 4,Color = DarkCyan>All Flows = $count</Font></H2>" -AS Table |
Set-Content $output2
Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Flow - Report"  -Attachments $output2
RemoveMSOL

########################Recycle reports & logs##############
$path1 = (Get-Location).path + "\report"
$path2 = (Get-Location).path + "\logs" 

$limit = (Get-Date).AddDays(-60) #for report recycling
Get-ChildItem -Path $path1 |
Where-Object {$_.CreationTime -lt $limit} |
Remove-Item -recurse -Force

Get-ChildItem -Path $path2 |
Where-Object {$_.CreationTime -lt $limit} |
Remove-Item -recurse -Force

Get-Date
Write-Host "Script finished" -ForegroundColor green
Stop-Transcript
Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Transcript Log - PowerAppsFlowReport" -Body "Transcript Log - SPowerAppsFlowReport" -Attachments $log
##############################################################################