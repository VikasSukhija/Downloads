####################################################################
#       Author: Vikas Sukhija
#       Date: 03/19/2013
#       Description: Event ID 5146 
#	Monitoring for sharepoint servers
####################################################################

$fromadd = �sharepointdown@labtest.com�
$email1=�Messagingsupport@labtest.com�
$email2="phonenumber@vtext.com"  #### example: 123456@vtext.com for verizon
$smtpServer="Smtp server"

$eventid = "5146"


$daystocheck = [DateTime]::Now.AddMinutes(-30)

$server_list=@("server1","server2")

$server_list | foreach-object {

$data = @()

$record=Get-WinEvent -ComputerName $_ -LogName system -MaxEvents 100 
$record
$coll = $record | where{($daystocheck -le $_.TimeCreated) -and ($_.id -eq $eventid)}
write-host "-------------------------------------------" -foregroundcolor green
$coll
if($coll -ne $null)

{

$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.To.Add($email2)
$msg.Subject = "$eventid Crash $_"
$smtp.Send($msg)

}

}

#########################################################################