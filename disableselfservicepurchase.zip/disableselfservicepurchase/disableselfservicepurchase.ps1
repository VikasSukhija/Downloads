﻿<#	
    .NOTES
    ===========================================================================
    Created on:   	7/7/2022 12:01 PM
    Created by:   	Vikas Sukhija (http://techwizard.cloud)
    Organization: 	
    Filename:     	disableselfservicepurchase.ps1
    Modules:        vsadmin,MSCommerce(modified to use ps credentials)
    Reference:       https://github.com/MicrosoftDocs/microsoft-365-docs/issues/799
    ===========================================================================
    .DESCRIPTION
    This script will disable the self service purchase options that appears for M365
#>
[CmdletBinding()]
param
(
  $PolicyId = 'AllowSelfServicePurchase',
  [Parameter(Mandatory = $true)]
  $smtpserver,
  [Parameter(Mandatory = $true)]
  $from,
  [Parameter(Mandatory = $true)]
  $erroremail,
  $logrecyclelimit = '60'
) 
###############ADD Logs and Variables#####################
$log = Write-Log -Name "disableselfservicepurchase" -folder "logs" -Ext "log"
$Report = Write-Log -Name "disableselfservicepurchase" -folder "Report" -Ext "csv"

##########Start Script main##############################
Write-Log -message "Start ......... Script" -path $log
Write-Log -Message "Get Crendetials for Admin ID" -path $log
if(Test-Path -Path ".\Password.xml"){
  Write-Log -Message "Password file Exists" -path $log
}else{
  Write-Log -Message "Generate password" -path $log
  $Credential = Get-Credential 
  $Credential | Export-Clixml ".\Password.xml"
}
#############################################################
$Credential = $null
$Credential = Import-Clixml ".\Password.xml"
try
{
  Import-Module .\MSCommerce\MSCommerce.psm1
  Add-Type -Path .\MSCommerce\Microsoft.IdentityModel.Clients.ActiveDirectory.dll
  Connect-MSCommerce -adminaccount $Credential
}
catch
{
  $($_.Exception.Message)
  Write-Log -message "exception has occured" -path $log
  Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Error - disableselfservicepurchase" -Body $($_.Exception.Message)
  break
}
	
try
{   
  Write-Log -message "fetch all products for $PolicyId" -path $log
  $collection = @()
  $allpolicies = Get-MSCommerceProductPolicies -PolicyId $PolicyId
  $allpolicies | ForEach-Object -Process {
    $coll = "" | Select-Object -Property ProductName, ProductID, CurrentPolicyValue, NewPolicyValue
    $productname = $_.ProductName
    $productid = $_.ProductID
    $policyvalue = $_.PolicyValue
    $coll.ProductName = $productname
    $coll.ProductID = $productid
    $coll.CurrentPolicyValue = $policyvalue
    if($policyvalue -eq 'Enabled')
    {
      Write-Log -message "Disable Self Purchase for - $productname" -path $log
      Update-MSCommerceProductPolicy -PolicyId $PolicyId -ProductId $productid -Enabled $False
      $coll.NewPolicyValue = 'Disabled'
    }
    $collection += $coll
  }
  Write-Log -message "Export all products for $PolicyId" -path $log
  $collection | Export-Csv $Report -NoTypeInformation
  $enabledproducts = $collection | Where-Object -FilterScript {
    $_.PolicyValue -eq 'Enabled'
  }
  if($enabledproducts)
  {
    Write-Log -message "Send Report of Disabled Products" -path $log
    Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Report - disableselfservicepurchase" -Attachments $Report
  }
}
catch
{
  Write-Log -message "$($_.Exception.Message)" -path $log
  Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Error - List Reading disableselfservicepurchase" -Body $($_.Exception.Message)
  Break
}	
Set-Recyclelogs -foldername "logs" -limit $logrecyclelimit -Confirm:$False
Set-Recyclelogs -foldername "Report" -limit $logrecyclelimit -Confirm:$False
Write-Log -message "Script finished" -path $log
Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Log - disableselfservicepurchase" -Attachments $log
###################################################################################

# SIG # Begin signature block
# MIIoSgYJKoZIhvcNAQcCoIIoOzCCKDcCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUqe799IwgIVrwZqjd674bZ4ba
# V5eggiJtMIIFsTCCBJmgAwIBAgIQASQK+x44C4oW8UtxnfTTwDANBgkqhkiG9w0B
# AQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVk
# IElEIFJvb3QgQ0EwHhcNMjIwNjA5MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQsw
# CQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cu
# ZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz
# 7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS
# 5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7
# bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfI
# SKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jH
# trHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14
# Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2
# h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp493ADkRSWJtppEGSt+wJS00mFt
# 6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPR
# iQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ER
# ElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4K
# Jpn15GkvmB0t9dmpsh3lGwIDAQABo4IBXjCCAVowDwYDVR0TAQH/BAUwAwEB/zAd
# BgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SS
# y4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUF
# BwMIMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaG
# NGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RD
# QS5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMA0GCSqGSIb3
# DQEBDAUAA4IBAQCaFgKlAe+B+w20WLJ4ragjGdlzN9pgnlHXy/gvQLmjH3xATjM+
# kDzniQF1hehiex1W4HG63l7GN7x5XGIATfhJelFNBjLzxdIAKicg6okuFTngLD74
# dXwsgkFhNQ8j0O01ldKIlSlDy+CmWBB8U46fRckgNxTA7Rm6fnc50lSWx6YR3zQz
# 9nVSQkscnY2W1ZVsRxIUJF8mQfoaRr3esOWRRwOsGAjLy9tmiX8rnGW/vjdOvi3z
# nUrDzMxHXsiVla3Ry7sqBiD5P3LqNutFcpJ6KXsUAzz7TdZIcXoQEYoIdM1sGwRc
# 0oqVA3ZRUFPWLvdKRsOuECxxTLCHtic3RGBEMIIGrjCCBJagAwIBAgIQBzY3tyRU
# fNhHrP0oZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UE
# ChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYD
# VQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcN
# MzcwMzIyMjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQs
# IEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEy
# NTYgVGltZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
# AgEAxoY1BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+k
# iPNo+n3znIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+va
# PcQXf6sZKz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RB
# idx8ald68Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn
# 7w6lY2zkpsUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAx
# E6lXKZYnLvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB
# 3iIU2YIqx5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNC
# aJ+2RrOdOqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklS
# UPRR8zZJTYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP
# 015LdhJRk8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXi
# YKNYCQEoAA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZ
# MBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCP
# nshvMB8GA1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQE
# AwIBhjATBgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5j
# cnQwQwYDVR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJ
# YIZIAYb9bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULh
# sBguEE0TzzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAl
# NDFnzbYSlm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XN
# Q1/tYLaqT5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ
# 8NWKcXZl2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDn
# mPv7pp1yr8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsd
# CEkPlM05et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcm
# a+Q4c6umAU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+
# 8kaddSweJywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6
# KYawmKAr7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAj
# fwAL5HYCJtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucT
# Dh3bNzgaoSv27dZ8/DCCBsYwggSuoAMCAQICEAp6SoieyZlCkAZjOE2Gl50wDQYJ
# KoZIhvcNAQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJ
# bmMuMTswOQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2
# IFRpbWVTdGFtcGluZyBDQTAeFw0yMjAzMjkwMDAwMDBaFw0zMzAzMTQyMzU5NTla
# MEwxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjEkMCIGA1UE
# AxMbRGlnaUNlcnQgVGltZXN0YW1wIDIwMjIgLSAyMIICIjANBgkqhkiG9w0BAQEF
# AAOCAg8AMIICCgKCAgEAuSqWI6ZcvF/WSfAVghj0M+7MXGzj4CUu0jHkPECu+6vE
# 43hdflw26vUljUOjges4Y/k8iGnePNIwUQ0xB7pGbumjS0joiUF/DbLW+YTxmD4L
# vwqEEnFsoWImAdPOw2z9rDt+3Cocqb0wxhbY2rzrsvGD0Z/NCcW5QWpFQiNBWvhg
# 02UsPn5evZan8Pyx9PQoz0J5HzvHkwdoaOVENFJfD1De1FksRHTAMkcZW+KYLo/Q
# yj//xmfPPJOVToTpdhiYmREUxSsMoDPbTSSF6IKU4S8D7n+FAsmG4dUYFLcERfPg
# OL2ivXpxmOwV5/0u7NKbAIqsHY07gGj+0FmYJs7g7a5/KC7CnuALS8gI0TK7g/oj
# PNn/0oy790Mj3+fDWgVifnAs5SuyPWPqyK6BIGtDich+X7Aa3Rm9n3RBCq+5jgnT
# dKEvsFR2wZBPlOyGYf/bES+SAzDOMLeLD11Es0MdI1DNkdcvnfv8zbHBp8QOxO9A
# Phk6AtQxqWmgSfl14ZvoaORqDI/r5LEhe4ZnWH5/H+gr5BSyFtaBocraMJBr7m91
# wLA2JrIIO/+9vn9sExjfxm2keUmti39hhwVo99Rw40KV6J67m0uy4rZBPeevpxoo
# ya1hsKBBGBlO7UebYZXtPgthWuo+epiSUc0/yUTngIspQnL3ebLdhOon7v59emsC
# AwEAAaOCAYswggGHMA4GA1UdDwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG
# /WwHATAfBgNVHSMEGDAWgBS6FtltTYUvcyl2mi91jGogj57IbzAdBgNVHQ4EFgQU
# jWS3iSH+VlhEhGGn6m8cNo/drw0wWgYDVR0fBFMwUTBPoE2gS4ZJaHR0cDovL2Ny
# bDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRp
# bWVTdGFtcGluZ0NBLmNybDCBkAYIKwYBBQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBYBggrBgEFBQcwAoZMaHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1
# NlRpbWVTdGFtcGluZ0NBLmNydDANBgkqhkiG9w0BAQsFAAOCAgEADS0jdKbR9fjq
# S5k/AeT2DOSvFp3Zs4yXgimcQ28BLas4tXARv4QZiz9d5YZPvpM63io5WjlO2IRZ
# pbwbmKrobO/RSGkZOFvPiTkdcHDZTt8jImzV3/ZZy6HC6kx2yqHcoSuWuJtVqRpr
# fdH1AglPgtalc4jEmIDf7kmVt7PMxafuDuHvHjiKn+8RyTFKWLbfOHzL+lz35FO/
# bgp8ftfemNUpZYkPopzAZfQBImXH6l50pls1klB89Bemh2RPPkaJFmMga8vye9A1
# 40pwSKm25x1gvQQiFSVwBnKpRDtpRxHT7unHoD5PELkwNuTzqmkJqIt+ZKJllBH7
# bjLx9bs4rc3AkxHVMnhKSzcqTPNc3LaFwLtwMFV41pj+VG1/calIGnjdRncuG3rA
# M4r4SiiMEqhzzy350yPynhngDZQooOvbGlGglYKOKGukzp123qlzqkhqWUOuX+r4
# DwZCnd8GaJb+KqB0W2Nm3mssuHiqTXBt8CzxBxV+NbTmtQyimaXXFWs1DoXW4CzM
# 4AwkuHxSCx6ZfO/IyMWMWGmvqz3hz8x9Fa4Uv4px38qXsdhH6hyF4EVOEhwUKVjM
# b9N/y77BDkpvIJyu2XMyWQjnLZKhGhH+MpimXSuX4IvTnMxttQ2uR2M4RxdbbxPa
# ahBuH0m3RFu0CAqHWlkEdhGhp3cCExwwggdtMIIGVaADAgECAhMUAANc8ih+Si+k
# XGn/AAAAA1zyMA0GCSqGSIb3DQEBCwUAMGoxEzARBgoJkiaJk/IsZAEZFgNjb20x
# FjAUBgoJkiaJk/IsZAEZFgZib3NzY2kxFDASBgoJkiaJk/IsZAEZFgRic2NpMSUw
# IwYDVQQDExxCU0NJLUVudFN1YkNBLVByaXZhdGUtU0hBMjU2MB4XDTIyMDYwODE3
# MTA0NloXDTI0MDYwNzE3MTA0NlowazELMAkGA1UEBhMCVVMxEjAQBgNVBAgTCU1p
# bm5lc290YTETMBEGA1UEBxMKU2FpbnQgUGF1bDENMAsGA1UEChMEQlNDSTEMMAoG
# A1UECxMDQ1RTMRYwFAYDVQQDEw1hY3NpLmJzY2kuY29tMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAuglwtcKjHqkH+m+vSPmS5EORAxtaJ2s2xBa85Hg6
# kf+d+mi8bKsRJxgUCN7dHDkEiXZitppUCu9oKvl4pN+rLnswDD15VrwuOyuYMkRk
# diSKvejaug4E5h9hdpyYaENfxxFDukKIKu2JVCHXsS9EbqvAH+IhV+mWUl883wCD
# 2SIRdFknQ3l43gvSvCq1R6WypqXxK3lNOo7jyKLVB8KwSgLMig1l+kK7pndd9zeu
# G3QgRZPVjhoNqqZRRuc8uwGa9y35cRxVJW9vceVgJVLgg4m5aOoznzyXFyF+4aB9
# 7tqtvZcMuptlGJE0iE09Nb3akJkcMaqDTupyJYNTV/5R6QIDAQABo4IECTCCBAUw
# HQYDVR0OBBYEFIDmrT6XdnUz9NRYb+QIARe6YYY8MB8GA1UdIwQYMBaAFGqRzcmw
# AsNJYfdzHN38XsLx9lVIMIIBZwYDVR0fBIIBXjCCAVowggFWoIIBUqCCAU6GgcZs
# ZGFwOi8vL0NOPUJTQ0ktRW50U3ViQ0EtUHJpdmF0ZS1TSEEyNTYsQ049bmF0Y2Vy
# dGFwMDIsQ049Q0RQLENOPVB1YmxpYyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZp
# Y2VzLENOPUNvbmZpZ3VyYXRpb24sREM9Ym9zc2NpLERDPWNvbT9jZXJ0aWZpY2F0
# ZVJldm9jYXRpb25MaXN0P2Jhc2U/b2JqZWN0Q2xhc3M9Y1JMRGlzdHJpYnV0aW9u
# UG9pbnSGOmh0dHA6Ly9zaGVtcC5ic2NpLmNvbS9wa2kvQlNDSS1FbnRTdWJDQS1Q
# cml2YXRlLVNIQTI1Ni5jcmyGR2h0dHA6Ly9uYXRjZXJ0YXAwMi5ic2NpLmJvc3Nj
# aS5jb20vcGtpL0JTQ0ktRW50U3ViQ0EtUHJpdmF0ZS1TSEEyNTYuY3JsMIIB2QYI
# KwYBBQUHAQEEggHLMIIBxzCBugYIKwYBBQUHMAKGga1sZGFwOi8vL0NOPUJTQ0kt
# RW50U3ViQ0EtUHJpdmF0ZS1TSEEyNTYsQ049QUlBLENOPVB1YmxpYyUyMEtleSUy
# MFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZpZ3VyYXRpb24sREM9Ym9zc2Np
# LERDPWNvbT9jQUNlcnRpZmljYXRlP2Jhc2U/b2JqZWN0Q2xhc3M9Y2VydGlmaWNh
# dGlvbkF1dGhvcml0eTBvBggrBgEFBQcwAoZjaHR0cDovL25hdGNlcnRhcDAyLmJz
# Y2kuYm9zc2NpLmNvbS9wa2kvbmF0Y2VydGFwMDIuYnNjaS5ib3NzY2kuY29tX0JT
# Q0ktRW50U3ViQ0EtUHJpdmF0ZS1TSEEyNTYuY3J0MGIGCCsGAQUFBzAChlZodHRw
# Oi8vc2hlbXAuYnNjaS5jb20vcGtpL25hdGNlcnRhcDAyLmJzY2kuYm9zc2NpLmNv
# bV9CU0NJLUVudFN1YkNBLVByaXZhdGUtU0hBMjU2LmNydDAzBggrBgEFBQcwAYYn
# aHR0cDovL25hdGNlcnRhcDAyLmJzY2kuYm9zc2NpLmNvbS9vY3NwMAsGA1UdDwQE
# AwIHgDA8BgkrBgEEAYI3FQcELzAtBiUrBgEEAYI3FQi5uyCBsYJIhe2DCIirDYLy
# ulSBfYPIxneHlOBGAgFkAgEFMBMGA1UdJQQMMAoGCCsGAQUFBwMDMBsGCSsGAQQB
# gjcVCgQOMAwwCgYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAAxVu2CRWpEk
# /OPPKWmH5YrFxhnyWu6h5xriy1Vf2v1TZg/XGKJ1w3c54o8/lV+WmBlq0PgmNC9m
# zbiGerpc4bXk50a9Hjv1w379XpLl+VDeGyTzJyQggePNwtbZiqm5cT9wTUY8pH24
# Xc57DfXLRZUctaW+70rfc1dk42h+CnfprHcryL57jf2LTgVKyHYGM7bCQbZNGoSZ
# s0pYBoEWy/5N7kbG7NNqexDhpw6g1dUAzog7+ScTplefm2lJAuU2QIPaf1Y9mKlI
# iD7/tPoo2AJYZip4qJGqlzxmWnRxgh9K8Hytf5f6zZZ2Tvfq4iO1d2cZ8RnwqfaU
# Yar9ZLV1ul4wggfHMIIFr6ADAgECAhN5AAAAApT+NAr/R95/AAAAAAACMA0GCSqG
# SIb3DQEBCwUAMCUxIzAhBgNVBAMTGkJTQ0ktUm9vdENBLVByaXZhdGUtU0hBMjU2
# MB4XDTE2MDIxNzE5MTIwOFoXDTI2MDIxNzE5MjIwOFowajETMBEGCgmSJomT8ixk
# ARkWA2NvbTEWMBQGCgmSJomT8ixkARkWBmJvc3NjaTEUMBIGCgmSJomT8ixkARkW
# BGJzY2kxJTAjBgNVBAMTHEJTQ0ktRW50U3ViQ0EtUHJpdmF0ZS1TSEEyNTYwggEi
# MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHTOBgyph/ejsOJQs7O56AAKqm
# HMxdlxUhwwqwDGKnZ1fQVWLEcOz/egpFZQvyEJ16NmY4V1S/CwjspD0t9UyCjiFS
# iAFIYwFzdqOq1AD5zqLA2LtBgmqkxXjF5Ik/7hpmWBJzSWCw/O1WBf9WnM6+8G05
# kvB7Zef/tPr6SLAiuSrejUaY3ytEPi1uuPnH0UIXBTfZo53B6XJQs92SmKEaVonv
# UCAO2Q+TuvyCYt37Cddqa9uNWXpRn1RYoXIMpWgRNeyEJPRnbljK1Jo/GM88IC9Y
# m1ArsWufkBXIN7HB1PH9XdYLrDJmaVsBdMaTrdpHIyUt0bH+chGxuCESLG/hAgMB
# AAGjggOpMIIDpTAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQUapHNybACw0lh
# 93Mc3fxewvH2VUgwggIXBgNVHSAEggIOMIICCjCCAgYGDCsGAQQBgvA1hAABBDCC
# AfQwTgYIKwYBBQUHAgEWQmh0dHA6Ly9uYXRjZXJ0YXAwMi5ic2NpLmJvc3NjaS5j
# b20vUEtJL0ludGVybmFsVXNlLVBLSXBvbGljeS5odG1sADCCAaAGCCsGAQUFBwIC
# MIIBkh6CAY4ATABlAGcAYQBsACAAUABvAGwAaQBjAHkAIABTAHQAYQB0AGUAbQBl
# AG4AdAAgAC0AIABUAGgAaQBzACAAUABLAEkAIABpAHMAIABmAG8AcgAgAGkAbgB0
# AGUAcgBuAGEAbAAgAEIAbwBzAHQAbwBuACAAUwBjAGkAZQBuAHQAaQBmAGkAYwAg
# AHMAeQBzAHQAZQBtAHMALgAgAFIAZQBmAGUAcgAgAHQAbwAgAHQAaABlACAAYQBz
# AHMAbwBjAGkAYQB0AGUAZAAgAEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAFAAcgBh
# AGMAdABpAGMAZQAgAFMAdABhAHQAZQBtAGUAbgB0ACAAKABDAFAAUwApACAAZgBv
# AHIAIABtAG8AcgBlACAAaQBuAGYAbwByAG0AYQB0AGkAbwBuAC4AIABBAG4AeQAg
# AG8AdABoAGUAcgAgAHUAcwBhAGcAZQAgAGkAcwAgAHMAdAByAGkAYwB0AGwAeQAg
# AHAAcgBvAGgAaQBiAGkAdABlAGQALjAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMA
# QTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBR8Z++u
# tUb9qV0GMkqiieBN/wq12DBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vbmF0Y2Vy
# dGFwMDIuYnNjaS5ib3NzY2kuY29tL3BraS9CU0NJLVJvb3RDQS1Qcml2YXRlLVNI
# QTI1Ni5jcmwwgaQGCCsGAQUFBwEBBIGXMIGUMF0GCCsGAQUFBzAChlFodHRwOi8v
# bmF0Y2VydGFwMDIuYnNjaS5ib3NzY2kuY29tL3BraS9uYXRjZXJ0YXAwMV9CU0NJ
# LVJvb3RDQS1Qcml2YXRlLVNIQTI1Ni5jcnQwMwYIKwYBBQUHMAGGJ2h0dHA6Ly9u
# YXRjZXJ0YXAwMi5ic2NpLmJvc3NjaS5jb20vb2NzcDANBgkqhkiG9w0BAQsFAAOC
# AgEArqWUBtTAwXctRrWSHI3nVFN4AIo74P0IrGKCODCvNtMXgLw0/eGT1aa2SaEn
# HMOk5sVi5nnR9Dol5JEiHWIZzxz8J8q5l0OdEpcorTRxB3jw1mjbrETMsERZHTr5
# 2SALZ2Ml5C03+3gJvfrO8R+DUcTleFXjhnLSQH3s59BFdi4Rkvm3Y9XD226afgMa
# JSWEdUMxM5d4ld+IeUl65NJtUk2kpRawON+Y3pW98Pe79eaw/+udE9ZLa/HpM1/H
# RD38BDC4y2LJQ9v1UG94ylUfp77yMJT3qnB5Qtj9tZDwQt2dZUbURiMvxvz3mBLj
# sMRCvrDdATHzjEYPT+rSQvFLqInG6p9T0iFoKIF7SzrRQ2PempyNm+l7kXTVP0EB
# P2+YSeM3GX8M1y/luYFAgGRRLNRAheF8rqe3eNeHR3baCjwGw4pRTDqf5BTAQ3c9
# DsSNEw8/cj+suGiv7utqi3chxzWSTO9TlYs/Lnn8QJfD0AboVftGEMQSKUgE9vXv
# 28tjKgJN1zqGIuAcEZ7f9GXKRLODMhZ0Z/17qqGMd+HXvz1/OnxdvtaFA5V5VSue
# q4vOCOZ7wJE/ORQ54sPRIihY2kQabkBJArj7Omz60zYIYmrN+aFSrrt2Z8pq8Zu7
# QDHQfbrUgP6geZimB4ynlsqs9fSk+X9GSK0JUKpsacOq4/4xggVHMIIFQwIBATCB
# gTBqMRMwEQYKCZImiZPyLGQBGRYDY29tMRYwFAYKCZImiZPyLGQBGRYGYm9zc2Np
# MRQwEgYKCZImiZPyLGQBGRYEYnNjaTElMCMGA1UEAxMcQlNDSS1FbnRTdWJDQS1Q
# cml2YXRlLVNIQTI1NgITFAADXPIofkovpFxp/wAAAANc8jAJBgUrDgMCGgUAoHgw
# GAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGC
# NwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQx
# FgQUTxVCWlW50gjQDsnsgK3ZC0LiUBYwDQYJKoZIhvcNAQEBBQAEggEAF3bzWatK
# QsdBxUPDskOwsIiDoDn6Var9pv5DmvOQuG5nSi38KMD9hWfxgGP6cJ4NNbePxf89
# EM/cyDgXqC2+SJf+buQdv/dJuSw1gd5moy4Zof96wfO9c/LXManmUHugXKO67hYf
# ci7bfRMYwiFIAMqhKWrwmYaYqXrimDg3iCWbqID9cAcbAXsOVBYi7x4YakD5JFQQ
# 0XUUYjoQforfwvTBkctsbLpnLdNdNqL15q+XrWuNZ+/TZUZLoolM8lKsVzpdEQPR
# 1x7PwTWCEgfGLYbrws7F4IBARKG8OAnhgvDzHjy1nWWKXjTCqe+R9zO1Abdm4HuF
# J4OK8vRgtF6qhqGCAyAwggMcBgkqhkiG9w0BCQYxggMNMIIDCQIBATB3MGMxCzAJ
# BgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGln
# aUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EC
# EAp6SoieyZlCkAZjOE2Gl50wDQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMx
# CwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yMjA3MjIxNDQ0NTBaMC8GCSqG
# SIb3DQEJBDEiBCBQk39vDNhJOFLdOIRAaHD1dxO0dKAy+anluOchn/TrGDANBgkq
# hkiG9w0BAQEFAASCAgBjW8N/FUk5jl9Li03oSBSPqHEe5l0uT6qDvuqbaAHyN5a0
# 7MIp8BcqTWYr3kETwVES12jZn+1dmhdOvvxl9YYrIE01XY3yE6IoWE34SMGcYu/M
# mpyFLwI0lcvERucYf871QQgaiQjImnWDIB8iHWMHEQTaeJzXkmitcD55iDjz8FM4
# g8jp+leRLan7Q3vBlQUfAlmcEr6ZPJDyKZ3JZQ6viRvjuLnL/A7du1E2oY2p/Ywk
# 4tOea4lhiKk4MvMSUjE8sfrIlHWCmRyFc5VE/p/bUFKyMv6jmMWeZsi4a19AO6Ym
# +eZw+sihkAP3pYAFykQulA+l24sWsBKchbHXhdHAFaV8HT310tWo6YiugcecnPn3
# lhf2mEhLF4gr25Zjnwbi9K38ulM/GE1wJbTlShrv60nZe944sJfXAeNP60x8CWfu
# yyQqiq+M0Of8PW0QrxcV1BDSk7KQMLUZL3EilJipv+yv0FlKk+LAs+fdRoolNFTZ
# TPQa77UsoCUai1Z60UvP9KHkK+GFPrBSNym5pM7yzcuEfMvGir/7BSjK3JKXPm8J
# +DSG8iS+05qfcFmB1r51zlypt1ORVj4eWLOEX3OIpU979XxBgccB1t8LiTui2tko
# uPG+oHRf6niZKef2+ZfMfVfQYvAdjwufI/xUK+3Ri1zGGvEge+lQhhmqXMlw0g==
# SIG # End signature block
