﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	3/10/2018 2:26 PM
	 Created by:   	Vikas Sukhija
	 Organization: 	
	 Filename:     	o365GroupReport.ps1
	===========================================================================
	.DESCRIPTION
		This will report All owners of office 365 group Sites
#>
#############Load Functions#################
$error.clear()
try { stop-transcript | out-null }
catch { $error.clear() }

function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}

function LaunchSHO
{
	param
	(
		$orgName,
		$cred
	)
	
	Write-Host "Enter Sharepoint Online Credentials" -ForegroundColor Green
	$userCredential = $cred
	Connect-SPOService -Url "https://$orgName-admin.sharepoint.com" -Credential $userCredential
}

Function RemoveSHO
{
	
	disconnect-sposervice
}

function LaunchEOL
{
	param
	(
		$cred
	)
	
	$UserCredential = $cred
	
	$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
	
	Import-PSSession $Session -Prefix "EOL" -AllowClobber
}



Function RemoveEOL
{
	
	$Session = Get-PSSession | where { $_.ComputerName -like "outlook.office365.com" }
	Remove-PSSession $Session
	
}
##########################Load variables & Logs####################
$log = Write-Log -Name "process_o365groupOwnerReport" -folder logs -Ext log
$output1 = Write-Log -Name "o365groupOwner" -folder Report -Ext html
$output2 = Write-Log -Name "o365groupOwner1" -folder Report -Ext html
$orgname = "Company"
$collection1 = @()
$collection = @()

########Start Script main##############

Start-Transcript -Path $log
$cred = Get-Credential
try
{
	Write-Host "Connecting to SPO" -ForegroundColor Green
	LaunchSHO -orgName $orgname -cred $cred
}
catch
{
	write-host "$($_.Exception.Message)" -foregroundcolor red
	Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "SP Online Error o365 group owner Report" -Body $($_.Exception.Message)
	break
}
try
{
	Write-Host "Connecting to EOL" -ForegroundColor Green
	LaunchEOL -cred $cred
}
catch
{
	write-host "$($_.Exception.Message)" -foregroundcolor red
	Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "SP Online -EOL Connection Error o365 group owner Report" -Body $($_.Exception.Message)
	break
}
$collection1 = get-EOLunifiedgroup -resultsize unlimited | Select ManagedByDetails, SharePointSiteUrl
$collection1 | ForEach-Object{
	$url = $_.SharePointSiteUrl
	$Owner = $_.ManagedByDetails
	$spsite = Get-SPOSite -id $url -ea silentlycontinue | where{ ($_.lockstate -eq "Unlock") } | select template, StorageUsageCurrent, StorageQuota, SharingCapability
	$Template = $spsite.template
	$StorageUsageCurrent = $spsite.StorageUsageCurrent
	$StorageQuota = $spsite.StorageQuota
	$SharingCapability = $spsite.SharingCapability
	Write-Host "processing...............$url" -ForegroundColor Green
	if ($Template -eq "GROUP#0") { $Template = "Office 365 Group Site" }
	if ($Template -eq "STS#0") { $Template = "Classic Team Site" }
	if ($Template -eq "SITEPAGEPUBLISHING#0") { $Template = "Communication Site" }
	<#$owner
	$Template
	$StorageUsageCurrent
	$StorageQuota#>
	$coll = "" | select url, owner, template, StorageUsageCurrent, StorageQuota, SharingCapability
	$coll.url = $url
	$coll.owner = $Owner
	$coll.template = $Template
	$coll.StorageUsageCurrent = $StorageUsageCurrent
	$coll.StorageQuota = $StorageQuota
	$coll.SharingCapability = $SharingCapability
	$collection += $coll
}
$collection = $collection | where{$_.url -ne $null}
RemoveSHO
RemoveEOL
############Format HTML###########
$HTMLFormat = "<style>"
$HTMLFormat = $HTMLFormat + "BODY{background-color:GainsBoro;}"
$HTMLFormat = $HTMLFormat + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$HTMLFormat = $HTMLFormat + "TH{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:darksalmon}"
$HTMLFormat = $HTMLFormat + "TD{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:LightBlue}"
$HTMLFormat = $HTMLFormat + "</style>"
################################

$collection | select  url, owner, template | ConvertTo-HTML -Head $HTMLFormat -Body "<H2><Font Size = 4,Color = DarkCyan>SharePoint Online office 365 Group Sites</Font></H2>" -AS Table |
Set-Content $output1
$collection | select  url, owner, template, SharingCapability, StorageUsageCurrent, StorageQuota  | ConvertTo-HTML -Head $HTMLFormat -Body "<H2><Font Size = 4,Color = DarkCyan>SharePoint Online office 365 Group Sites</Font></H2>" -AS Table |
Set-Content $output2

copy-item $output1 .\aspxreport\o365GroupSites.aspx
copy-item $output2 .\aspxreport\o365GroupSites1.aspx

########################Recycle reports & logs##############
$path1 = ".\report\"
$path2 = ".\Logs\"
$limit = (Get-Date).AddDays(-60) #for report recycling
Get-ChildItem -Path $path1 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

Get-ChildItem -Path $path2 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

get-date
Write-Host "Script finished" -ForegroundColor green
Stop-Transcript
##############################################################################

