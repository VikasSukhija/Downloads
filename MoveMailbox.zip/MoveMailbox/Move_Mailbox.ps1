####################################################################################
##           Script to Move Mailboxes from one db to another      
##           Author: Vikas Sukhija                       		
##           Modified:  09-01-2013      
##                                    				
####################################################################################
$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)

#####################Define Variables ###############################################

$SourceFile = ".\users.txt"
$TargetDatabase = "LABSERVER\First Storage Group\Mailbox Database"
$threads = "10"
$Log1 = "E:\scripts\MoveMailbox\" + "logs" + "\" + "Move_" + $date + "_.txt"

#####################################################################################


If ((Get-PSSnapin | where {$_.Name -match "Exchange.Management"}) -eq $null)
{
  Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin
}



$UserList = Get-Content $SourceFile
$userlist | get-mailbox | 
move-mailbox -TargetDatabase $TargetDatabase -BadItemLimit 5  `
-maxthreads $threads -Confirm: $false -ReportFile $Log1


######################################################################################