﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	2/27/2018 1:37 PM
	 Created by:   	Vikas Sukhija (http://SysCloudPro.com)
	 Organization: 	
	 Filename:     	SetSPDefaultQUota.ps1
	===========================================================================
	.DESCRIPTION
		This script will set the deafult quota of 10 GB to all Newly created sites
#>
$error.clear()
try { stop-transcript | out-null }
catch { $error.clear() }

function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}

function LaunchSPO
{
	param
	(
		$orgName,
		$cred
	)
	
	Write-Host "Enter Sharepoint Online Credentials" -ForegroundColor Green
	$userCredential = $cred
	Connect-SPOService -Url "https://$orgName-admin.sharepoint.com" -Credential $userCredential
}

Function RemoveSPO
{
	
	disconnect-sposervice
}
##########################Load variables & Logs####################
$log = Write-Log -Name "process_SpSiteDefaultQuota" -folder logs -Ext log
$report = Write-Log -Name "SetSPQuota" -folder Report -Ext csv
$orgname = "Company"
$collection = @()
$collection1 = @()
$quota = "10240"
$quotawarning = "9216"
$msdefquota = "1048576"
$smtpserver = "smtp.labtest.com"
$from = "Automate@labtest.com"
$erroremail = "Reports@labtest.com"
#####################userid/password##########################
$userId = "COMP-Auto-SVC@labtest.com"
$encrypted1 = "01000000d08c9ddf0115d1103660000c000000010000000edb3510a5e61c98c23c3ee14e6ac000bda93b938c97851f02070753d27b3bcd200000008a2352c3c28df30db902f7029fd8f0cd3c7bd3e88e4b865bbb76ffb412d03627140000006f7bbee447fb961f410b80029a2af3555767e135"
$pwd = ConvertTo-SecureString -string $encrypted1
$Credential = New-Object System.Management.Automation.PSCredential -ArgumentList $userId, $pwd
##########Start Script main##############

Start-Transcript -Path $log
$cred = $Credential
try
{
	LaunchSPO -orgName $orgname -cred $cred
}
catch
{
	write-host "$($_.Exception.Message)" -foregroundcolor red
	Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "SP Online ConnectionError Site owner Report" -Body $($_.Exception.Message)
	break
}
$collection = Get-SPOSite -Limit All | where{ ($_.lockstate -eq "Unlock") -and ($_.Url -notlike "*/portals/*") -and ($_.StorageQuota -eq $msdefquota) } | select url, owner, template, StorageUsageCurrent, StorageQuota

if ($collection)
{
	$collection | foreach-object{
		$mcoll = "" | select  url, owner, template, StorageUsageCurrent, StorageQuota, ModifiedQuota
		$mcoll.url = $_.url
		$mcoll.owner = $_.owner
		$mcoll.template = $_.template
		$mcoll.StorageUsageCurrent = $_.StorageUsageCurrent
		$mcoll.StorageQuota = $_.StorageQuota
		Set-SPOSite -identity $_.url -StorageQuota $quota -StorageQuotaWarningLevel $quotawarning
		if ($error)
		{
			$mcoll.ModifiedQuota = "Error"
		}
		else
		{
			$mcoll.ModifiedQuota = $quota
		}
		$mcoll
		$collection1 += $mcoll
	}
	$collection1 | Export-Csv $report -NoTypeInformation
	if ($error)
	{
		Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Error Occured - Set Default Quota SPOnline Sites" -Body $error[0].tostring() -Attachments $report
	}
}
RemoveSPO

########################Recycle reports & logs##############
$path1 = ".\report\"
$path2 = ".\Logs\"
$limit = (Get-Date).AddDays(-60) #for report recycling
Get-ChildItem -Path $path1 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

Get-ChildItem -Path $path2 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

get-date
Write-Host "Script finished" -ForegroundColor green
Stop-Transcript
#########################################################

Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Transcript Log - Set SPO Default Quota" -Attachments $log
Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Report - Set SPO Default Quota" -Attachments $report

############################################################