######################################################################
#               Author: Vikas Sukhija
#               Date:- 10/26/2015
#		Reviewer:-
#               Description:- Update Dial in group for Using in Disclaimer
#               
######################################################################

$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/","-")
$dir= ".\logs\"
$limit = (Get-Date).AddDays(-30)

$logs = ".\Logs" + "\" + "Processed_" + $date1 + "_.log"

$smtpServer = "smtpserver"
$fromadd = "DoNotReply@labtest.com"
$email1 = "Messaginge@labtest.com"

Start-Transcript -Path $logs

Import-Module 'C:\Program Files\Common Files\Microsoft Lync Server 2010\Modules\Lync\Lync.psd1'

$group = "OCS_Dialin_access"

$Lyncpol = "Ind Conferencing Policy Dial-in"

######################################Fucntion for getting groupDN########################

function checkgroupDN ($Group, $DomainRootPath) 
{ 
 
$Search = New-Object DirectoryServices.DirectorySearcher([ADSI]"$DomainRootPath") 
$Search.filter = "(&(objectCategory=group)(objectClass=group)(sAMAccountName=$Group))" 
$findgrp=$Search.Findall() 

if ($findgrp.count -gt 1)
      {    
            $count = 0
            foreach($i in $findgrp)
            {
                  write-host $count ": " $i.path
                  $count = $count + 1
		  write-host "multiple matches found"
            }

       exit
      }
      elseif ($findgrp.count -gt 0)
      {
            return $findgrp[0].path
      }
      else
      {
      write-host "no match found"

      }
}

######################################Fucntion for getting UserDN########################

function checkuserDN ($usersm, $DomainRootPath) 
{ 
 
$Search = New-Object DirectoryServices.DirectorySearcher([ADSI]"$DomainRootPath") 
$Search.filter = "(&(objectCategory=user)(objectClass=user)(sAMAccountName=$usersm))" 
$findusr=$Search.Findall() 

if ($findusr.count -gt 1)
      {    
            $count = 0
            foreach($i in $findusr)
            {
                  write-host $count ": " $i.path
                  $count = $count + 1
		write-host "multiple matches found"
            }

       exit
      }
      elseif ($findusr.count -gt 0)
      {
            return $findusr[0].path
      }
      else
      {
      write-host "no match found"

      }
}


######Add Lync Shell##########################################


$GpSamNameDN = checkgroupDN $group
$GpSamNameDN = $GpSamNameDN.split("//")
$GpSamNameDN[2]


$diailinmem = Get-CsUser -Filter {ConferencingPolicy -eq $Lyncpol} | select SamAccountName


$Statefile = "$($group)-Name.csv"


# If the file doesn't exist, create oit
   If (!(Test-Path $Statefile)){  
                $diailinmem | Export-csv $Statefile -NoTypeInformation 
                }

# Check Changes
$Changes =  Compare-Object $diailinmem $(Import-Csv $StateFile) -Property SamAccountName | 
                Select-Object SamAccountName,
                    @{n='State';e={
                        If ($_.SideIndicator -eq "=>"){
                            "Removed" } Else { "Added" }
                        }
                    }

$Changes | foreach-object{
         
	if($_.state -eq "Added") {
	
	$UserSamNameDN = checkuserDN $_.SamAccountName
	$UserSamNameDN = $UserSamNameDN.split("//")
        $UserSamNameDN[2]	
        Write-host "Add user "$_.SamAccountName" to group $group" -foregroundcolor green
	$gpmod = Dsmod group $GpSamNameDN[2] -addmbr $UserSamNameDN[2] 2>&1
	if($gpmod -like "*dsmod succeeded*"){ Write-host "$_.SamAccountName added successfully to group $group" -foregroundcolor green }

	 }
	
        if($_.state -eq "Removed") {
       
	$UserSamNameDN = checkuserDN $_.SamAccountName
	$UserSamNameDN = $UserSamNameDN.split("//")
        $UserSamNameDN[2]
        Write-host "Removed user "$_.SamAccountName" to group $group" -foregroundcolor Red
	$gpmod = Dsmod group $GpSamNameDN[2] -rmmbr $UserSamNameDN[2] 2>&1
	if($gpmod -like "*dsmod succeeded*"){ Write-host "$_.SamAccountName Removed successfully from group $group" -foregroundcolor yellow }
	}
      }

$diailinmem | select SamAccountName | Export-csv $StateFile -NoTypeInformation

###########################Recycle##########################################

$path = $dir 
 
Get-ChildItem -Path $path  | Where-Object {  
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force 

#######################Report Error#########################################
if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "Dial in group member modification Script Error"
$msg.Body = $error
$smtp.Send($msg)
$error.clear()
       }
  else

      {
    Write-host "no errors till now"
      }


stop-transcript

##########################################################################


