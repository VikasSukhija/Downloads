<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	6/17/2019 1:46 PM
    Created by:   	Vikas Sukhija
    Organization: 	http://SysCloudPro.com
    Filename:     	SharepointADDExternalUsers.ps1
    ===========================================================================
    .DESCRIPTION
    Add external users in bulk to Sharepoint online Site
#>
param (
  [string]$siteUrl = $(Read-Host "Enter SITE URL on which External access is required"),
  [string]$userId  = $(Read-Host "Enter Site Administrator id"),
  $password = $(Read-Host "Enter Password" -AsSecureString),
 [string] $message = $(Read-Host "Enter Custom Welcome Message")
)
function Write-Log
{
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [array]$Name,
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [string]$Ext,
    [Parameter(Mandatory = $true,ParameterSetName = 'Create')]
    [string]$folder,
    
    [Parameter(ParameterSetName = 'Create',Position = 0)][switch]$Create,
    
    [Parameter(Mandatory = $true,ParameterSetName = 'Message')]
    [String]$Message,
    [Parameter(Mandatory = $true,ParameterSetName = 'Message')]
    [String]$path,
    [Parameter(Mandatory = $false,ParameterSetName = 'Message')]
    [ValidateSet('Information','Warning','Error')]
    [string]$Severity = 'Information',
    
    [Parameter(ParameterSetName = 'Message',Position = 0)][Switch]$MSG
  )
  switch ($PsCmdlet.ParameterSetName) {
    "Create"
    {
      $log = @()
      $date1 = Get-Date -Format d
      $date1 = $date1.ToString().Replace("/", "-")
      $time = Get-Date -Format t
	
      $time = $time.ToString().Replace(":", "-")
      $time = $time.ToString().Replace(" ", "")
	
      foreach ($n in $Name)
      {$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"}
      return $log
    }
    "Message"
    {
      $date = Get-Date
      $concatmessage = "|$date" + "|   |" + $Message +"|  |" + "$Severity|"
      switch($Severity){
        "Information"
        {Write-Host -Object $concatmessage -ForegroundColor Green}
        "Warning"
        {Write-Host -Object $concatmessage -ForegroundColor Yellow}
        "Error"
        {Write-Host -Object $concatmessage -ForegroundColor Red}
      }
      
      Add-Content -Path $path -Value $concatmessage
    }
  }
}
function ProgressBar
{
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true)]
    $Title,
    [Parameter(Mandatory = $true)]
    [int]$Timer
  )
	
  For ($i = 1; $i -le $Timer; $i++)
  {
    Start-Sleep -Seconds 1;
    Write-Progress -Activity $Title -Status "$i" -PercentComplete ($i /10 * 100)
  }
}

#################Check if logs folder is created########
$logpath  = (Get-Location).path + "\logs"
$testlogpath1 = Test-Path -Path $logpath
if($testlogpath1 -eq $false)
{
  ProgressBar -Title "Creating logs folder" -Timer 10
  New-Item -Path (Get-Location).path -Name Logs -Type directory
}

#########################Variable and logs###############
$log = Write-Log -Name "SharePointExternalInvite" -folder logs -Ext log
$users = get-content .\users.txt
$pwd=$password
Write-Log -Message "Script Start" -path $log
#################Add csom and process request############
Add-Type -Path "C:\Program Files\Common Files\microsoft shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\microsoft shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"

$ctx = New-Object Microsoft.SharePoint.Client.ClientContext($siteUrl)
$credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($userId,$pwd)
$ctx.Credentials = $credentials
$userList = New-Object "System.Collections.Generic.List``1[Microsoft.SharePoint.Client.Sharing.UserRoleAssignment]"

ForEach($user in $users)
{
  $userList.clear()
  Write-Log -Message "Processing ..........$user" -path $log
  $userRoleAssignment = New-Object Microsoft.SharePoint.Client.Sharing.UserRoleAssignment
  $userRoleAssignment.UserId = $user
  $userRoleAssignment.Role = [Microsoft.SharePoint.Client.Sharing.Role]::View
  $userList.Add($userRoleAssignment)
  
  try
  {
    Write-Log -Message "Sending invite to user $user" -path $log
    [Microsoft.SharePoint.Client.Sharing.WebSharingManager]::UpdateWebSharingInformation($ctx, $ctx.Web, $userList, $true, $message, $true, $true)
    $ctx.ExecuteQuery()
  }
  catch
  {
    $exception = $_.Exception
    Write-Log -Message $exception -path $log -Severity error
  }
}

 Write-Log -Message "Script Finished" -path $log
########################################################################

