##################################################################################
#			Author: Manuhar Mannan
#			Reviewer: Vikas Sukhija
#			Date: 03/23/2015
#			Description: Take Configuration only Backups & retention
##################################################################################
#############################ADD SHell############################################
If ((Get-PSSnapin | where {$_.Name -match "Microsoft.SharePoint"}) -eq $null)
{
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}

###################Define Variables#####################

$Dname = ((get-date).AddDays(0).toString('yyyyMMdd')) 
$dirName = "ConfigBackup_$Dname"
$dir= "d:\Scripts\SharepointBackup\backup\Configuration"
$limit = (Get-Date).AddDays(-60)


#####################Solution Extraction#################

new-item -path $dir -name $dirName -type directory

	try {
	Write-Host "Exporting Farm backup to $dirName" -foregroundcolor green

	backup-spfarm -BackupMethod Full -Directory "$dir\$dirName\" -ConfigurationOnly
	}
	catch 
	{ 
        Write-Host " � error : $_" -foreground red 
	} 
 
##########################Retention##########################
$path = $dir

Get-ChildItem -Path $path  | Where-Object { 
$_.CreationTime -lt $limit } | Remove-Item -recurse -Force

##############################################################