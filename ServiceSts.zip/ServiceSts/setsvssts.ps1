###################################################################################
#			Author: Vikas Sukhija http://msexchange.me
#			Date: 11/12/2015
#			Update:11/28/2015
#			Reviewer:
#			Description: Start, stop, disable ,manual, automatic
###################################################################################

param(
    
$status,
$startup
)

write-host "After updating the servers & Services file" -foregroundcolor Magenta
write-host "Use Script as setsvssts.ps1 startuptype status" -foregroundcolor Magenta
write-host "-----------------------------------------------" -foregroundcolor Magenta
write-host "--------Examples--------" -foregroundcolor Magenta
write-host "Use Script as setsvssts.ps1 stopped manual" -foregroundcolor Magenta
write-host "Use Script as setsvssts.ps1 stopped automatic" -foregroundcolor Magenta
write-host "Use Script as setsvssts.ps1 stopped disabled" -foregroundcolor Magenta
write-host "Use Script as setsvssts.ps1 running manual" -foregroundcolor Magenta
write-host "Use Script as setsvssts.ps1 running manual" -foregroundcolor Magenta

write-host "=========================================== " -foregroundcolor Blue


write-host "You can also enter parameters when Prompted " -foregroundcolor Blue

$servers = gc .\servers.txt
$services = gc .\services.txt

if(($status -like "stopped") -or ($status -like "running")){ }else{
	$status = Read-host "Refer above and Enter Value for status:" 
	if(($status -like "stopped") -or ($status -like "running")){ }else{
	Write-Host "You have entered invalid input, script will end now" -foregroundcolor Red
	timeout 10
	exit}
}

if(($startup -like "manual") -or ($startup -like "automatic") -or ($startup -like "disabled")){ }else{
	$startup = Read-host "Refer above and Enter Value for startuptype:" 
	if(($startup -like "manual") -or ($startup -like "automatic") -or ($startup -like "disabled")){ }else{
	Write-Host "You have entered invalid input, script will end now" -foregroundcolor Red
	timeout 10
	exit}
}

$servers | foreach-object {
Write-host "Processing ....................... $_"
$comp = $_

$services | foreach-object {
$svc = $_
$comp
$svc

Set-Service -ComputerName $comp -Name $svc -StartupType $startup
if( $status -like "stopped"){
get-service -ComputerName $comp -Name $svc | Stop-Service -force}

if( $status -like "running"){
get-service -ComputerName $comp -Name $svc | Start-Service}


}

}
####################################################################################