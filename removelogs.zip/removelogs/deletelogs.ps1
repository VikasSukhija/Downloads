#####################################################################################################
##           Script to remove Log files based on age                       
##           Author: Vikas Sukhija                  		 
##           Date: 03-30-2012                       		 
##           Modified:04-12-2012 Modified the script for all servers
##           Modified:06/18/2013 Added variables to simplify the script.
#####################################################################################################

#Function remove logs created which will map the server drive & then delete operation will be executed
 
Function RemoveLogs ($Server, $path, $drive, $Age) {

$days = (get-date).adddays($Age)
$date = get-date -format d
$date = $date.ToString().Replace("/", "-")


$net = $(New-Object -ComObject WScript.Network)

##########################define the drive that needs to be mapped #################################
########################## I have entered e$, you can use according to enviornment##################
##########################dont only change after\\$server\ i.e e$ dont change $server###############
##########################$server is used by function call #########################################

$net.MapNetworkDrive("$drive", "\\$Server\e$")

$a= Get-ChildItem  $path | Where{$_.LastWriteTime -lt $days } 

write-host $a


$output =  ".\" + "logs" + "\" + "$Server" + "_" + "$date" + "_log.txt"

Add-content $output "$a log files have been deleted"

################ remove hash # from below line after running the script first time################### 
################so that you know which files will be deleted ########################################

#$a | Foreach-Object { del $_.FullName -recurse}

$net.RemoveNetworkDrive("$drive")

sleep 20

}

############################## define the Variables#################################################

$drive = "Y:"
$path = "Y:\LogFiles\W3SVC1"
$Age = -180

############################# Call function removelogs for servers##################################

RemoveLogs hostname01 $path $drive $Age 
RemoveLogs hostname02 $path $drive $Age 
RemoveLogs hostname03 $path $drive $Age 
RemoveLogs hostname04 $path $drive $Age 
RemoveLogs hostname05 $path $drive $Age
####################################################################################################