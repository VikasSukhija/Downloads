###############################################################
#			Author: Vikas Sukhija (http://msexchange.me)
#			Date: 8/24/2016
#			Reviewer:
#			Decription: Change o365 UPN based on onpremise UPN
#
###############################################################

$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/","-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = ".\Logs" + "\" + "Processed_" + $date1 + "_" + $time + "_.log"
$report = ".\report" + "\" + "Report_" + $date1 + "_" + $time + "_.csv"

$pslogs = ".\Logs" + "\" + "Pslogs_" + $date1 + "_" + $time + "_.log"

start-transcript $pslogs

$data = import-csv $args[0] 

foreach($i in $data){

$CloudUPN = $i.cloudUPN
$onpremUPN = $i.onpremUPN

$date = get-date

write-host "$date - $CloudUPN will be set to $onpremUPN" -foregroundcolor magenta
add-content $logs "$date - $CloudUPN will be set to $onpremUPN"

get-msoluser -UserPrincipalName $CloudUPN | Set-MsolUserPrincipalName -NewUserPrincipalName $onpremUPN

if($error -ne $null){ Write-host "$onpremUPN ---- Processed" -foregroundcolor green

add-content $logs "$onpremUPN ---- Processed"

} 
else {

Add-content $logs "$onpremUPN .....failed processing" -foregroundcolor yellow
Write-host "$onpremUPN ---- Error Occured" -foregroundcolor yellow

$error.clear
}

}

stop-transcript
################################################################




