###################################################################################
#			Author: Vikas Sukhija (http://msexchange.me)
#			Date: 11/12/2015
#			Update:
#			Reviewer:
#			Description: Enable/Disable Tasks
###################################################################################

param(
    
$status

)

$matching1 = "snapshot"
$matching2 = "Ent"

write-host "After updating the servers file" -foregroundcolor Magenta
write-host "Use Script as settasksts.ps1 status" -foregroundcolor Magenta
write-host "-----------------------------------------------" -foregroundcolor Magenta
write-host "--------Examples--------" -foregroundcolor Magenta
write-host "Use Script as settasksts.ps1 Disable " -foregroundcolor Magenta
write-host "Use Script as settasksts.ps1 Enable " -foregroundcolor Magenta

write-host "You can also enter parameters when Prompted " -foregroundcolor Blue



if($status -like $null){

$status= Read-host " Enter Value for Status: " }



$servers = gc .\servers.txt


$servers | foreach-object{
$srv = $_
		$schedule = new-object -com("Schedule.Service")
		$schedule.connect("$srv")
		$tasks = $schedule.getfolder("\").gettasks(0)
		$totaltasks = $tasks | where{($_.Name -match $matching1) -or ($_.Name -match $matching2)}
$totaltasks | foreach-object {
if($status -eq "Disable"){$_.Enabled = $False
Write-host "Disabled Task "$_.name" for server $srv" -foregroundcolor Yellow}

if($status -eq "Enable"){$_.Enabled = $True
Write-host "Enabled Task "$_.name" for server $srv" -foregroundcolor Green}
}

}

####################################################################################