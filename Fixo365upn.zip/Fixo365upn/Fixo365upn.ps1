#########################################################################
#			Author: Vikas Sukhija
#			Reviewer:
#			date: 7/6/2016
#			Modified:7/11/2016						
#			Description: Fix o365 UPN
#			Update: Added reporting
#########################################################################

$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/","-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = ".\Logs" + "\" + "Processed_" + $date1 + "_" + $time + "_.log"
$report = ".\report" + "\" + "Report_" + $date1 + "_" + $time + "_.csv"

$collection = @()

Start-Transcript -Path $logs

If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}


$users = get-content .\users.txt

$users | foreach-object{

$user = $_

$mbx=Get-User $user | Where { -Not [string]::IsNullOrEmpty($_.WindowsEmailAddress) } 

$mbcoll = "" | select Name,ExistingUPN,WindowsEmailAddress,ModifiedUPN

if($mbx){

	if($mbx.UserPrincipalName -eq $mbx.WindowsEmailAddress) {

	Write-host "$user is already setup as "$mbx.UserPrincipalName"" -foregroundcolor blue 
	$mbcoll.Name = $mbx.Name
	$mbcoll.ExistingUPN = $mbx.UserPrincipalName
	$mbcoll.WindowsEmailAddress = $mbx.WindowsEmailAddress
	$mbcoll.ModifiedUPN = "Not Modified" }

	else{

	Set-User -identity $mbx -UserPrincipalName $mbx.WindowsEmailAddress.ToString()
	Write-host "Updating UPN for $user as "$mbx.WindowsEmailAddress"" -foregroundcolor green
	#For($i = 1; $i -le "5"; $i++){ sleep 1;Write-Progress -Activity "Updating UPN for $user" -status "$i" -percentComplete ($i /10*100)}
	#$mbx1 = get-user -identity $mbx
	$mbcoll.Name = $mbx.Name
	$mbcoll.ExistingUPN = $mbx.UserPrincipalName
	$mbcoll.WindowsEmailAddress = $mbx.WindowsEmailAddress
	$mbcoll.ModifiedUPN = $mbx.WindowsEmailAddress }
        }

else{

$mbx=Get-User $user
write-host "$user ..doesn't have ..WindowsEmailAddress" -foregroundcolor magenta
	$mbcoll.Name = $mbx.Name
	$mbcoll.ExistingUPN = $mbx.UserPrincipalName
	$mbcoll.WindowsEmailAddress = $mbx.WindowsEmailAddress
	$mbcoll.ModifiedUPN = "Empty Windows Email"}
$collection += $mbcoll
}

$collection | export-csv $report -notypeinfo

stop-transcript
##########################################################################