﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/27/2016 
     Reviewed on:   12/27/2016
	 Created by:   	Prabhat Tiwari/Vikas Sukhija
	 Reviewed by:   Vikas Sukhija (http://syscloudpro.com)
	 Organization: 	
	 Filename:     	NewSharedMailBox.ps1
	===========================================================================
	.DESCRIPTION
		This script will take inputs from CSV file & will create the Shared mailbox
		along with full access/ send as groups and providing them appropriate permissions.
#>
$error.clear()
##################Load Modules###############
If ((Get-PSSnapin | where { $_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010" }) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}
############################Logs ###############
$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/", "-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log = (Get-Location).Path + "\Logs" + "\" + "Processed_SHDMBX_" + $date1 + "_" + $time + "_.log"
$report1 = (Get-Location).Path + "\Report" + "\" + "Report_SHDMBX_" + $date1 + "_" + $time + "_.csv"
$report2 = (Get-Location).Path + "\Logs" + "\" + "CSV_Created" + $date1 + "_" + $time + "_.csv"

$limit = (Get-Date).AddDays(-60) #for report recycling
$path1 = (Get-Location).Path + "\Logs"
$path2 = (Get-Location).Path + "\Report"

################Variables####################
$UserList = Import-Csv ".\MailboxDetails.csv" | where{ $_.MailboxName -ne "" }
$description = "Disabled Window Resource Account-Mailbox"
$Dom = "@labtest.com"

$email1 = "VikasS@labtest.com", "PrabhatT@labtest.com"
$from = "SharedMailboxCreation@labtest.com"
$smtpserver = "SMTP server"

$collection = @()

Copy-Item ".\MailboxDetails.csv" $report2
#############Load Functions################
################Email Function#####################

function Send-Email
{
	[CmdletBinding()]
	param
	(
		$From,
		[array]$To,
		[array]$bcc,
		[array]$cc,
		$body,
		$subject,
		$attachment,
		$smtpserver
	)
	$message = new-object System.Net.Mail.MailMessage
	$message.From = $from
	if ($To -ne $null)
	{
		$To | ForEach-Object{
			$to1 = $_
			$to1
			$message.To.Add($to1)
		}
	}
	if ($cc -ne $null)
	{
		$cc | ForEach-Object{
			$cc1 = $_
			$cc1
			$message.CC.Add($cc1)
		}
	}
	if ($bcc -ne $null)
	{
		$bcc | ForEach-Object{
			$bcc1 = $_
			$bcc1
			$message.bcc.Add($bcc1)
		}
	}
	$message.IsBodyHtml = $True
	if ($subject -ne $null)
	{
		$message.Subject = $Subject
	}
	if ($attachment -ne $null)
	{
		$attach = new-object Net.Mail.Attachment($attachment)
		$message.Attachments.Add($attach)
	}
	if ($body -ne $null)
	{
		$message.body = $body
	}
	$smtp = new-object Net.Mail.SmtpClient($smtpserver)
	$smtp.Send($message)
}
###################################################
function ProgressBar
{
	[CmdletBinding()]
	param
	(
		$Title
	)
	For ($i = 1; $i -le "10"; $i++)
	{
		Start-Sleep 1;
		Write-Progress -Activity $Title -status "$i" -percentComplete ($i /10 * 100)
	}
}

#############################Loaded Functions######
if ($error) { ProgressBar -title "Exiting - error loading modules/functions"; exit }

Start-Transcript -Path $log
##########Import the values from CSV file ##########

foreach ($User in $UserList)
{
	$SharedMailboxName = $User.MailboxName
	$SharedMailboxName = $SharedMailboxName.trim()
	$SharedMailboxAlias = $User.AliasName
	$SharedMailboxAlias = $SharedMailboxAlias.trim()
	$POwner = $User.PriOwner
	$POwner = $POwner.trim()
	$SOwner = $User.SecOwner
	$FullAccess = $user.FullAccess
	$FullAccess = $FullAccess.trim()
	$Users = $FullAccess.Split(",")
	$SMMBXOU = $User.SMMBXOU
	$GroupsOU = $User.GroupsOU
	
	$FGroup = "FullAccess-" + $SharedMailboxAlias
	$SGroup = "SendAs-" + $SharedMailboxAlias
	$UPN = $SharedMailboxAlias + $Dom
	
	if ($SOwner)
	{
		$SOwner = $SOwner.trim()
		$Owner = "Primary Owner : " + $POwner + ", " + " BUO : " + $SOwner
	}
	Else
	{
		$Owner = "Primary Owner : " + $POwner
	}
	
	$mcoll = "" | select Name, Processed, AlreadyExists, Created, Notes, Description, CustomAttribute10, FullAccessGroup, SendASAccessGroup, FullaccesGrpDesc, SendAsAccessGrpDesc, FullAccessGroupmem, FullAccessGroupInvalidmembers, SendASAccessGroupMem, SendASAccessGroupInvalidmembers, FullaccessPermission, SendasPermission, Nesting
	$mcoll.Name = $SharedMailboxName
	
	if ($error)
	{
		ProgressBar -title "$user will not be processed"
		$mcoll.Processed = "Error"
	}
	else
	{
		$mcoll.Processed = "Processed"
		#####Check if mailbox already exists############
		
		if ((Get-Mailbox $SharedMailboxName -ErrorAction SilentlyContinue) -or (Get-Mailbox $SharedMailboxAlias -ErrorAction SilentlyContinue))
		{
			ProgressBar -Title "Mailbox $SharedMailboxName Already exits"
			$mcoll.AlreadyExists = "Yes"
		}
		else #############Create Shared mailbox###################
		{
			$mcoll.AlreadyExists = "No"
			$Error.clear()
			New-Mailbox -Name:$SharedMailboxName -UserPrincipalName:$UPN -Alias:$SharedMailboxAlias -OrganizationalUnit $SMMBXOU -Shared
			if ($Error)
			{
				Write-Host "Error creating Shared mailbox" -ForegroundColor yellow
				$mcoll.Created = "Error"
			}
			else
			{
				
				while (!(Get-User $SharedMailboxAlias -ErrorAction SilentlyContinue))
				{
					ProgressBar -Title "Creating Shared mailbox $SharedMailboxAlias"
				}
				ProgressBar -Title "Creating Shared mailbox $SharedMailboxAlias"
				ProgressBar -Title "Creating Shared mailbox $SharedMailboxAlias"
				$mcoll.Created = "Created"
				############Update the Notes & Description############
				ProgressBar -Title "Wait for Few Seconds"
				$getsmx = Get-User $SharedMailboxAlias
				if ($getsmx)
				{
					$Error.clear()
					Set-User -Notes $Owner -Identity $getsmx.SamAccountName
					if ($Error)
					{
						Write-Host "Error Updating notes for Shared mailbox" -ForegroundColor yellow
						$mcoll.Notes = "Error"
						$Error.clear()
					}
					else
					{
						Write-Host "Updating notes for $SharedMailboxAlias" -ForegroundColor Green
						$mcoll.Notes = "Success"
					}
					$dn = $getsmx.DistinguishedName
					$dm = $null
					$dm = dsmod user $dn -desc $description 2>&1
					if ($dm -like "*dsmod succeeded*")
					{
						Write-Host "Updating Description for $SharedMailboxAlias" -ForegroundColor Green
						$mcoll.Description = "Updated"
					}
					else
					{
						Write-Host "Updating Description for $SharedMailboxAlias - Failed" -ForegroundColor yellow
						$mcoll.Description = "Failed"
					}
					$Error.clear()
					Set-Mailbox -CustomAttribute10 "NONE" -Identity $getsmx.SamAccountName
					if ($Error)
					{
						Write-Host "Error Updating CustomAttribute10 for $SharedMailboxAlias" -ForegroundColor yellow
						$mcoll.CustomAttribute10 = "Error"
						$Error.clear()
					}
					else
					{
						Write-Host "Updating CustomAttribute10 for $SharedMailboxAlias" -ForegroundColor Green
						$mcoll.CustomAttribute10 = "Success"
					}
					##########Create Groups and update members######################
					$fgpname = "CN=$FGroup,$GroupsOU"
					$dm = $null
					$dm = dsadd group $fgpname 2>&1
					if ($dm -like "*dsadd succeeded*")
					{
						Write-Host "Group $fgpname Created" -ForegroundColor Green
						$mcoll.FullAccessGroup = "Created"
						ProgressBar -Title "Creating $fgpname"
						ProgressBar -Title "Creating $fgpname"
						$dm = $null
						$dm = dsmod group $fgpname -desc "Full Access on :-  $SharedMailboxName" 2>&1
						if ($dm -like "*dsmod succeeded*")
						{
							$mcoll.FullaccesGrpDesc = "Updated Description"
						}
						else
						{
							$mcoll.FullaccesGrpDesc = "Failed Description"
							$dm
						}
						#########Add members#############
						$userdn = @()
						foreach ($Usr in $Users)
						{
							$Us = Get-User $Usr
							$userdn += $Us.distinguishedName
						}
						if ($error)
						{
							$mcoll.FullAccessGroupInvalidmembers = "Error"
						}
						else
						{
							$mcoll.FullAccessGroupInvalidmembers = "No"
						}
						$Error.clear()
						$dm = $null
						$dm = dsmod group $fgpname -addmbr $userdn 2>&1
						if ($dm -like "*dsmod succeeded*")
						{
							$mcoll.FullAccessGroupmem = "Members Added"
						}
						else
						{
							$mcoll.FullAccessGroupmem = "Failed Members Addition"
							$dm
						}
						################Add Permissions to mailbox########
						$Error.clear()
						ADD-MailboxPermission -identity $getsmx.SamAccountName -User $fgpname -AccessRights FullAccess -AutoMapping $false
						if ($Error)
						{
							Write-Host "Error Updating FullaccessPermission for $SharedMailboxAlias" -ForegroundColor yellow
							$mcoll.FullaccessPermission = "Error"
							$Error.clear()
						}
						else
						{
							Write-Host "Updating FullaccessPermission for $SharedMailboxAlias" -ForegroundColor Green
							$mcoll.FullaccessPermission = "Success"
						}
					}
					else
					{
						Write-Host "Group $fgpname Creation - Failed" -ForegroundColor yellow
						$mcoll.FullAccessGroup = "CreationFailed"
						$mcoll.FullaccesGrpDesc = "CreationFailed"
						$mcoll.FullAccessGroupmem = "CreationFailed"
						$mcoll.FullaccessPermission = "CreationFailed"
						$dm
					}
					############################################
					$sgpname = "CN=$SGroup,$GroupsOU"
					$dm = $null
					$dm = dsadd group $sgpname 2>&1
					if ($dm -like "*dsadd succeeded*")
					{
						Write-Host "Group $sgpname Created" -ForegroundColor Green
						$mcoll.SendASAccessGroup = "Created"
						ProgressBar -Title "Creating $sgpname"
						ProgressBar -Title "Creating $sgpname"
						$dm = $null
						$dm = dsmod group $sgpname -desc "Send Access on :-  $SharedMailboxName" 2>&1
						if ($dm -like "*dsmod succeeded*")
						{
							$mcoll.SendAsAccessGrpDesc = "Updated Description"
						}
						else
						{
							$mcoll.SendAsAccessGrpDesc = "Failed Description"
							$dm
						}
						#########Add members#############
						$userdn = @()
						foreach ($Usr in $Users)
						{
							$Us = Get-User $Usr
							$userdn += $Us.distinguishedName
						}
						if ($error)
						{
							$mcoll.SendASAccessGroupInvalidmembers = "Error"
						}
						else
						{
							$mcoll.SendASAccessGroupInvalidmembers = "No"
						}
						$Error.clear()
						$dm = $null
						$dm = dsmod group $sgpname -addmbr $userdn 2>&1
						if ($dm -like "*dsmod succeeded*")
						{
							$mcoll.SendASAccessGroupMem = "Members Added"
						}
						else
						{
							$mcoll.SendASAccessGroupMem = "Failed Members Addition"
							$dm
						}
						#########Nest the group to Full access group#####
						$dm = $null
						$dm = dsmod group $fgpname -addmbr $sgpname 2>&1
						if ($dm -like "*dsmod succeeded*")
						{
							$mcoll.Nesting = "Nested"
						}
						else
						{
							$mcoll.Nesting = "Nesting Failed"
							$dm
						}
						################Add Permissions to mailbox########
						$Error.clear()
						$mbx = Get-Mailbox -id $getsmx.SamAccountName
						$mbx | Add-ADPermission -User $sgpname -Extendedrights "Send As"
						if ($Error)
						{
							Write-Host "Error Updating SendasPermission for $SharedMailboxAlias" -ForegroundColor yellow
							$mcoll.SendasPermission = "Error"
							$Error.clear()
						}
						else
						{
							Write-Host "Updating SendasPermission for $SharedMailboxAlias" -ForegroundColor Green
							$mcoll.SendasPermission = "Success"
						}
					}
					else
					{
						Write-Host "Group $sgpname Creation - Failed" -ForegroundColor yellow
						$mcoll.SendASAccessGroup = "CreationFailed"
						$mcoll.SendAsAccessGrpDesc = "CreationFailed"
						$mcoll.SendASAccessGroupMem = "CreationFailed"
						$mcoll.SendasPermission = "CreationFailed"
						$mcoll.Nesting = "CreationFailed"
						$dm
					}	
					
				}
				else
				{
					Write-Host "not able to find $SharedMailboxAlias" -ForegroundColor Yellow
					$mcoll.Notes = "Mailbox not found"
					$mcoll.Description = "Mailbox not found"
					$mcoll.CustomAttribute10 = "Mailbox not found"
					$mcoll.FullAccessGroup = "Mailbox not found"
					$mcoll.FullaccesGrpDesc = "Mailbox not found"
					$mcoll.SendASAccessGroup = "Mailbox not found"
					$mcoll.SendAsAccessGrpDesc = "Mailbox not found"
					$mcoll.FullAccessGroupmem = "Mailbox not found"
					$mcoll.SendASAccessGroupMem = "Mailbox not found"
					$mcoll.SendasPermission = "Mailbox not found"
					$mcoll.FullaccessPermission = "Mailbox not found"
					
				}
			}
		}
	}
	$collection += $mcoll
}
if ($collection)
{
	$collection | Export-Csv $report1 -NoTypeInformation
	Send-Email -From $from -To $email1 -subject "Shared Mailbox Creation" -attachment $report1 -smtpserver $smtpserver
}
##################Recycle logs####################
Get-ChildItem -Path $path1 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

Get-ChildItem -Path $path2 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

get-date
Stop-Transcript

##################################################################