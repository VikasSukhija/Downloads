<#	
	.NOTES
	===========================================================================
	 Created with: 	VS Code
	 Created on:   	8/6/2018
	 Created by:   	Vikas Sukhija (http://SysCloudPro.com)
	 Organization: 	
	 Filename:     	FlipUPNfromTextFile.ps1
	===========================================================================
	.DESCRIPTION
		This solution will take input from text file and Filp the UPN and FLIP is back again.
#>
$error.clear()
try { stop-transcript | out-null }
catch { $error.clear() }
function Write-Log {
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [array]$Name,
        [Parameter(Mandatory = $true)]
        [string]$Ext,
        [Parameter(Mandatory = $true)]
        [string]$folder
    )
	
    $log = @()
    $date1 = get-date -format d
    $date1 = $date1.ToString().Replace("/", "-")
    $time = get-date -format t
	
    $time = $time.ToString().Replace(":", "-")
    $time = $time.ToString().Replace(" ", "")
	
    foreach ($n in $name) {
		
        $log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
    }
    return $log
}

function LaunchMSOL
	{
		param
		(
			$UserCredential
		)
		import-module msonline
		Write-Host "Enter MS Online Credentials" -ForegroundColor Green
		Connect-MsolService -Credential $UserCredential
	}
	
	Function RemoveMSOL
	{
		
		Write-host "Close Powershell Window - No disconnect available" -ForegroundColor yellow
	}

	If ((Get-PSSnapin | where { $_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010" }) -eq $null)
	{
		Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
	}
	if ($error) { Write-host "Error loading Modules and functions" -foregroundcolor green ; exit }

####################Variables/Logs###########################
$log = Write-Log -Name "FlipUPN" -folder "logs" -Ext "log"
$Report = Write-Log -Name "FlipUPN" -folder "Report" -Ext "csv"
$hybdomain = "Labtest.onmicrosoft.com"
$collection = @()
$users = get-content .\Users.txt
##############################################################
Start-Transcript $log
LaunchMSOL
$users | ForEach-Object{
	$mcoll = "" | Select User,Alias,tempupn,OrignalUPN,Status
$checkeolmbx = Get-Mailbox -Identity $_ -ea silentlycontinue #switch to get-Remotemailbox if users are on exchange online.
if($checkeolmbx){
	$Error.clear()
	try
	{
		$alias = $checkeolmbx.Alias
		$tempupn = $alias + "@" + $hybdomain
		$tempupn
		$orignalUPN = $checkeolmbx.UserPrincipalName
		$orignalUPN
		Set-MsolUserPrincipalName -UserPrincipalName $orignalUPN -NewUserPrincipalName $tempupn
		Write-Host "------temp upn Set $tempupn ----------- " -ForegroundColor Yellow
		timeout 5
		Set-MsolUserPrincipalName -UserPrincipalName $tempupn -NewUserPrincipalName $orignalUPN
		Write-Host "------Orignal upn Set $orignalUPN ----------- " -ForegroundColor Green
		$mcoll.User = $_
		$mcoll.Alias = $alias
		$mcoll.tempupn = $tempupn
		$mcoll.Orignalupn = $orignalUPN
		if ($error)
		{
			Write-Host "Error has occured" -ForegroundColor Red
			$mcoll.Status = "Error"
			$Error.clear()
		}else{
			$mcoll.Status = "Success"
		}
		
	}
		catch{
			$_.Exception
			Write-Host "exception occured Flipping UPN" -ForegroundColor Yellow
		}
}
$collection+= $mcoll
}
$collection | export-csv $Report -NoTypeInformation
RemoveMSOL
Stop-Transcript
###########################################################################o