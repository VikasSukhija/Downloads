#####################################################################################
# 			Author: Vikas Sukhija
# 			Date:- 09/12/2013
#                       Description:- read emailbody,extract attachment & send email 
#			with extracted attachment
#                       Prerequisites :- Powershell/Outlook
#####################################################################################

###############################Logs##################################################
$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log1 = ".\Logs" + "\" + "Processed_" + $date + "_.log"

$logs = ".\Logs" + "\" + "Powershell" + $date + "_" + $time + "_.txt"

Start-Transcript -Path $logs 

$date1 = get-date

#############################outlook Call#############################################

$olFolderInbox = 6
$outlook = new-object -com outlook.application;
$ns = $outlook.GetNameSpace("MAPI");
$inbox = $ns.GetDefaultFolder($olFolderInbox)
$messages = $inbox.items
write-host $messages.count
$messcount = $messages.count
add-content $log1 $date1
add-content $log1 "Messages Count: $messcount"
$countprocessed = 0
foreach($message in $messages){
$msubject = $message.subject
add-content $log1 "Messages Subject: $msubject"
$mBody = $message.body
#Write-Host $mBody
$mBodySplit = $mBody -split "Customer Email ID:"
$toaddress1=$mBodySplit[1]
$toaddress1
add-content $log1 "Vendor Email: $toaddress1"

###################################Save Invoice#######################################

$filepath = "c:\temp\"
$message.attachments|foreach {
    Write-Host $_.filename
    $attr = $_.filename
    add-content $log1 "Attachment: $attr"
    $a = $_.filename
    If ($a.Contains("pdf")) {
    $_.saveasfile((Join-Path $filepath $a))
                             }
  }
$attachment = "c:\temp\" + $a

########################send email invoice###########################################

$mail = $outlook.CreateItem(0) 
$Mail.Recipients.Add($toaddress1) 
$Mail.Subject = "$msubject" 
$Mail.Body = "" 
$Mail.Attachments.Add($attachment)
$Mail.Send()
add-content $log1 "Message Sent: $toaddress1"

#################################Move Items#########################################

$MoveTarget = $inbox.Folders.item("Processed")
[void]$message.Move($MoveTarget)
add-content $log1 "Message Moved to: Processed"
$countprocessed = $countprocessed + 1
}
add-content $log1 "Total Messages Processed: $countprocessed"

###########################Report Errors#############################################

if ($error -ne $null)
{
$smtpServer = "SMTP Server"
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
$msg.From = "OutlookautomationScript@testlab.com"
$msg.To.Add("Vikas.Sukhija@testlab.com")
$msg.Subject = "Outlook Script Error"
$msg.Body = $error
$smtp.Send($msg)
}

Stop-Transcript
#####################################END################################################