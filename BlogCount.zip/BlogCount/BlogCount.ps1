#################################################################################
#		Author: Vikas Sukhija	
#		Date: 03/11/2015
#		Modified:
#		Reviewer:
#		Description: Count number of Blog posts
#################################################################################

#####Define Variables#########

$firstdayofm = ((Get-Date -day 01).AddMonths(-1)).AddDays(0)

$siteurls = gc .\blogurls.txt

$Collection = @()


#####Browse thru each blog #####

foreach($blog in $siteurls)

{

$blogtitle = $blog

$blgtitle = $blogtitle.Split(".")[0].split("//")[2]

$blgxml = $blgtitle + ".xml"

Invoke-WebRequest -Uri $blog -OutFile .\XML\$blgxml

[xml]$XMLcontent = gc .\XML\$blgxml

$items = $XMLcontent.rss.channel.Item 
$count = 0

$items | foreach-object{

[datetime]$pitem = $_.pubdate 


if($pitem -ge $firstdayofm ){

$pitem
$firstdaypmonth

$count = $count +1 }

}

$coll = �� | select BlogTitle,BlogUrl,count
$coll.BlogTitle = $blgtitle
$coll.BlogUrl = $blogtitle
$coll.count = $count

$Collection += $coll

}

$Collection| export-csv .\BlogCountreport.csv -notypeinfo

#####################################################################








