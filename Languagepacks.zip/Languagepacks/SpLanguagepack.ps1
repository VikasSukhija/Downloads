##############################################################################
#                Author: Vikas Sukhija
#                Date: 9/17/2012
#                Description:- Install Language Packs
##############################################################################
#################################LOG##########################################
$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")
$log1 = ".\Logs" + "\" + "Processed_" + $date + "_.log"
$logs = ".\Logs" + "\" + "Powershell" + $date + "_" + $time + "_.txt"
Start-Transcript -Path $logs 

##########################get executable files################################
Get-Content .\installfolders.txt | ForEach-Object{
[string]$loc = get-location
$date1 = get-date
Write-Host -ForegroundColor Blue "$date1 $_ Language Pack folder"
Add-Content $log1 "$date1 $_ Language Pack folder"
$ExecutableFile1 = (Get-ChildItem $_ -Name -Include Sharepoint*.exe )
$ExecutableFile2 = (Get-ChildItem $_ -Name -Include Server*.exe )
$date1 = get-date
Write-Host -ForegroundColor Blue "$date1 ---Installing $ExecutableFile1-----" 
Add-Content $log1 "$date1 ----Installing $ExecutableFile1------"
Start-Process -filepath $loc\$_\$ExecutableFile1 -ArgumentList "/quiet /norestart"

While (Get-Process -Name ($ExecutableFile1 -replace ".exe", "") -ErrorAction SilentlyContinue)
    {
       Write-Host -ForegroundColor Blue "." -NoNewline
       sleep 5
    }
         $date1 = get-date
	 Write-Host -BackgroundColor Blue -ForegroundColor Black "Done."
	 Add-Content $log1 "$date1 ---Done Installing $ExecutableFile1-----"
$date1 = get-date	 
Write-Host -ForegroundColor Blue "$date1 ----Installing $ExecutableFile2---" 
Add-Content $log1 "$date1 ---Installing $ExecutableFile2-----"

Start-Process -filepath $loc\$_\$ExecutableFile2 -ArgumentList "/quiet /norestart"

While (Get-Process -Name ($ExecutableFile2 -replace ".exe", "") -ErrorAction SilentlyContinue)
    {
       Write-Host -ForegroundColor Blue "." -NoNewline
       sleep 5
    }
	 $date1 = get-date	 
	 Write-Host -BackgroundColor Blue -ForegroundColor Black "Done."
	 Add-Content $log1 "$date1 ---Done Installing $ExecutableFile2-----"
}
$date1 = get-date
Write-Host -ForegroundColor Green " - Installation Complete."
Add-Content $log1 "$date1 ---Installation completed please run config wizard----"

Stop-Transcript
##################################################################################