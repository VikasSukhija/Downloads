﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	7/27/2017 8:55 AM
	 Created by:   	Vikas Sukhija(http://SysCloudPro.com)
	 Organization: 	
	 Filename:     	ExtractPermissionsMBX.ps1
	===========================================================================
	.DESCRIPTION
		This script will extract send ad, full access & delegate dump from
                Exchange enviornment, this can be handy in creating groups for EOL Migration.
#>
######################Add Modules##############################
If ((Get-PSSnapin | where {$_.Name -match "Microsoft.Exchange.Management.PowerShell.E2010"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
}

If ((Get-PSSnapin | where { $_.Name -match "Quest.ActiveRoles.ADManagement" }) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}

################################ADD Funstions##################
function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}
#########################Add logs/variables#######################
$excludeacc = (Get-Content .\config\excludeaccounts.txt)
$log = Write-Log -Name extractperm -folder logs -Ext log
$report = Write-Log -Name extractpermissions -folder report -Ext csv
$collection = @()
$count = 0

#Start-Transcript -Path $log
Write-Host "Fetching all mailboxes" -ForegroundColor Magenta
$allmbx = get-mailbox -resultsize unlimited
$countAll = $allmbx.count
Write-Host "fetched all mailboxes .....count $countAll" -ForegroundColor Green

$allmbx | ForEach-Object {
	$pub=@()
	$count = $count + 1
	$mcoll = "" | select Alias, Samaccountname, PrimarySMTPAddress, Employeeid,MBXType,fullaccess, sendasaccess, delegate
	$alias = $_.alias
	$sam = $_.samaccountname
	$email = $_.primarysmtpaddress
	$mbxtype = $_.recipienttypedetails
	Write-Host "Processing........$sam..........$count of $countAll" -ForegroundColor Green
	$qaduser = get-qaduser -samaccountname $sam -IncludedProperties publicdelegates,extensionattribute10
	$empid = $qaduser.extensionattribute10
	$pubdelegates = $qaduser.publicdelegates
	if($pubdelegates){
	$pubdelegates | ForEach-Object{
			$delegate = (get-qaduser $_).Samaccountname
			$pub += $delegate
		}
	}
	$fullaccessp = Get-MailboxPermission -Identity $sam | where{ $_.AccessRights -like "*fullaccess*" } | select -ExpandProperty user
	$senasp = get-mailbox $sam | get-ADPermission | where { $_.ExtendedRights -like "*Send-As*" } | select -ExpandProperty user
	$full = compare $fullaccessp $excludeacc | where{ $_.SideIndicator -eq '<='} | select -ExpandProperty InputObject
	$send = compare $senasp $excludeacc | where{ $_.SideIndicator -eq '<=' } | select -ExpandProperty InputObject
	$mcoll.Alias = $alias
	$mcoll.Samaccountname = $sam
	$mcoll.PrimarySMTPAddress = $email
	$mcoll.Employeeid = $empid
	$mcoll.MBXtype = $mbxtype
	$mcoll.delegate = $pub
	$mcoll.fullaccess = $full
	$mcoll.sendasaccess = $send
	
	$collection += $mcoll
}

$collection | select Alias, Samaccountname, PrimarySMTPAddress,Employeeid,MBXType, @{ Name = "fullaccess"; Expression = { $_.fullaccess } }, @{ Name = "sendasaccess"; Expression = { $_.sendasaccess} }, @{ Name = "delegate"; Expression = { $_.delegate} } |Export-Csv $report -NoTypeInformation
#Stop-Transcript