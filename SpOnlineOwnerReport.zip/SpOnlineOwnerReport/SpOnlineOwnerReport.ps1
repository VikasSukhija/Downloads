﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	8/17/2017 2:26 PM
	 Created by:   	Vikas Sukhija
	 Organization: 	
	 Filename:     	SpOnlineOwnerReport.ps1
	===========================================================================
	.DESCRIPTION
		This will report All owners of Sharepoint SItecollections
#>
#############Load Functions#################
$error.clear()
try { stop-transcript | out-null }
catch { $error.clear() }

function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}

function LaunchSHO
{
	param
	(
		$orgName,
		$cred
	)
	
	Write-Host "Enter Sharepoint Online Credentials" -ForegroundColor Green
	$userCredential = $cred
	Connect-SPOService -Url "https://$orgName-admin.sharepoint.com" -Credential $userCredential
}

Function RemoveSHO
{
	
	disconnect-sposervice
}
##########################Load variables & Logs####################
$log = Write-Log -Name "process_SpSiteonlineOwnerReport" -folder logs -Ext log
$output1 = Write-Log -Name "SPOCollection" -folder Report -Ext html
$orgname = "OrgName"
$collection = @()

##########Start Script main##############

Start-Transcript -Path $log
try
{
	LaunchSHO -orgName $orgname
}
catch
{
	write-host "$($_.Exception.Message)" -foregroundcolor red
	Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "SP Online ConnectionError Site owner Report" -Body $($_.Exception.Message)
	break
}

$collection = Get-SPOSite -Filter { Template -ne "Group#0" } | where{ $_.url -like "*/sites/*" } | Select URL, Owner, StorageUsageCurrent, StorageQuota

############Format HTML###########
$HTMLFormat = "<style>"
$HTMLFormat = $HTMLFormat + "BODY{background-color:GainsBoro;}"
$HTMLFormat = $HTMLFormat + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$HTMLFormat = $HTMLFormat + "TH{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:darksalmon}"
$HTMLFormat = $HTMLFormat + "TD{border-width: 2px;padding: 0px;border-style: solid;border-color: black;background-color:LightBlue}"
$HTMLFormat = $HTMLFormat + "</style>"
################################

$collection | ConvertTo-HTML -Head $HTMLFormat -Body "<H2><Font Size = 4,Color = DarkCyan>SharePoint Online Site Collection excluding Groups,Videos, OneDrive</Font></H2>" -AS Table |
Set-Content $output1

Stop-Transcript
##############################################################################

