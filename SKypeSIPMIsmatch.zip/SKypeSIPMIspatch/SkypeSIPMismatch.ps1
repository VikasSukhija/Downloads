﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	6/28/2017 2:40 PM
	 Created by:   	Vikas Sukhija
	 Organization: 	http://SysCloudPro.com
	 Filename:     	SkypeSIPMismatch.ps1
	===========================================================================
	.DESCRIPTION
		This Script will Check for SKYPe Mismatch with UPN
#>
###################Load Functions######################
$error.clear()
try { stop-transcript | out-null }
catch { $error.clear() }

function LaunchSOL
{
	param
	(
		$Domain,
		$UserCredential
	)
	
	Write-Host "Enter Skype Online Credentials" -ForegroundColor Green
	$CSSession = New-CsOnlineSession -Credential $UserCredential -OverrideAdminDomain $Domain -Verbose
	Import-pssession $CSSession -Prefix "SOL"
	return $UserCredential
}
Function RemoveSOL
{
	
	$Session = Get-PSSession | where { $_.ComputerName -like "admin1a.online.lync.com" }
	Remove-PSSession $Session
}
function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}
####################Variables/Logs###########################
$log = Write-Log -Name "Skype-Mismatch" -folder "logs" -Ext "log"
$Report = Write-Log -Name "Skype-Mismatch" -folder "Report" -Ext "csv"
$domain = "tenant.onmicrosoft.com"
$smtpserver = "smtpserver"
$email1 = "VSukhija@labtest.com"
$from = "DoNotReply@labtest.com"

$collection = @()

########################STart main script#######################

Start-Transcript -Path $log
try
{
  LaunchSOL -Domain $domain -allowclobber
}
catch
{
	$_.Exception
	Write-Host "Exception has occured in connecting to SKOB" -ForegroundColor Yellow
	break;
}

################Connected to SKOB , now fetch users & compare###################
try
{
	$allSKOBusers = Get-SOLCsOnlineUser -Filter { HostingProvider -eq 'sipfed.online.lync.com' } -resultsize:unlimited
}
catch
{
	$_.Exception
	Write-Host "Exception has occured in fetching SKOB users" -ForegroundColor Yellow
	break;
}

$allSKOBusers | ForEach-Object{
	$upn = $_.userprincipalname
	Write-Host " Processing................$upn" -ForegroundColor Green
	$sipaddress = $_.sipaddress
	$sipaddress = $sipaddress -split ":"
	if ($upn -ne $sipaddress[1])
	{
		$mcoll = "" | select UPN, SIPaddress
		$mcoll.UPN = $upn
		$mcoll.SIPaddress = $sipaddress[1]
		$collection+=$mcoll
	}
}
$collection | Export-Csv $Report -NoTypeInformation
timeout 10
Send-MailMessage -SmtpServer $smtpserver -To $email1 -From $from -Subject "Skype for Business SIP Mismatch report" -Attachments $Report
Stop-Transcript
###################################################