#######################################################################
#			Author: Vikas Sukhija (http://msexchange.me)
#			Date: 04/17/2016
#			Reviewer:
#			Desc: Check server status in AD & Name lookup
#######################################################################

###############Add required modules ############

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles.ADManagement"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}

########define variables########
$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/","-")

$report = ".\" + "Decom_" + $date1 + "_.csv"

$smtpserver = "smtpserver"

$from = "DecomSrvAudit@labtest.com"

$to = "vsukhija@labtest.com

$coll = @()

$srvs = gc .\srv.txt

##################################


$srvs | foreach-object{
write-host "processing server $_ ....." -foregroundcolor green
$srv = get-qadcomputer $_$  -ea silentlycontinue
$ping = Test-Connection $_ -count 2 -ea silentlycontinue


if($ping) {
$Pstatus = "Yes"}
Else {
$Pstatus = "No" }

if($srv) {
$Adstatus = "Exists"}
Else {
$Adstatus = "NotFound" }

$nsl = nslookup -querytype=A $_ 2>&1
$find1 = "*can't find*"
$find2 = "*timed-out*"

if(($nsl -like $find1) -or ($nsl -like $find2)){
$lookup = "False"}
Else{
$lookup = "True"}

$wsl = .\nblookup $_
$find = "*does not exist*"

if($Wsl -like $find){
$wlookup = "False"}
Else{
$wlookup = "True"}



$dcomrep = "" | Select Name,Ping,AdStatus,Nslookup,Winslookup

$dcomrep.Name = $_
$dcomrep.Ping = $Pstatus
$dcomrep.AdStatus = $Adstatus
$dcomrep.Nslookup = $lookup
$dcomrep.Winslookup = $wlookup
$coll += $dcomrep

}

####################################################

$coll | export-csv $report -notypeinfo

$getpath = get-childitem $report
$fullpath = $getpath.Fullname

$message = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpserver)
$message.From = $from
$message.To.Add($to)
$message.IsBodyHtml = $False
$message.Subject = "Decom Audit Report"
$attach = new-object Net.Mail.Attachment($fullpath)
$message.Attachments.Add($attach) 
$smtp.Send($message)

#######################################################






