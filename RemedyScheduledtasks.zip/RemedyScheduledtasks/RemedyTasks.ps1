#############################################################################
#       Author: Vikas Sukhija
#       Reviewer:    
#       Date: 01/15/2015
#       
#       Description: Create Remedy Recurring Tickets
#############################################################################
#########################Variables###########################################

$config1 = import-csv .\config\config1.csv

$smtphost = "smtp.labtest.com" 
$days = (get-date).adddays(-60)
$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t
$month = get-date 
$month1 = $month.month
$year1 = $month.year
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$log1 = ".\Logs\" + "Remedy_" + $date + $time + "_.log"

$fromadd = �donotreply@labtest.com�
$email1=�sukhija@labtest.com�
$smtpServer=�smtp.labtest.com�


$collection = @()
############################################################################
####################Create a copy of exiting file###########################

copy .\config\config1.csv .\config\config2.csv

###########################Scheduling#######################################
$config1 = import-csv .\config\config2.csv

foreach($i in $config1)
{
$subject = $i.subject
$body = $i.body
$Assignee = $i.Assignee
$Reccurrence = $i.Reccurrence
$To = $i.to
$Lastoccured = $i.Lastoccured

$curd = get-date
$modd = $curd.adddays(-$Reccurrence)
	if($modd -ge $Lastoccured)
	{
	$tday = get-date
	Write-host "create remedy ticket: $subject - number of days $Reccurrence" -foregroundcolor green
	Add-content $log1 "$tday create remedy ticket: $subject - number of days $Reccurrence"
	$Lastoccured = get-date

####################Create Ticket##########
$message = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtphost)
$message.From = $Assignee
$message.To.Add($To)
$message.IsBodyHtml = $False
$message.Subject = $subject
$message.body = $body
$smtp.Send($message)
###########################################
	}
	else
	{
	$tday = get-date
	Write-host "Remedy ticket: $subject will not be created as its not past $Reccurrence days" -foregroundcolor Red
	Add-content $log1 "$tday Remedy ticket: $subject will not be created as its not past $Reccurrence days"
	}


$coll = "" | select subject,Body,Assignee,Reccurrence,To,Lastoccured

$coll.subject = $subject
$coll.Body = $body
$coll.Assignee = $Assignee
$coll.Reccurrence = $Reccurrence
$coll.To = $To
$coll.Lastoccured = $Lastoccured

$Collection += $coll
}

$Collection | export-csv .\config\config1.csv -notypeinformation



############################################################################
############################################################################

if ($error -ne $null)
      {
$tday = get-date
Add-content $log1 "$tday $error"
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "Remedy scheduled task script error"
$msg.Body = $error
$smtp.Send($msg)
       }
  else

      {
    Write-host "no errors till now"
      }
############################################################################
############################################################################
