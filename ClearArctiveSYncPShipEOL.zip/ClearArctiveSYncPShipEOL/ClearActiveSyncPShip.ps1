﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	8/10/2017 1:23 PM
	 Created by:   	Vikas Sukhija(http://SysCloudPro.com)
	 Organization: 	
	 Filename:     	ClearActiveSyncPShip.ps1
	===========================================================================
	.DESCRIPTION
		This Script will clear activesync partnership that are older than 60 days
#>
#################Load Functions and modules###############
function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}
function LaunchEOL
{
	param
	(
		$Credential
	)
	
	$UserCredential = $Credential
	
	$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
	
	Import-PSSession $Session -Prefix "EOL" -AllowClobber
}
Function RemoveEOL
{
	
	$Session = Get-PSSession | where { $_.ComputerName -like "outlook.office365.com" }
	Remove-PSSession $Session
	
}
#########################variables and logs###################
$log = Write-Log -Name "Clearpartnership" -folder logs -Ext log
$days = (get-date).adddays(-60)
$smtpserver = "smtp.labtest.com"
$from = "RemoveActiveSyncpartnerShip@labtest.com"
$to = "ReportsandLogs@labtest.com"
$erroremail = "ReportsandLogs@labtest.com"
############connect to Exchange online ######################
try
{
	LaunchEOL 
}
catch
{
	write-host "$($_.Exception.Message)" -foregroundcolor red
	Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Exchange online Sharedmbx connection Error" -Body $($_.Exception.Message)
	break
}
################################################################

$casm = get-EOLcasmailbox -resultsize unlimited | where { $_.HasActiveSyncDevicePartnership -eq $true }
Write-Host "Loaded all ACtiveSYnc mailboxes" -ForegroundColor Green
$date = Get-Date
Add-content $log "$date"
Add-content $log "Loaded all ACtiveSYnc mailboxes"

$casm | foreach-object{
	$user = $_.name
	$devices = Get-EOLMobileDeviceStatistics -Mailbox $_.Identity | Where-Object { ($_.LastSuccessSync -le $days) -and ($_.FirstSyncTime -le $days)}
	Write-Host "Processing....................$user" -ForegroundColor Magenta
	if ($devices -ne $null)
	{
		$devices | foreach{
			$deviicemod = $_.DeviceModel
			$devicetype = $_.DeviceType
			$LastSuccessSync = $_.LastSuccessSync
			$guid = [string]$_.Guid
			$usrname = $user
			
			Write-host  "processing....$usrname....$devicetype....$deviicemod....$LastSuccessSync...$guid" -foreground green
			
			Add-content $log "processing....$usrname....$devicetype....$deviicemod....$LastSuccessSync...$guid"
			
			Remove-EOLMobileDevice -identity ([string]$_.Guid) -confirm:$false
		}
	}
}
$date = Get-Date
Add-content $log "$date"
RemoveEOL
timeout 10
Send-MailMessage -SmtpServer $smtpserver -From $from -To $to -Subject "Remove ActiveSync Partnership" -Body "Remove ActiveSync Partnership" -Attachments $log
####################################################################
