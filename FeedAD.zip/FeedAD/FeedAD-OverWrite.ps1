###############################################################################################
##           Author: Vikas Sukhija                   
##           Date: 07-10-2012 
##           modified : 06-08-2013 (made it folder independent)                                                                                                                      
##           Description:- This script is used for feeding data to AD attributes 
##userid,Email,Physicaladdress,City,State,Zip,Country,CountryCode,OfficeTelephone                                                             
###############################################################################################

# Add Quest Shell...

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}


# Import CSV file that is populated with user id & email address

$now=Get-Date -format �dd-MMM-yyyy HH:mm�

# replace : by -

$now = $now.ToString().Replace(�:�, �-�)

$data = import-csv $args[0]

# Loop thru the data from CSV

foreach ($i in $data)

{

$userobject = get-qaduser $i.userid -IncludedProperties �Co�,�C� 

$Address = $userobject.StreetAddress
$City = $userobject.City
$Country = $userobject.co
$Zip = $userobject.PostalCode
$State = $userobject.StateOrProvince
$Phone = $userobject.telephoneNumber


############################StreetAddress########################################################

# adding log to check current  address is blank

if ($Address -like $null)
{

Write-host $userobject has blank Physical address

$Log1 = ".\logs\" + "BlankAddress� + $now + �.log�

Add-content  $Log1 �$userobject has blank Physical address�

# If address is Blank then populate the address from the csv file

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{StreetAddress = $i.PhysicalAddress.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Address = $userobject.StreetAddress

Write-host $userobject has $Address as Physical address

$Log3 = ".\logs\" + "SetAddress� + $now + �.log�

Add-content  $Log3 �For $userobject $Address as address has been set�

} 

else

{

# adding log to check current address is not blank , then address will be overwritten.

$Log2 = ".\logs\" + "Currentaddress� + $now + �.log�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{StreetAddress = $i.PhysicalAddress.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Address = $userobject.StreetAddress

Write-host $userobject has been overwritten with $Address as Current Physical address

Add-content  $Log2 �$userobject has been overwritten with $Address as address�

}

###############################################City#####################################################

# As done above same needs to be done with other parameters

if ($City -like $null)
{
Write-host $userobject has blank City

$Log1 = ".\logs\" + "BlankCity� + $now + �.log�

Add-content  $Log1 �$userobject has blank City�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{l = $i.City.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$City = $userobject.City

Write-host $userobject has $City as City

$Log3 = ".\logs\" + "SetCity� + $now + �.log�

Add-content  $Log3 �For $userobject $City as city has been set�

} 

else

{

$Log2 = ".\logs\" + "CurrentCity� + $now + �.log�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{l = $i.City.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$City = $userobject.City

Write-host $userobject has been overwritten with $City as Current City

Add-content  $Log2 �$userobject has been overwritten with $City as City�

}

###############################################Country##############################################

if ($Country -like $null)

{

Write-host $userobject has blank Country

$Log1 = ".\logs\" + "BlankCountry� + $now + �.log�

Add-content  $Log1 �$userobject has blank Country�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{co = $i.Country.Trim()}

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{C = $i.CountryCode.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Country = $userobject.CO

Write-host $userobject has $Country as Country

$Log3 = ".\logs\" + "SetCountry� + $now + �.log�

Add-content  $Log3 �For $userobject $Country as Country has been set�

} 

else

{

$Log2 = ".\logs\" + "CurrentCountry� + $now + �.log�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{co = $i.Country.Trim()}

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{C = $i.CountryCode.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Country = $userobject.CO

Write-host $userobject has been overwritten with $Country as Country

Add-content  $Log2 �$userobject has been overwritten with $Country as Country�

}

###############################################Postal Code##########################################################

if ($Zip -like $null)
{
Write-host $userobject has blank Zip

$Log1 = ".\logs\" + "BlankZip� + $now + �.log�

Add-content  $Log1 �$userobject has blank Zip�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{PostalCode = $i.Zip.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Zip = $userobject.PostalCode

Write-host $userobject has $Zip as Zip

$Log3 = ".\logs\" + "SetZip� + $now + �.log�

Add-content  $Log3 �For $userobject $Zip as Zip has been set�

} 

else

{

$Log2 = ".\logs\" + "CurrentZip� + $now + �.log�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{PostalCode = $i.Zip.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Zip = $userobject.PostalCode

Write-host $userobject has been overwritten with $Zip as Zip

Add-content  $Log2 �$userobject has been overwritten with $Zip as Zip�

}

###############################################State################################################################

if ($State -like $null)
{
Write-host $userobject has blank State

$Log1 = ".\logs\" + "BlankState� + $now + �.log�

Add-content  $Log1 �$userobject has blank State�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{st = $i.State.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$State = $userobject.st

Write-host $userobject has $State as State

$Log3 = ".\logs\" + "SetState� + $now + �.log�

Add-content  $Log3 �For $userobject $State as State has been set�

} 

else

{

$Log2 = ".\logs\" + "CurrentState� + $now + �.log�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{st = $i.State.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$State = $userobject.st

Write-host $userobject has been overwritten with $State as State

Add-content  $Log2 �$userobject has been overwritten with $State as State�

}

###############################################Phone###############################################################

if ($Phone -like $null)
{
Write-host $userobject has blank Phone

$Log1 = ".\logs\" + "BlankPhone� + $now + �.log�

Add-content  $Log1 �$userobject has blank Phone�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{telephoneNumber = $i.OfficeTelephone.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Phone = $userobject.telephoneNumber

Write-host $userobject has $Phone as Phone

$Log3 = ".\logs\" + "SetPhone� + $now + �.log�

Add-content  $Log3 �For $userobject $Phone as Phone has been set�

} 

else

{

$Log2 = ".\logs\" + "CurrentPhone� + $now + �.log�

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{telephoneNumber = $i.OfficeTelephone.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Phone = $userobject.telephoneNumber

Write-host $userobject has been overwritten $Phone as Phone

Add-content  $Log2 �$userobject has been overwritten $Phone as Phone�

}
}
####################################################################################################################

