﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/21/2016 4:18 PM
	 Created by:   	Vikas Sukhija
	 Organization: 	
	 Filename:     	ControlNewLicenseFeatures.ps1
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$Error.clear()
$date1 = get-date -format d
$date1 = $date1.ToString().Replace("/", "-")
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$report = ".\report" + "\" + "Report_DisabledSVC" + $date1 + "_" + $time + "_.csv"

$collusers = @()
$collection = @()

###################Variables to be defined#######################

$licenseent = "Company:ENTERPRISEPACK"
$svctodisable = @("FLOW_O365_P2", "POWERAPPS_O365_P2", "TEAMS1")

##########################Define functions##############
function ProgressBar {
    [CmdletBinding()]
    param
    (
        $title
    )
    
    For ($i = 1; $i -le "10"; $i++) {
        Start-Sleep 1;
        Write-Progress -Activity $Title -status "$i" -percentComplete ($i /10 * 100)
    }
}
##########Connect to MSOL#####################
Connect-MsolService

$AllLicensingPlans = Get-MsolAccountSku | Where-Object{ $_.AccountSkuId -eq $licenseent }

$allusers = get-msoluser -All | Where-Object{ $_.isLicensed -eq $true }
if ($error) { Write-Host "Exiting Script -- Error Fetching MSOL Users" -ForegroundColor Red; ProgressBar -title "Error Fetching MSOL Users"; exit }

################Loop thru services for each user#####

foreach ($user in $allusers) {
    $status = $user.Licenses.servicestatus
    $upn = $user.userprincipalname
    
    if ($status -ne $null) {
        
        foreach ($svc in $status) {
            $svcnm = $svc.Serviceplan.ServiceName
            $svcsts = $svc.ProvisioningStatus
            foreach ($newsvc in $svctodisable) {
                if (($svcnm -eq $newsvc) -and ($svcsts -ne "Disabled")) {
                    Write-Host "$svcnm is enabled for user $upn" -foregroundcolor Magenta
                    $collusers += $upn
                }
            }
        }
    }
}
$collusers = $collusers | Select-Object -Unique
if ($error) { Write-Host "Exiting Script -- Error Collecting MSOL Users" -ForegroundColor Red; ProgressBar -title "Error  Collecting MSOL Users"; exit }
####loop thru collected user to disable required services witout affecting enabled #######
$collusers | foreach-object{
    $mcoll = "" | Select-Object UserPrincipalName, DisabledSVC
    $USR = $_
    $lic1 = get-msoluser -UserPrincipalName $USR
    
    foreach ($sts in $lic1.Licenses) {
        if ($sts.AccountSkuId -eq $licenseent) {
            $status1 = $sts.servicestatus
        }
    }
    
    $mcoll.UserPrincipalName = $USR
    
    if ($status1 -ne $null) {
        $collnmsts = @()
        foreach ($svc1 in $status1) {
            $svcnm1 = $svc1.Serviceplan.ServiceName
            $svcsts1 = $svc1.ProvisioningStatus
            if ($svcsts1 -eq "Disabled") {
                $collnmsts += $svcnm1
            }
        }
        $collnmsts += $svctodisable
        $mcoll.DisabledSVC = $collnmsts
        $O365Licences = $null
        for ($i = 0; $i -lt $AllLicensingPlans.Count; $i++) {
            $O365Licences = New-MsolLicenseOptions -AccountSkuId $AllLicensingPlans[$i].AccountSkuId -DisabledPlans $collnmsts
        }
        Write-Host "Processing ........................ $USR" -ForegroundColor Green
        Set-MsolUserLicense -UserPrincipalName $USR -LicenseOptions $O365Licences
        if ($error) {
            Write-Host "Exiting Script -- Error setting License for $USR" -ForegroundColor Red; ProgressBar -title "Error seeting License for $USR"; exit
        }
    }
    else {
        Write-Host "Processing ........................ $USR" -ForegroundColor Green
        $mcoll.DisabledSVC = "NA"
    }
    $collection += $mcoll
}
$collection | Select-Object UserPrincipalName, @{ Name = "DisabledSVC"; Expression = { $_.DisabledSVC } } | Export-Csv $report -NoTypeInformation
#############################################################################