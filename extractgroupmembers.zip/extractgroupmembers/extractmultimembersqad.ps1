################################################################################## 
#       Author: Vikas Sukhija 
#       Date: 06/31/2013 
#       Description: Extract group members recursevely 
#       Modified: 01/30/2014
#       Modification: Take input from text file & report members(requested 
#       by MS community user)
################################################################################### 

Param(
     $path
    )

$path = read-host "Please enter text file that contains group name"
if($path -eq $null)
{
Write-host "Please enter text file that contains group name"
}
else
{
$import = get-content $path

# Add Quest Shell...

If ((Get-PSSnapin | where {$_.Name -match "Quest.ActiveRoles"}) -eq $null)
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
}

$import | foreach-object {


$Group = $_



$members = Get-QADGroupMember $Group -Indirect |  select Name, Type | Export-Csv .\$Group.csv

}
}

###################################################################################






