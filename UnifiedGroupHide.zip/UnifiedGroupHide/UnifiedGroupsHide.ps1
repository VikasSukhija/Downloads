﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	3/19/2018 10:16 AM
	 Created by:   	Vikas Sukhija (http://SysCloudPro.com)
	 Organization: 	
	 Filename:     	UnifiedGroupsHide.ps1
	===========================================================================
	.DESCRIPTION
		Hide all new Unified Groups created in last 2 days
#>
#############Load Functions#################
$error.clear()
try { stop-transcript | out-null }
catch { $error.clear() }

function Write-Log
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory = $true)]
		[array]$Name,
		[Parameter(Mandatory = $true)]
		[string]$Ext,
		[Parameter(Mandatory = $true)]
		[string]$folder
	)
	
	$log = @()
	$date1 = get-date -format d
	$date1 = $date1.ToString().Replace("/", "-")
	$time = get-date -format t
	
	$time = $time.ToString().Replace(":", "-")
	$time = $time.ToString().Replace(" ", "")
	
	foreach ($n in $name)
	{
		
		$log += (Get-Location).Path + "\" + $folder + "\" + $n + "_" + $date1 + "_" + $time + "_.$Ext"
	}
	return $log
}

function LaunchEOL
{
	param
	(
		$cred
	)
	
	$UserCredential = $cred
	
	$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
	
	Import-PSSession $Session -Prefix "EOL" -AllowClobber
}
Function RemoveEOL
{
	
	$Session = Get-PSSession | where { $_.ComputerName -like "outlook.office365.com" }
	Remove-PSSession $Session
	
}

##########################Load variables & Logs####################
$log = Write-Log -Name "process_HideUnifiedGroups" -folder logs -Ext log
$Report = Write-Log -Name "HideUnifiedGroups" -folder Report -Ext csv
$collection = @()

$smtpserver = "smtp.labtest.com"
$from = "Automate@labtest.com"
$erroremail = "Reports@labtest.com"
$days = (get-date).adddays(-2)

#####################userid/password################################
$userId = "SVCAccount@labtest.com"
$encrypted1 = "01kgkgnjhvekwhqvknerhmvoi89326842000003660000c000000010000000d3daae27960a5fc000000000000000777fd0d62ab916e90083c0a0a2"
$pwd = ConvertTo-SecureString -string $encrypted1
$Credential = New-Object System.Management.Automation.PSCredential -ArgumentList $userId, $pwd
##########Start Script main##############
Start-Transcript -Path $log
get-date
try
{
	LaunchEOL -Cred $Credential
}
catch
{
	write-host "$($_.Exception.Message)" -foregroundcolor red
	Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Exchange online Unified Group Hide connection Error" -Body $($_.Exception.Message)
	break
}
Write-host "Start fetching o365 groups" -foregroundcolor Green
$geto365groups = Get-EOLUnifiedGroup -resultsize unlimited | where{ ($_.WhenCreated -ge $days) -and ($_.HiddenFromAddressListsEnabled -eq $false) }
Write-host "Finished fetching o365 groups" -foregroundcolor Green

$geto365groups | Foreach-object{
	$Error.clear()
	$mcoll = "" | select Identity, Guid, HiddenFromAddressListsEnabled
	$identity = $_.identity
	$globalidentifier = $_.Guid
	$mcoll.Identity = $identity
	$mcoll.Guid = $globalidentifier.guid
	Set-EOLUnifiedGroup -Identity $globalidentifier.guid -HiddenFromAddressListsEnabled:$true
	if ($error)
	{
		$mcoll.HiddenFromAddressListsEnabled = "Error"
	}
	else
	{
		$mcoll.HiddenFromAddressListsEnabled = "Success"
	}
	$collection+=$mcoll
}
$collection | Export-Csv $Report -NoTypeInformation

Send-MailMessage -SmtpServer $smtpserver -From $from -To $erroremail -Subject "Hide - Office 365 Groups Report"  -Attachments $Report
########################Recycle reports & logs##############
$path1 = ".\report\"
$path2 = ".\Logs\"
$limit = (Get-Date).AddDays(-60) #for report recycling
Get-ChildItem -Path $path1 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

Get-ChildItem -Path $path2 | Where-Object {
	$_.CreationTime -lt $limit
} | Remove-Item -recurse -Force

get-date
Write-Host "Script finished" -ForegroundColor green
Stop-Transcript
##############################################################################
