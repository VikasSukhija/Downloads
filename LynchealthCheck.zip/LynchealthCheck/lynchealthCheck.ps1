#############################################################################
#       Author: Abhishek Gupta
#       Reviewer/Updated: Vikas SUkhija      
#       Date: 04/13/2015
#	Modified:04/14/2015 - HTML Report Creation
#       Description: Lync Health Status
#############################################################################

Import-Module 'C:\Program Files\Common Files\Microsoft Lync Server 2010\Modules\Lync\Lync.psd1'

$reportpath = ".\Lync2010Report.htm" 
$servers = ".\Lyncserver.txt"

if((test-path $reportpath) -like $false)
{
new-item $reportpath -type file
}


$smtphost = "smtp.labtest.com" 
$from = "Lync2010Status@labtest.com" 
$to = "vikas.sukhija@labtest.com"
$groupemail = "TestGroupExpansion@labtest.com" #for group expansion test

##############################HTml Report Content############################
$report = $reportpath

Clear-Content $report 
Add-Content $report "<html>" 
Add-Content $report "<head>" 
Add-Content $report "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>" 
Add-Content $report '<title>Exchange Status Report</title>' 
add-content $report '<STYLE TYPE="text/css">' 
add-content $report  "<!--" 
add-content $report  "td {" 
add-content $report  "font-family: Tahoma;" 
add-content $report  "font-size: 11px;" 
add-content $report  "border-top: 1px solid #999999;" 
add-content $report  "border-right: 1px solid #999999;" 
add-content $report  "border-bottom: 1px solid #999999;" 
add-content $report  "border-left: 1px solid #999999;" 
add-content $report  "padding-top: 0px;" 
add-content $report  "padding-right: 0px;" 
add-content $report  "padding-bottom: 0px;" 
add-content $report  "padding-left: 0px;" 
add-content $report  "}" 
add-content $report  "body {" 
add-content $report  "margin-left: 5px;" 
add-content $report  "margin-top: 5px;" 
add-content $report  "margin-right: 0px;" 
add-content $report  "margin-bottom: 10px;" 
add-content $report  "" 
add-content $report  "table {" 
add-content $report  "border: thin solid #000000;" 
add-content $report  "}" 
add-content $report  "-->" 
add-content $report  "</style>" 
Add-Content $report "</head>" 
Add-Content $report "<body>" 
add-content $report  "<table width='100%'>" 
add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>CS Replication Status</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>" 
add-content $report  "</table>" 
 
add-content $report  "<table width='100%'>" 
Add-Content $report  "<tr bgcolor='IndianRed'>" 
Add-Content $report  "<td width='10%' align='center'><B>ReplicaFqdn</B></td>" 
Add-Content $report  "<td width='20%' align='center'><B>LastStatusReport</B></td>" 
Add-Content $report  "<td width='20%' align='center'><B>LastUpdateCreation</B></td>" 
Add-Content $report  "<td width='10%' align='center'><B>UpToDate</B></td>" 
 

Add-Content $report "</tr>" 

####################################CS Replication Status###########################################

$g1 = Get-CsManagementStoreReplicationStatus | Select-Object UpToDate,ReplicaFqdn,LastStatusReport,LastUpdateCreation,ProductVersion 

foreach($srv in $g1){

$ReplicaFqdn = $srv.ReplicaFqdn
$LastStatusReport = $srv.LastStatusReport
$LastUpdateCreation = $srv.LastUpdateCreation
$UpToDate = $srv.UpToDate

	Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $ReplicaFqdn</B></td>" 
        Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B>$LastStatusReport</B></td>" 
	Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B>$LastUpdateCreation</B></td>"

	if($UpToDate -like $true)
	{

	Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B>$UpToDate</B></td>" 
	Add-Content $report "</tr>" 
	}

	else

	{
	Add-Content $report "<td bgcolor= 'Red' align=center>  <B>$UpToDate</B></td>" 
	Add-Content $report "</tr>" 
	}
}

####################################################################################################
###################################CS User database State###########################################
add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>CS User database State</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>"

add-content $report  "</tr>" 
add-content $report  "</table>" 
add-content $report  "<table width='100%'>" 
Add-Content $report "<tr bgcolor='IndianRed'>"
Add-Content $report  "<td width='25%' align='center'><B>Identity</B></td>" 
Add-Content $report "<td width='25%' align='center'><B>Online</B></td>" 
Add-Content $report "</tr>" 

$c1 = Get-CsUserDatabaseState

foreach($st in $c1) {
$Identity = $st.Identity
$Online = $st.Online
	Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $Identity</B></td>" 
	
	if($Online -like $true){
	Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B>$Online</B></td>" 
	Add-Content $report "</tr>" 
	}
	Else {
	Add-Content $report "<td bgcolor= 'Red' align=center>  <B>$Online</B></td>" 
	Add-Content $report "</tr>" 
	}

}
####################################################################################################
##################################Synthetic transaction IM##########################################
add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>Test IM Status</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>"

add-content $report  "</tr>" 
add-content $report  "</table>" 
add-content $report  "<table width='100%'>" 
Add-Content $report "<tr bgcolor='IndianRed'>"
Add-Content $report  "<td width='25%' align='center'><B>Identity</B></td>" 
Add-Content $report "<td width='25%' align='center'><B>Result</B></td>" 
Add-Content $report "</tr>" 


$csim = Get-CsHealthMonitoringConfiguration

foreach($pool in $csim)
{
$poolN = $pool.identity
Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $poolN</B></td>"
$result = Test-CsIM -TargetFQDN $poolN
	if($result.result -like "Success"){
	Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B> Success</B></td>"
	Add-Content $report "</tr>"
	} else{
	Add-Content $report "<td bgcolor= 'Red' align=center>  <B> Failure</B></td>"
	Add-Content $report "</tr>"
	}
}

######################################################################################################
##################################Synthetic transaction Addressbook###################################
add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>Test Addressbook Status</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>"

add-content $report  "</tr>" 
add-content $report  "</table>" 
add-content $report  "<table width='100%'>" 
Add-Content $report "<tr bgcolor='IndianRed'>"
Add-Content $report  "<td width='25%' align='center'><B>Identity</B></td>" 
Add-Content $report "<td width='25%' align='center'><B>Result</B></td>" 
Add-Content $report "</tr>" 


$csim = Get-CsHealthMonitoringConfiguration

foreach($pool in $csim)
{
$poolN = $pool.identity
Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $poolN</B></td>"
$result = Test-CsAddressBookService -TargetFQDN $poolN
	if($result.result -like "Success"){
	Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B> Success</B></td>"
	Add-Content $report "</tr>"
	} else{
	Add-Content $report "<td bgcolor= 'Red' align=center>  <B> Failure</B></td>"
	Add-Content $report "</tr>"
	}
}

######################################################################################################
##################################Synthetic transaction Presence###################################
add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>Test Presence Status</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>"

add-content $report  "</tr>" 
add-content $report  "</table>" 
add-content $report  "<table width='100%'>" 
Add-Content $report "<tr bgcolor='IndianRed'>"
Add-Content $report  "<td width='25%' align='center'><B>Identity</B></td>" 
Add-Content $report "<td width='25%' align='center'><B>Result</B></td>" 
Add-Content $report "</tr>" 


$csim = Get-CsHealthMonitoringConfiguration

foreach($pool in $csim)
{
$poolN = $pool.identity
Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $poolN</B></td>"
$result = Test-CsPresence -TargetFQDN $poolN
	if($result.result -like "Success"){
	Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B> Success</B></td>"
	Add-Content $report "</tr>"
	} else{
	Add-Content $report "<td bgcolor= 'Red' align=center>  <B> Failure</B></td>"
	Add-Content $report "</tr>"
	}
}

######################################################################################################
##################################Synthetic transaction Dialin########################################
add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>Test Dialin Status</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>"

add-content $report  "</tr>" 
add-content $report  "</table>" 
add-content $report  "<table width='100%'>" 
Add-Content $report "<tr bgcolor='IndianRed'>"
Add-Content $report  "<td width='25%' align='center'><B>Identity</B></td>" 
Add-Content $report "<td width='25%' align='center'><B>Result</B></td>" 
Add-Content $report "</tr>" 


$csim = Get-CsHealthMonitoringConfiguration

foreach($pool in $csim)
{
$poolN = $pool.identity
Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $poolN</B></td>"
$result = Test-CsDialInConferencing -TargetFQDN $poolN
	if($result.result -like "Success"){
	Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B> Success</B></td>"
	Add-Content $report "</tr>"
	} else{
	Add-Content $report "<td bgcolor= 'Red' align=center>  <B> Failure</B></td>"
	Add-Content $report "</tr>"
	}
}

######################################################################################################
##################################Synthetic transaction P2PAV ###############################
add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>Test P2PAV Ssatus</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>"

add-content $report  "</tr>" 
add-content $report  "</table>" 
add-content $report  "<table width='100%'>" 
Add-Content $report "<tr bgcolor='IndianRed'>"
Add-Content $report  "<td width='25%' align='center'><B>Identity</B></td>" 
Add-Content $report "<td width='25%' align='center'><B>Result</B></td>" 
Add-Content $report "</tr>" 

$csim = Get-CsHealthMonitoringConfiguration

foreach($pool in $csim)
{
$poolN = $pool.identity
Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $poolN</B></td>"
$result = Test-CsP2PAV  -TargetFqdn $poolN 
	if($result.result -like "Success"){
	Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B> Success</B></td>"
	Add-Content $report "</tr>"
	} else{
	Add-Content $report "<td bgcolor= 'Red' align=center>  <B> Failure</B></td>"
	Add-Content $report "</tr>"
	}
}
#####################################################################################################
##################################Synthetic transaction group expansion###############################
add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>Test Group Expansion</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>"

add-content $report  "</tr>" 
add-content $report  "</table>" 
add-content $report  "<table width='100%'>" 
Add-Content $report "<tr bgcolor='IndianRed'>"
Add-Content $report  "<td width='25%' align='center'><B>Identity</B></td>" 
Add-Content $report "<td width='25%' align='center'><B>Result</B></td>" 
Add-Content $report "</tr>" 

$csim = Get-CsHealthMonitoringConfiguration

foreach($pool in $csim)
{
$poolN = $pool.identity
Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $poolN</B></td>"
$result = Test-CsGroupExpansion -TargetFqdn $poolN -GroupEmailAddress $groupemail
	if($result.result -like "Success"){
	Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B> Success</B></td>"
	Add-Content $report "</tr>"
	} else{
	Add-Content $report "<td bgcolor= 'Red' align=center>  <B> Failure</B></td>"
	Add-Content $report "</tr>"
	}
}
#####################################################################################################
##################################Lync Services Test#################################################

add-content $report  "<tr bgcolor='Lavender'>" 
add-content $report  "<td colspan='7' height='25' align='center'>" 
add-content $report  "<font face='tahoma' color='#003399' size='4'><strong>Lync Services Test</strong></font>" 
add-content $report  "</td>" 
add-content $report  "</tr>"

add-content $report  "</tr>" 
add-content $report  "</table>" 
add-content $report  "<table width='100%'>" 
Add-Content $report "<tr bgcolor='IndianRed'>"
Add-Content $report  "<td width='25%' align='center'><B>Identity</B></td>" 
Add-Content $report "<td width='25%' align='center'><B>Name</B></td>" 
Add-Content $report "<td width='25%' align='center'><B>Status</B></td>"
Add-Content $report "</tr>" 

$srv = get-content $servers
$srv | foreach {
$identity = $_
$csservices = Get-CsWindowsService -computername $_
  $csservices | foreach{
  $name = $_.Name
  $sts = $_.status
	Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $identity</B></td>"
	Add-Content $report "<td bgcolor= 'GainsBoro' align=center>  <B> $name</B></td>"

        if($sts -like "Running"){
	Add-Content $report "<td bgcolor= 'Aquamarine' align=center>  <B> $sts</B></td>"
	Add-Content $report "</tr>"
        }
        else{
	Add-Content $report "<td bgcolor= 'Red' align=center>  <B> $sts</B></td>"
	Add-Content $report "</tr>"
        }
}
}

######################################################################################################
######################################################### Send Mail ##################################


Add-content $report  "</table>" 
Add-Content $report "</body>" 
Add-Content $report "</html>"

 
$subject = "Lync2010 Status Check Report" 
$body = Get-Content $reportpath
$smtp= New-Object System.Net.Mail.SmtpClient $smtphost 
$msg = New-Object System.Net.Mail.MailMessage $from, $to, $subject, $body 
$msg.isBodyhtml = $true 
$smtp.send($msg) 

###################################################Lync Test Complete#################################
